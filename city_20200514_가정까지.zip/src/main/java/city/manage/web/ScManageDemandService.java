package city.manage.web;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import city.beans.Cl;
import city.beans.ClasB;
import city.beans.SearchUsed;
import city.dao.mapper.ScManageDemandMapper;
import city.domain.ComboData;
import city.domain.Search;

@Service("scManageDemandService")
public class ScManageDemandService {

    @Autowired
    ScManageDemandMapper scManageDemandMapper;
    
    public List<ComboData> getEnergyList() throws Exception {
        return scManageDemandMapper.getEnergyList();
    }
    
    public List<ComboData> getClasAList(Search search) throws Exception {
        return scManageDemandMapper.getClasAList(search);
    }
    
    public List<ComboData> getClasBList(Search search) throws Exception {
        return scManageDemandMapper.getClasBList(search);
    }
    
    public List<Cl> getChartList(SearchUsed search) throws Exception {
        return scManageDemandMapper.getChartList(search);
    }
    
    
}
