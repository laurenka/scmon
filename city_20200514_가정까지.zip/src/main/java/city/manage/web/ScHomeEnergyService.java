package city.manage.web;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import city.beans.Cl;
import city.beans.SearchUsed;
import city.dao.mapper.ScHomeEnergyMapper;
import city.domain.ComboData;
import city.domain.Search;

@Service("scHomeEnergyService")
public class ScHomeEnergyService {

    @Autowired
    ScHomeEnergyMapper scHomeEnergyMapper;
    
    public List<ComboData> getEnergyList() throws Exception {
        return scHomeEnergyMapper.getEnergyList();
    }
    
    public List<ComboData> getClasBList(Search search) throws Exception {
        return scHomeEnergyMapper.getClasBList(search);
    }
    
    public List<ComboData> getClasList(Search search) throws Exception {
        return scHomeEnergyMapper.getClasList(search);
    }
   
    public List<Cl> getChartList(SearchUsed search) throws Exception {
        return scHomeEnergyMapper.getChartList(search);
    }
    
}
