package city.manage.web;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import city.beans.Cl;
import city.beans.ClasC;
import city.beans.EqCate;
import city.beans.EquipCate;
import city.beans.SearchUsed;
import city.dao.mapper.ScHomeAnalyticsMapper;
import city.domain.ComboData;
import city.domain.Search;

@Service("scHomeAnalyticsService")
public class ScHomeAnalyticsService {

    @Autowired
    ScHomeAnalyticsMapper scHomeAnalyticsMapper;
    
    public List<ComboData> getEnergyList() throws Exception {
        return scHomeAnalyticsMapper.getEnergyList();
    }
    
    public List<ComboData> getClasAList(Search search) throws Exception {
        return scHomeAnalyticsMapper.getClasAList(search);
    }
    
    public List<ComboData> getClasList(Search search) throws Exception {
        return scHomeAnalyticsMapper.getClasList(search);
    }
    
    public List<ComboData> getClasBList(Search search) throws Exception {
        return scHomeAnalyticsMapper.getClasBList(search);
    }
    
    public List<ComboData> getClasCList(Search search) throws Exception {
        return scHomeAnalyticsMapper.getClasCList(search);
    }
    
    public List<ComboData> getEqCateList(Search search) throws Exception {
        return scHomeAnalyticsMapper.getEqCateList(search);
    } 
    
    public List<ClasC> getClassB11ChartList(Search search) throws Exception {
        return scHomeAnalyticsMapper.getClassB11ChartList(search);
    }
    
    public List<ClasC> getClassB21ChartList(Search search) throws Exception {
        return scHomeAnalyticsMapper.getClassB21ChartList(search);
    }
    

    public List<ClasC> getClassB22ChartList(Search search) throws Exception {
        return scHomeAnalyticsMapper.getClassB22ChartList(search);
    }

    public List<ClasC> getClassB23ChartList(Search search) throws Exception {
        return scHomeAnalyticsMapper.getClassB23ChartList(search);
    }

    public List<ClasC> getClassB24ChartList(Search search) throws Exception {
        return scHomeAnalyticsMapper.getClassB24ChartList(search);
    }

    public List<ClasC> getClassB25ChartList(Search search) throws Exception {
        return scHomeAnalyticsMapper.getClassB25ChartList(search);
    }

    public List<ClasC> getClassB26ChartList(Search search) throws Exception {
        return scHomeAnalyticsMapper.getClassB26ChartList(search);
    }

    public List<ClasC> getClassB31ChartList(Search search) throws Exception {
        return scHomeAnalyticsMapper.getClassB31ChartList(search);
    }

    public List<ClasC> getClassB41ChartList(Search search) throws Exception {
        return scHomeAnalyticsMapper.getClassB41ChartList(search);
    }

    public List<ClasC> getClassB42ChartList(Search search) throws Exception {
        return scHomeAnalyticsMapper.getClassB42ChartList(search);
    }

    public List<ClasC> getClassB43ChartList(Search search) throws Exception {
        return scHomeAnalyticsMapper.getClassB43ChartList(search);
    }

    public List<ClasC> getClassB44ChartList(Search search) throws Exception {
        return scHomeAnalyticsMapper.getClassB44ChartList(search);
    }

    public List<ClasC> getClassB45ChartList(Search search) throws Exception {
        return scHomeAnalyticsMapper.getClassB45ChartList(search);
    }

    public List<ClasC> getClassB46ChartList(Search search) throws Exception {
        return scHomeAnalyticsMapper.getClassB46ChartList(search);
    }

    public List<Cl> getChartList(SearchUsed search) throws Exception {
        return scHomeAnalyticsMapper.getChartList(search);
    }
    
    public List<Cl> getSeasonChartList(SearchUsed search) throws Exception {
        return scHomeAnalyticsMapper.getSeasonChartList(search);
    }
    
    public List<Cl> getMonthChartList(SearchUsed search) throws Exception {
        return scHomeAnalyticsMapper.getMonthChartList(search);
    }
    
//    public List<ClasC> getClassCChartList(Map search) throws Exception {
//        return scHomeAnalyticsMapper.getClassCChartList(search);
//    }
}
