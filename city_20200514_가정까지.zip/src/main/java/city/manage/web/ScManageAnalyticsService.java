package city.manage.web;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import city.beans.Cl;
import city.beans.ClasC;
import city.beans.EqCate;
import city.beans.EquipCate;
import city.beans.SearchUsed;
import city.dao.mapper.ScManageAnalyticsMapper;
import city.domain.ComboData;
import city.domain.Search;

@Service("scManageAnalyticsService")
public class ScManageAnalyticsService {

    @Autowired
    ScManageAnalyticsMapper scManageAnalyticsMapper;
    
    public List<ComboData> getEnergyList() throws Exception {
        return scManageAnalyticsMapper.getEnergyList();
    }
    
    public List<ComboData> getClasAList(Search search) throws Exception {
        return scManageAnalyticsMapper.getClasAList(search);
    }
    
    public List<ComboData> getClasList(Search search) throws Exception {
        return scManageAnalyticsMapper.getClasList(search);
    }
    
    public List<ComboData> getClasBList(Search search) throws Exception {
        return scManageAnalyticsMapper.getClasBList(search);
    }
    
    public List<ComboData> getClasCList(Search search) throws Exception {
        return scManageAnalyticsMapper.getClasCList(search);
    }
    
    public List<ComboData> getEqCateList(Search search) throws Exception {
        return scManageAnalyticsMapper.getEqCateList(search);
    } 
    
    public List<ClasC> getClassB11ChartList(Search search) throws Exception {
        return scManageAnalyticsMapper.getClassB11ChartList(search);
    }
    
    public List<ClasC> getClassB21ChartList(Search search) throws Exception {
        return scManageAnalyticsMapper.getClassB21ChartList(search);
    }
    

    public List<ClasC> getClassB22ChartList(Search search) throws Exception {
        return scManageAnalyticsMapper.getClassB22ChartList(search);
    }

    public List<ClasC> getClassB23ChartList(Search search) throws Exception {
        return scManageAnalyticsMapper.getClassB23ChartList(search);
    }

    public List<ClasC> getClassB24ChartList(Search search) throws Exception {
        return scManageAnalyticsMapper.getClassB24ChartList(search);
    }

    public List<ClasC> getClassB25ChartList(Search search) throws Exception {
        return scManageAnalyticsMapper.getClassB25ChartList(search);
    }

    public List<ClasC> getClassB26ChartList(Search search) throws Exception {
        return scManageAnalyticsMapper.getClassB26ChartList(search);
    }

    public List<ClasC> getClassB31ChartList(Search search) throws Exception {
        return scManageAnalyticsMapper.getClassB31ChartList(search);
    }

    public List<ClasC> getClassB41ChartList(Search search) throws Exception {
        return scManageAnalyticsMapper.getClassB41ChartList(search);
    }

    public List<ClasC> getClassB42ChartList(Search search) throws Exception {
        return scManageAnalyticsMapper.getClassB42ChartList(search);
    }

    public List<ClasC> getClassB43ChartList(Search search) throws Exception {
        return scManageAnalyticsMapper.getClassB43ChartList(search);
    }

    public List<ClasC> getClassB44ChartList(Search search) throws Exception {
        return scManageAnalyticsMapper.getClassB44ChartList(search);
    }

    public List<ClasC> getClassB45ChartList(Search search) throws Exception {
        return scManageAnalyticsMapper.getClassB45ChartList(search);
    }

    public List<ClasC> getClassB46ChartList(Search search) throws Exception {
        return scManageAnalyticsMapper.getClassB46ChartList(search);
    }

    public List<Cl> getChartList(SearchUsed search) throws Exception {
        return scManageAnalyticsMapper.getChartList(search);
    }
    
    public List<Cl> getSeasonChartList(SearchUsed search) throws Exception {
        return scManageAnalyticsMapper.getSeasonChartList(search);
    }
    
    public List<Cl> getMonthChartList(SearchUsed search) throws Exception {
        return scManageAnalyticsMapper.getMonthChartList(search);
    }
    
//    public List<ClasC> getClassCChartList(Map search) throws Exception {
//        return scManageAnalyticsMapper.getClassCChartList(search);
//    }
}
