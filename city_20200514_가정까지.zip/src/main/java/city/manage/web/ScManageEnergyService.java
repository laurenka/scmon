package city.manage.web;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import city.beans.Cl;
import city.beans.SearchUsed;
import city.dao.mapper.ScManageEnergyMapper;
import city.domain.ComboData;
import city.domain.Search;

@Service("scManageEnergyService")
public class ScManageEnergyService {

    @Autowired
    ScManageEnergyMapper scManageEnergyMapper;
    
    public List<ComboData> getEnergyList() throws Exception {
        return scManageEnergyMapper.getEnergyList();
    }
    
    public List<ComboData> getClasList(Search search) throws Exception {
        return scManageEnergyMapper.getClasList(search);
    }
    
    public List<ComboData> getClasAList(Search search) throws Exception {
        return scManageEnergyMapper.getClasAList(search);
    }
   
    public List<Cl> getChartList(SearchUsed search) throws Exception {
        return scManageEnergyMapper.getChartList(search);
    }
    
}
