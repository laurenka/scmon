package city.manage.web;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import city.beans.Cl;
import city.beans.EqCate;
import city.beans.SearchUsed;
import city.cmm.module.CalculationUtil;
import city.cmm.module.ChartXAxisUtil;
import city.cmm.util.CityUtil;
import city.domain.ComboData;
import city.domain.Search;
import city.domain.SimpleDataResult;
import city.domain.SimpleResult;
import city.menu.service.MenuService;

@Controller
public class ScDashboardController {
    @Autowired MenuService menuService;
//    @Autowired ScHomeAnalyticsService scHomeAnalyticsService;
 
    @RequestMapping(value="/{workspace}/scDashboard")
    public String getScDashboard(HttpServletRequest req, Model model, @PathVariable("workspace") String workspace) {
    	model.addAttribute("workspace", workspace);
        return "scDashboard";
    }

    
    
}
