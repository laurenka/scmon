package city.domain;

public class CompareData {
    float value;

    public float getValue() {
        return value;
    }
    public void setValue(float value) {
        this.value = value;
    }
    
    
}
