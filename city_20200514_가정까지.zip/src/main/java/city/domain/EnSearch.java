package city.domain;

public class EnSearch {
//    public static final int CURRENT = 0;
//    public static final int DAILY = 1;
//    public static final int WEEKLY = 2;
    public static final int MONTHLY = 0;// 3;
    public static final int ANNUAL = 1; //4;

    public static final int PER10 = 1;
    public static final int PER30 = 2;
    public static final int PER60 = 3;
}
