package city.domain;

public class CalculatedEnergyResult2 {
	String chck_date;
	double enrg_totl;
	double totl_prod;
	double basc_unit;
	
	
	
	public String getChck_date() {
		return chck_date;
	}
	public void setChck_date(String chck_date) {
		this.chck_date = chck_date;
	}
	public double getEnrg_totl() {
		return enrg_totl;
	}
	public void setEnrg_totl(double enrg_totl) {
		this.enrg_totl = enrg_totl;
	}
	public double getTotl_prod() {
		return totl_prod;
	}
	public void setTotl_prod(double totl_prod) {
		this.totl_prod = totl_prod;
	}
	public double getBasc_unit() {
		return basc_unit;
	}
	public void setBasc_unit(double basc_unit) {
		this.basc_unit = basc_unit;
	}
}
