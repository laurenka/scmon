package city.domain;

public class SimpleResult {
    protected boolean result;
    protected String message;

    public SimpleResult(boolean result) {
        this.result = result;
    }

    public SimpleResult(boolean result, String message) {
        this.result = result;
        this.message = message;
    }

    public boolean getResult() {
        return result;
    }

    public String getMessage() {
        return message;
    }

    public void setResult(boolean result) {
        this.result = result;
    }

    public void setMessage(String message) {
        this.message = message;
    }

}
