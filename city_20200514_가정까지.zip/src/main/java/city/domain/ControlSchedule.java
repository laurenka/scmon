package city.domain;

public class ControlSchedule {
    int domainId;
    int equipmentId;
    int id;
    String name;
    Integer onHour;
    Integer onMinute;
    Integer offHour;
    Integer offMinute;
    Integer activeControl;
    Integer activeOn;
    Integer activeOff;
    Integer isRepeat;
    Integer season;
    String runDate;
    String repeat;
    String desc;
    
    
    
    public String getStrRepeat() {
        if (isRepeat == 1) {
            int nRepeat = new Integer(repeat);
            return ("0000000" + Integer.toBinaryString(0xFF & nRepeat)).replaceAll(".*(.{8})$", "$1");
        } else {
            return repeat;
        }
    }
    
    
    public int getDomainId() {
        return domainId;
    }
    public void setDomainId(int domainId) {
        this.domainId = domainId;
    }
    public int getEquipmentId() {
        return equipmentId;
    }
    public void setEquipmentId(int equipmentId) {
        this.equipmentId = equipmentId;
    }
    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public Integer getOnHour() {
        return onHour;
    }
    public void setOnHour(Integer onHour) {
        this.onHour = onHour;
    }
    public Integer getOnMinute() {
        return onMinute;
    }
    public void setOnMinute(Integer onMinute) {
        this.onMinute = onMinute;
    }
    public Integer getOffHour() {
        return offHour;
    }
    public void setOffHour(Integer offHour) {
        this.offHour = offHour;
    }
    public Integer getOffMinute() {
        return offMinute;
    }
    public void setOffMinute(Integer offMinute) {
        this.offMinute = offMinute;
    }
    public Integer getActiveControl() {
        return activeControl;
    }
    public void setActiveControl(Integer activeControl) {
        this.activeControl = activeControl;
    }
    public Integer getActiveOn() {
        return activeOn;
    }
    public void setActiveOn(Integer activeOn) {
        this.activeOn = activeOn;
    }
    public Integer getActiveOff() {
        return activeOff;
    }
    public void setActiveOff(Integer activeOff) {
        this.activeOff = activeOff;
    }
    public Integer getIsRepeat() {
        return isRepeat;
    }
    public void setIsRepeat(Integer isRepeat) {
        this.isRepeat = isRepeat;
    }
    public String getRunDate() {
        return runDate;
    }
    public void setRunDate(String runDate) {
        this.runDate = runDate;
    }
    public String getRepeat() {
        return repeat;
    }
    public void setRepeat(String repeat) {
        this.repeat = repeat;
    }
    public String getDesc() {
        return desc;
    }
    public void setDesc(String desc) {
        this.desc = desc;
    }
    public Integer getSeason() {
        return season;
    }
    public void setSeason(Integer season) {
        this.season = season;
    }
}
