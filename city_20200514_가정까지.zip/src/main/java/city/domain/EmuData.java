package city.domain;

import java.util.List;


public class EmuData {
    private DefaultTimeData time;
    private DefaultEquipmentData equipment;
//    private ModuleEmuData emuData;
//    private ModuleEmuData emuData2;
//    private ModuleData moduleData;
//    private List<ModuleEmuData> data;

    public DefaultTimeData getTime() {
        return time;
    }

    public void setTime(DefaultTimeData time) {
        this.time = time;
    }

    public DefaultEquipmentData getEquipment() {
        return equipment;
    }

    public void setEquipment(DefaultEquipmentData equipment) {
        this.equipment = equipment;
    }

//    public ModuleEmuData getEmuData() {
//        return emuData;
//    }
//
//    public void setEmuData(ModuleEmuData emuData) {
//        this.emuData = emuData;
//    }
//
//    public ModuleEmuData getEmuData2() {
//        return emuData2;
//    }
//
//    public void setEmuData2(ModuleEmuData emuData2) {
//        this.emuData2 = emuData2;
//    }
//
//    public ModuleData getModuleData() {
//        return moduleData;
//    }
//
//    public void setModuleData(ModuleData moduleData) {
//        this.moduleData = moduleData;
//    }
//
//    public List<ModuleEmuData> getData() {
//        return data;
//    }
//
//    public void setData(List<ModuleEmuData> data) {
//        this.data = data;
//    }

}
