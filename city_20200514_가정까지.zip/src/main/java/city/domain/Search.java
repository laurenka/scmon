package city.domain;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import org.joda.time.DateTime;

import city.cmm.util.CityUtil;

public class Search implements Cloneable {
	
    public Search() {
        isChart = -1;
        listOrder = 1;
    }
    
    public void calcTime() {
        if (periodType != 0) {
            time = "00:00";
            time2 = "00:00";
            secondTime = "23:59";
            secondTime2 = "23:59";
        }
        
        if (periodType == 1) {
            secondDate = date;
        } else if (periodType == 2) {
            DateTime tmp = CityUtil.fmt.parseDateTime(date); 
            date = tmp.plusDays(1-tmp.getDayOfWeek()).toString(CityUtil.fmt);
            tmp = CityUtil.fmt.parseDateTime(secondDate);
            secondDate = tmp.plusDays(8-tmp.getDayOfWeek()).plusMinutes(-1).toString(CityUtil.fmt);
        } else if (periodType == 3) {
            DateTime tmp = CityUtil.fmt.parseDateTime(date).withDayOfMonth(1);
            date = tmp.toString(CityUtil.fmt);
            secondDate = tmp.plusDays(tmp.dayOfMonth().getMaximumValue()-1).toString(CityUtil.fmt);
        } else if (periodType == 4) {
            DateTime tmp = CityUtil.fmt.parseDateTime(date).withDayOfMonth(1).withMonthOfYear(1);
            date = tmp.toString(CityUtil.fmt);
            secondDate = tmp.plusMonths(12).plusDays(-1).toString(CityUtil.fmt);
        }
    }
    
    public void calcTime2() {
    	if (periodType != 0) {
    		time = "00:00";
    		time2 = "00:00";
    		secondTime = "23:59";
    		secondTime2 = "23:59";
    	}
	  
    	if (periodType == 1) {
    		DateTime tmp = CityUtil.fmt.parseDateTime(date).withDayOfMonth(1);
    		date = tmp.toString(CityUtil.fmt);
    		secondDate = tmp.plusDays(tmp.dayOfMonth().getMaximumValue()-1).toString(CityUtil.fmt);
	      
    		tmp = CityUtil.fmt.parseDateTime(date2).withDayOfMonth(1);
    		date2 = tmp.toString(CityUtil.fmt);
    		secondDate2 = tmp.plusDays(tmp.dayOfMonth().getMaximumValue()-1).toString(CityUtil.fmt);
    	} else if (periodType == 2) {
    		DateTime tmp = CityUtil.fmt.parseDateTime(date).withDayOfMonth(1).withMonthOfYear(1);
    		date = tmp.toString(CityUtil.fmt);
    		secondDate = tmp.plusMonths(12).plusDays(-1).toString(CityUtil.fmt);
	      
    		tmp = CityUtil.fmt.parseDateTime(date2).withDayOfMonth(1).withMonthOfYear(1);
    		date2 = tmp.toString(CityUtil.fmt);
    		secondDate2 = tmp.plusMonths(12).plusDays(-1).toString(CityUtil.fmt);
    	}
    }

    int listOrder = 1;
    
    private int periodType;
    private String date;
    private String time;
    private String secondDate;
    private String secondTime;

    private String date2;
    private String time2;
    private String secondDate2;
    private String secondTime2;

    private int page;
    private int limit;
    private int isUsed;
    
    private int id;
    private int isChart;
    public final static SimpleDateFormat DATE_FORMAT = new SimpleDateFormat("yyyy-MM-dd");
    public final static SimpleDateFormat MONTH_FORMAT = new SimpleDateFormat("yyyy-MM");
    public final static SimpleDateFormat YEAR_FORMAT = new SimpleDateFormat("yyyy");
    
    List<Integer> idList;
    
    private int energy;
    private int clas;
    private int clasA;
    private int clasB;
    private int clasC;
    private int item;
    private String clasField;
    private int eqCate;
    
    
    public int getEqCate() {
		return eqCate;
	}

	public void setEqCate(int eqCate) {
		this.eqCate = eqCate;
	}

	public String getClasField() {
		return clasField;
	}

	public void setClasField(String clasField) {
		this.clasField = clasField;
	}
    
    
    public int getEnergy() {
		return energy;
	}

	public void setEnergy(int energy) {
		this.energy = energy;
	}

	public int getClas() {
		return clas;
	}

	public void setClas(int clas) {
		this.clas = clas;
	}

	public int getClasA() {
		return clasA;
	}

	public void setClasA(int clasA) {
		this.clasA = clasA;
	}

	public int getClasB() {
		return clasB;
	}

	public void setClasB(int clasB) {
		this.clasB = clasB;
	}

	public int getClasC() {
		return clasC;
	}

	public void setClasC(int clasC) {
		this.clasC = clasC;
	}

	public int getItem() {
		return item;
	}

	public void setItem(int item) {
		this.item = item;
	}

	public int getListOrder() {
        return listOrder;
    }
    public void setListOrder(int listOrder) {
        this.listOrder = listOrder;
    }
    public void setEqIds(List<Integer> idList) {
        this.idList = idList;
    }
    public void setEqId(int id) {
        if (idList == null) idList = new ArrayList<>();
        
        idList.add(id);
    }
    public void clearEqId(int id) {
        idList = new ArrayList<>();
        if (id > 0) idList.add(id);
    }
    public List<Integer> getIdList() {
        if (idList == null) idList = new ArrayList<>();
        if (idList.size() == 0) { idList.add(-1); }
        
        return idList;
    }
    
    public int getPeriodType() {
		return periodType;
	}

	public void setPeriodType(int periodType) {
		this.periodType = periodType;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public String getTime() {
		return time;
	}

	public void setTime(String time) {
		this.time = time;
	}

	public String getSecondDate() {
		return secondDate;
	}

	public void setSecondDate(String secondDate) {
		this.secondDate = secondDate;
	}

	public String getSecondTime() {
		return secondTime;
	}

	public void setSecondTime(String secondTime) {
		this.secondTime = secondTime;
	}

	public String getDate2() {
		return date2;
	}

	public void setDate2(String date2) {
		this.date2 = date2;
	}

	public String getTime2() {
		return time2;
	}

	public void setTime2(String time2) {
		this.time2 = time2;
	}

	public String getSecondDate2() {
		return secondDate2;
	}

	public void setSecondDate2(String secondDate2) {
		this.secondDate2 = secondDate2;
	}

	public String getSecondTime2() {
		return secondTime2;
	}

	public void setSecondTime2(String secondTime2) {
		this.secondTime2 = secondTime2;
	}

	public int getPage() {
		return page;
	}

	public void setPage(int page) {
		this.page = page;
	}

	public int getLimit() {
		return limit;
	}

	public void setLimit(int limit) {
		this.limit = limit;
	}

	public int getIsUsed() {
		return isUsed;
	}

	public void setIsUsed(int isUsed) {
		this.isUsed = isUsed;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getIsChart() {
		return isChart;
	}

	public void setIsChart(int isChart) {
		this.isChart = isChart;
	}

	public static SimpleDateFormat getDateFormat() {
		return DATE_FORMAT;
	}

	public void setIdList(List<Integer> idList) {
		this.idList = idList;
	}

	@Override
    public Object clone() throws CloneNotSupportedException {
        return (Search)super.clone();
    }

  
}
