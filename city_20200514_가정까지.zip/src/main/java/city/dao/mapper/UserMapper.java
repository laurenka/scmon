package city.dao.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import city.domain.ComboData;
import city.domain.User;

public interface UserMapper {
    User getUserInfo(User user) throws Exception;
    User getDomainWorkspaceInfo(User user) throws Exception;
    Integer getExistWorkspace(@Param("workspace") String workspace) throws Exception;
    
    List<User> getUserList(@Param("user") User user, @Param("start") int start, @Param("limit") int limit) throws Exception;
    
    int getUserCount(User user) throws Exception;
    
    List<ComboData> getUserGrantList(@Param("deptId") int deptId) throws Exception;
    
    void insertUser(User user) throws Exception;
    void updateUser(User user) throws Exception;
    void deleteUser(User user) throws Exception;
    User getSelfInfo(User user) throws Exception;
    User checkSelfPass(User user) throws Exception;
    void updateSelfInfo(User user ) throws Exception;
    
    
    String getUserName(User user) throws Exception;
    
    List<String> getUserEmails(@Param("ws") int workspaceId) throws Exception;
    
    
    Integer getCheckIp(@Param("ip") String ip) throws Exception;
//    List<HostFilter> getHostInfo(@Param("start") int start, @Param("limit") int limit) throws Exception;
    Integer getHostInfoCount() throws Exception;
//    void insertHost(HostFilter hf) throws Exception;
//    void updateHost(HostFilter hf) throws Exception;
//    void deleteHost(HostFilter hf) throws Exception;
}
