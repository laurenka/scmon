package city.dao.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import city.beans.Cl;
import city.beans.ClasA;
import city.beans.SearchUsed;
import city.beans.Used;
import city.domain.ComboData;
import city.domain.Search;
import city.manage.web.ScManageEnergy;


public interface ScManageEnergyMapper {
	
	List<ComboData> getEnergyList() throws Exception;
	List<ComboData> getClasList(Search search) throws Exception;
	List<ComboData> getClasAList(Search search) throws Exception;
	List<Cl> getChartList(SearchUsed search) throws Exception;
	 
	
	
	
	
	
	
	
	
	
	
	
//	int getTotalCount(Search search) throws Exception;
//	List<ScManageEnergy> getScManageEnergyList(Search search) throws Exception;
//	Integer getScManageEnergyIsUsed(@Param("id") int id) throws Exception;
//	List<ComboData> getManufacturer() throws Exception;
//	void insertScManageEnergy(ScManageEnergy measure) throws Exception;
//    void deleteScManageEnergy(ScManageEnergy measure) throws Exception;

}
