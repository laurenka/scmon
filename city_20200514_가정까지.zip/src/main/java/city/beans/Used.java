package city.beans;

public class Used {
	private int clasA;
	private int clasB;
	private int clasC;
	private int equipCate;
	private int equip;
	private int energy;
	private int item;
	
	private String clasAName;
	private String clasBName;
	private String clasCName;
	private String equipCateName;
	private String equipName;
	private String energyName;
	private String itemName;
	
	private String energyUnit;
	private String itemUnit;
	private String itemSubName;
	
	private float d00;
	private float d01;
	private float d02;
	private float d03;
	private float d04;
	private float d05;
	private float d06;
	private float d07;
	private float d08;
	private float d09;
	private float d10;
	private float d11;
	private float d12;
	private float d13;
	private float d14;
	private float d15;
	private float d16;
	private float d17;
	private float d18;
	private float d19;
	private float d20;
	private float d21;
	private float d22;
	private float d23;
	private float dc;
	
	
	private String used;
	
	private int method;
	private String insertDate;
	
	
	public String getUsed() {
		return used;
	}
	public void setUsed(String used) {
		this.used = used;
	}
	public int getClasA() {
		return clasA;
	}
	public void setClasA(int clasA) {
		this.clasA = clasA;
	}
	public int getClasB() {
		return clasB;
	}
	public void setClasB(int clasB) {
		this.clasB = clasB;
	}
	public int getClasC() {
		return clasC;
	}
	public void setClasC(int clasC) {
		this.clasC = clasC;
	}
	public int getEquipCate() {
		return equipCate;
	}
	public void setEquipCate(int equipCate) {
		this.equipCate = equipCate;
	}
	public int getEquip() {
		return equip;
	}
	public void setEquip(int equip) {
		this.equip = equip;
	}
	public int getEnergy() {
		return energy;
	}
	public void setEnergy(int energy) {
		this.energy = energy;
	}
	public int getItem() {
		return item;
	}
	public void setItem(int item) {
		this.item = item;
	}
	public String getClasAName() {
		return clasAName;
	}
	public void setClasAName(String clasAName) {
		this.clasAName = clasAName;
	}
	public String getClasBName() {
		return clasBName;
	}
	public void setClasBName(String clasBName) {
		this.clasBName = clasBName;
	}
	public String getClasCName() {
		return clasCName;
	}
	public void setClasCName(String clasCName) {
		this.clasCName = clasCName;
	}
	public String getEquipCateName() {
		return equipCateName;
	}
	public void setEquipCateName(String equipCateName) {
		this.equipCateName = equipCateName;
	}
	public String getEquipName() {
		return equipName;
	}
	public void setEquipName(String equipName) {
		this.equipName = equipName;
	}
	public String getEnergyName() {
		return energyName;
	}
	public void setEnergyName(String energyName) {
		this.energyName = energyName;
	}
	public String getItemName() {
		return itemName;
	}
	public void setItemName(String itemName) {
		this.itemName = itemName;
	}
	public String getEnergyUnit() {
		return energyUnit;
	}
	public void setEnergyUnit(String energyUnit) {
		this.energyUnit = energyUnit;
	}
	public String getItemUnit() {
		return itemUnit;
	}
	public void setItemUnit(String itemUnit) {
		this.itemUnit = itemUnit;
	}
	public String getItemSubName() {
		return itemSubName;
	}
	public void setItemSubName(String itemSubName) {
		this.itemSubName = itemSubName;
	}
	public float getD00() {
		return d00;
	}
	public void setD00(float d00) {
		this.d00 = d00;
	}
	public float getD01() {
		return d01;
	}
	public void setD01(float d01) {
		this.d01 = d01;
	}
	public float getD02() {
		return d02;
	}
	public void setD02(float d02) {
		this.d02 = d02;
	}
	public float getD03() {
		return d03;
	}
	public void setD03(float d03) {
		this.d03 = d03;
	}
	public float getD04() {
		return d04;
	}
	public void setD04(float d04) {
		this.d04 = d04;
	}
	public float getD05() {
		return d05;
	}
	public void setD05(float d05) {
		this.d05 = d05;
	}
	public float getD06() {
		return d06;
	}
	public void setD06(float d06) {
		this.d06 = d06;
	}
	public float getD07() {
		return d07;
	}
	public void setD07(float d07) {
		this.d07 = d07;
	}
	public float getD08() {
		return d08;
	}
	public void setD08(float d08) {
		this.d08 = d08;
	}
	public float getD09() {
		return d09;
	}
	public void setD09(float d09) {
		this.d09 = d09;
	}
	public float getD10() {
		return d10;
	}
	public void setD10(float d10) {
		this.d10 = d10;
	}
	public float getD11() {
		return d11;
	}
	public void setD11(float d11) {
		this.d11 = d11;
	}
	public float getD12() {
		return d12;
	}
	public void setD12(float d12) {
		this.d12 = d12;
	}
	public float getD13() {
		return d13;
	}
	public void setD13(float d13) {
		this.d13 = d13;
	}
	public float getD14() {
		return d14;
	}
	public void setD14(float d14) {
		this.d14 = d14;
	}
	public float getD15() {
		return d15;
	}
	public void setD15(float d15) {
		this.d15 = d15;
	}
	public float getD16() {
		return d16;
	}
	public void setD16(float d16) {
		this.d16 = d16;
	}
	public float getD17() {
		return d17;
	}
	public void setD17(float d17) {
		this.d17 = d17;
	}
	public float getD18() {
		return d18;
	}
	public void setD18(float d18) {
		this.d18 = d18;
	}
	public float getD19() {
		return d19;
	}
	public void setD19(float d19) {
		this.d19 = d19;
	}
	public float getD20() {
		return d20;
	}
	public void setD20(float d20) {
		this.d20 = d20;
	}
	public float getD21() {
		return d21;
	}
	public void setD21(float d21) {
		this.d21 = d21;
	}
	public float getD22() {
		return d22;
	}
	public void setD22(float d22) {
		this.d22 = d22;
	}
	public float getD23() {
		return d23;
	}
	public void setD23(float d23) {
		this.d23 = d23;
	}
	public float getDc() {
		return dc;
	}
	public void setDc(float dc) {
		this.dc = dc;
	}
	public int getMethod() {
		return method;
	}
	public void setMethod(int method) {
		this.method = method;
	}
	public String getInsertDate() {
		return insertDate;
	}
	public void setInsertDate(String insertDate) {
		this.insertDate = insertDate;
	}
}
