package city.beans;

public class EquipCate {
//	private int id;
//	private String name;
//	
//	public int getId() {
//		return id;
//	}
//	public void setId(int id) {
//		this.id = id;
//	}
//	public String getName() {
//		return name;
//	}
//	public void setName(String name) {
//		this.name = name;
//	}
	
	
	private float acousticCommunication;
	private float acousticCommunicationFacility;
	private float bookMaterials;
	private float catering;
	private float coolingAndHeating;
	private float cultural;
	private float detachedHouse;
	private float educationalMaterials;
	private float emergencyGenerator;
	private float freezeProtectionElectricHeater;
	private float fuelCell;
	private float heating;
	private float heatingAndheatingWater;
	private float horizontalLighting;
	private float hygiene;
	private float kitchen;
	private float laundryHygiene;
	private float lightControlPanel;
	private float Lighting;
	private float medicalEquipment;
	private float monitoring;
	private float office;
	private float other;
	private float otherCommercial;
	private float otherHousehold;
	private float performanceEquipment;
	private float physicalFacilities;
	private float power;
	private float publicFacilitie;
	private float publicFacility;
	private float rapidCharge;
	private float reasearchMaterials;
	private float religiousFacility;
	private float sales;
	private float signalControlPanel;
	private float slowCharge;
	private float streetLighting;
	private float toiletElectricWaterHeater;
	private float trafficLight;
	private float trainingEquipment;


	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
