package city.beans;
import java.util.List;
import java.util.Map;

import city.domain.ComboData;
 
public class SearchUsed {
	private int energy;
	private int periodType;
	private String date;
	private String clasField;
	private List<ComboData> list;

	
	public int getEnergy() {
		return energy;
	}
	public void setEnergy(int energy) {
		this.energy = energy;
	}
	public int getPeriodType() {
		return periodType;
	}
	public void setPeriodType(int periodType) {
		this.periodType = periodType;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public String getClasField() {
		return clasField;
	}
	public void setClasField(String clasField) {
		this.clasField = clasField;
	}
	public List<ComboData> getList() {
		return list;
	}
	public void setList(List<ComboData> list) {
		this.list = list;
	}
	
}
