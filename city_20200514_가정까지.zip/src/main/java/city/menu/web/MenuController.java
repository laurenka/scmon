package city.menu.web;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import city.domain.SimpleDataResult;
import city.domain.SimpleResult;
import city.domain.TreeMenuItem;
import city.domain.User;
import city.login.web.LoginController;
import city.menu.service.MenuItem;
import city.menu.service.MenuService;

@Controller
public class MenuController {
 
    @Autowired MenuService menuService;

    @ResponseBody
    @RequestMapping(value="/{workspace}/getMenu", method=RequestMethod.POST, produces="application/json;charset=utf8")
    public SimpleResult getMenu(HttpServletRequest req, Model model, @PathVariable("workspace") String workspace) {
        createMenu( req, model );
        return new SimpleDataResult(true, model);
    }
    
    @ResponseBody
    @RequestMapping(value="/{ws}/getModuleMenu", method=RequestMethod.POST, produces="application/json;charset=utf8")
    public SimpleResult getModuleMenu(HttpServletRequest req, Model model) {
        User user = LoginController.getUser(req);
        try {
            if (user.getDeptId() == 0) {
                model.addAttribute("qm", menuService.getModule(user.getDeptId(), user.getDomainId()));
            } else {
                model.addAttribute("qm", menuService.getModule(user.getDeptId(), user.getWorkspaceId()));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        return new SimpleDataResult(true, model);
    }
    
    public Model createMenu( HttpServletRequest req, Model model ) {
        User user = LoginController.getUser(req);
        if (user != null) {
            List<TreeMenuItem<MenuItem>> mainMenu = new ArrayList<TreeMenuItem<MenuItem>>();
            try {
                List<MenuItem> menuList = menuService.getMenuList(user.getGradeId());
                for(MenuItem item : menuList) {
                    if (item.getParentId() == 0) {
                        List<MenuItem> childList = menuList.stream().filter(it->it.getParentId() == item.getId()).collect(Collectors.toList());
        
                        TreeMenuItem<MenuItem> parentTree = new TreeMenuItem<MenuItem>(item);
                        for(MenuItem child : childList) {
                            parentTree.addChildren(child);
                        }
                        
                        mainMenu.add( parentTree );
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            
            
            model.addAttribute("data", mainMenu);
        }
        
        model.addAttribute("user", user);
        return model;
    }
    
    @ResponseBody
    @RequestMapping(value="/{workspace}/getTab", method=RequestMethod.POST, produces="application/json;charset=utf8")
    public SimpleResult getTab(HttpServletRequest req, @PathVariable("workspace") String workspace) {
        try {
            return new SimpleDataResult(true, menuService.getTabList(LoginController.getUser(req).getDomainId()));
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        return new SimpleResult(false);
    }
}
