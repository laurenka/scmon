package city.cmm.exception;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class CityNoneTypeModuleException extends Exception {
    
    private static final long serialVersionUID = 4L;

    @Value("${city.exception.nonetypemodule}")
    private String message;

    @Override
    public String getMessage() {
        return message;
    }
}
