package city.cmm.util;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.ibatis.exceptions.PersistenceException;
import org.apache.ibatis.reflection.ReflectionException;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;
import org.mybatis.spring.MyBatisSystemException;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.transaction.CannotCreateTransactionException;
import org.springframework.ui.Model;

import city.cmm.exception.CityDuplicateException;
import city.cmm.exception.CityNonTransactionConnectionException;
import city.domain.Search;

public class CityUtil {

    public static DateTimeFormatter realTimeFmt = DateTimeFormat.forPattern("yyyy-MM-dd HH:mm");
    public static DateTimeFormatter dateFmt = DateTimeFormat.forPattern("yyyy-MM-dd");
    public static DateTimeFormatter timeFmt = DateTimeFormat.forPattern("HH:mm"); 
    public static SimpleDateFormat monthlyFormat = new SimpleDateFormat("dd");
    public static SimpleDateFormat timeFormat = new SimpleDateFormat("HH:mm");
    public static DateTimeFormatter fmt = DateTimeFormat.forPattern("yyyy-MM-dd");
 
    public static final Integer SINIL_NUMBER = -1000;
    
    private final static Log log = LogFactory.getLog(CityUtil.class);

    public static Exception myExceptionTypeConvert(Exception e) {
        Throwable cause = e.getCause();
        log.info(e.getClass() + "[cause is instance of " + cause + "]");

        if (e instanceof DuplicateKeyException) {
            return ApplicationContextLocator.getApplicationContext().getBean(CityDuplicateException.class);
        } else if (e instanceof MyBatisSystemException) {

            if (cause instanceof ReflectionException) {
                return e;
            } else if (cause instanceof PersistenceException) {
                return ApplicationContextLocator.getApplicationContext().getBean(CityNonTransactionConnectionException.class);
            } else {
                return e;
            }

        } else if (e instanceof CannotCreateTransactionException) {
            return ApplicationContextLocator.getApplicationContext().getBean(CityNonTransactionConnectionException.class);
        } else {
            return e;
        }
    }

    public static Model makePageModel(Model model, int page, int limit, List list, int totalSize) {
        model.addAttribute("page", page);
        model.addAttribute("limit", limit);
        int offset = (page - 1) * limit;
        model.addAttribute("start", (totalSize!=0)?(offset + 1):0);
        model.addAttribute("end", offset + list.size());
        model.addAttribute("totalSize", totalSize);
        model.addAttribute("totalPage", new BigDecimal(totalSize).divide(new BigDecimal(limit), 0, BigDecimal.ROUND_UP).intValue());
        model.addAttribute("data", list);

        return model;
    }

    public static Map<String, Object> makePageModel(Map<String, Object> model, int page, int limit, List list, int totalSize) {
        model.put("page", page);
        model.put("limit", limit);
        int offset = (page - 1) * limit;
        model.put("start", (totalSize!=0)?(offset + 1):0);
        model.put("end", offset + list.size());
        model.put("totalSize", totalSize);
        model.put("totalPage", new BigDecimal(totalSize).divide(new BigDecimal(limit), 0, BigDecimal.ROUND_UP).intValue());
        model.put("data", list);

        return model;
    }

    public static  Map<String, Object> makePageModel(Search search, List list, int totalSize) {
        Map<String, Object> model = new HashMap<>();
        makePageModel(model, search.getPage(), search.getLimit(), list, totalSize);
        return model;
    }
    
    public static String convertMethodName(String str) {
        return String.format("get%s%s", str.substring(0, 1).toUpperCase(), str.substring(1).toLowerCase());
    }

    public static boolean isEmpty(Float value) {
        return (value == null);
    }
    
    public static boolean isEmpty(Integer value) {
        return (value == null);
    }
    
    public static boolean isEmpty(String value) {
        return (value == null || (value != null && "".equals(value)));
    }
    
    @SuppressWarnings("rawtypes")
    public static boolean isEmpty(List list) {
        return list == null || (list != null && list.size() == 0);
    }
    

    public static boolean isZero(Float value) {
        return (value == null || (value != null && value == 0F));
    }
    
    public static boolean isZero(String value) {
        if (value == null || (value != null && "".equals(value)) || (value != null && "0".equals(value))) {
            return true;
        } else {
            return (0F == new BigDecimal(value).floatValue());
        }
    }
    
    public static boolean isOne(String value) {
        if (value == null || (value != null && "".equals(value)) || (value != null && "1".equals(value))) {
            return true;
        } else {
            return (1F == new BigDecimal(value).floatValue());
        }
    }
    
}
