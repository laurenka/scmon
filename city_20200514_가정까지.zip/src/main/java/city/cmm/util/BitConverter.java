package city.cmm.util;

import java.nio.ByteBuffer;

public class BitConverter {
	public static int ToShort16(byte[] bytes, int offset) {
		int result = 0;
		result |= (((int)bytes[offset]) << 8);
		result |= (((int)bytes[offset+1]))&0xff;
        return result;
    }
	
	public static short ToInt16(byte[] bytes, int offset) {
		short result = (short) ((int)bytes[offset+1]&0xff);
        result |= ((int)bytes[offset]&0xff) << 8;
        //System.out.println(result & 0xffff);
        return (short) (result & 0xffff);
    }
	
	public static int ToUInt16(byte[] bytes, int offset) {
		int result = (int)bytes[offset+1]&0xff;
        result |= ((int)bytes[offset]&0xff) << 8;
        //System.out.println(result & 0xffff);
        return result & 0xffff;
    }
	
	public static int ToInt32(byte[] bytes, int offset) {
		int result = (int)bytes[offset+3]&0xff;
        result |= ((int)bytes[offset+2]&0xff) << 8;
        result |= ((int)bytes[offset+1]&0xff) << 16;
        result |= ((int)bytes[offset]&0xff) << 24;
        //System.out.println(result);
        return result;
    }
	
	public static long ToUInt32(byte[] bytes, int offset) {
        long result = (int)bytes[offset+3]&0xff;
        result |= ((int)bytes[offset+2]&0xff) << 8;
        result |= ((int)bytes[offset+1]&0xff) << 16;
        result |= ((int)bytes[offset]&0xff) << 24;
        //System.out.println(result & 0xFFFFFFFFL);
        return result & 0xFFFFFFFFL;
    }
	
	public static long ToUInt64(byte[] bytes, int offset) {
        long result = 0;
        for (int i = 0; i <= 56; i += 8) {
			result |= ((int)bytes[offset++]&0xff) << i;
		}
        //System.out.println(result);
        return result;
    }

	public static byte[] GetBytesOf16Int(int value) {
		byte[] bytes = new byte[2];
		bytes[0] = (byte) (value >> 8);
		bytes[1] = (byte) (value);
		//System.out.println(Arrays.toString(bytes));
		return bytes;
	}
	
	public static byte[] GetBytes(int value) {
		byte[] bytes = new byte[4];
		bytes[0] = (byte) (value >> 24);
		bytes[1] = (byte) (value >> 16);
		bytes[2] = (byte) (value >> 8);
		bytes[3] = (byte) (value);
		//System.out.println(Arrays.toString(bytes));
		return bytes;
	}
	
	public static byte[] GetBytes(long value) {
		byte[] bytes = new byte[4];
		bytes[0] = (byte) (value >> 24);
		bytes[1] = (byte) (value >> 16);
		bytes[2] = (byte) (value >> 8);
		bytes[3] = (byte) (value);
		//System.out.println(Arrays.toString(bytes));
		return bytes;
	}
	
	public static float ToSingle(byte[] b, long offset) {
		ByteBuffer buf = ByteBuffer.wrap(b, (int) offset, 4);
		float outp = buf.getFloat();
        //System.out.println(outp);
		return outp;
	}
	
	public static byte[] GetBytes(float value) { //int 32 �? 처리?��?�� float ?�� ?�� byte array�? �??�� 
		int floatValue =  Float.floatToIntBits(value);
		byte[] g = GetBytes(floatValue);
//		System.out.println(floatValue);
		return g;
	}
	
	public static byte[] GetBytes(double value) { //unsigned int 32 �? 처리?��?�� double ?�� ?�� byte array�? �??�� 
		long longValue =  Double.doubleToLongBits(value);
		//System.out.println(GetBytes(longValue));
		return GetBytes(longValue);
	}

	public static float ToFloat(byte bytes[], int offset) { //byte array�? float ?��?���? �??�� (int32)
		int value =  (int)ToUInt32(bytes, offset);
		return Float.intBitsToFloat(value);
	}
	
	public static double ToDouble(byte bytes[], int offset) { //byte array�? double ?��?���? �??�� (unsigned int 32)
		long value =  ToUInt32(bytes, offset);
		//System.out.println(Double.longBitsToDouble(value));
		return Double.longBitsToDouble(value);
	}
	
	public static byte[] GetByteBits(String value) {
		byte[] bytes = new byte[2];
		if(value != null && !value.equals("") && value.length() == 16) {
			bytes[0] = (byte) Integer.parseInt(value.substring(0, 8), 2);
			bytes[1] = (byte) Integer.parseInt(value.substring(8), 2);
//			System.out.println("[GetByteBits] string 1 : "+ value.substring(0, 8) + ", string 2 : "+ value.substring(8) + ", bytes 0 : " + bytes[0] + ", bytes 1 : " + bytes[1]);
		}
		//System.out.println(Arrays.toString(bytes));
		return bytes;
	}
	
	public static String ToStringBits(byte bytes[], int offset) {
		String s1 = String.format("%8s", Integer.toBinaryString(bytes[offset] & 0xFF)).replace(' ', '0');
		String s2 = String.format("%8s", Integer.toBinaryString(bytes[offset+1] & 0xFF)).replace(' ', '0');
		return s1 + s2;
	}
}
