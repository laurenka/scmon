package city.cmm.util;

import java.util.List;
import java.util.Properties;

import javax.mail.Address;
import javax.mail.BodyPart;
import javax.mail.Message;
import javax.mail.Multipart;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import city.dao.mapper.UserMapper;

@Component
public class EmailSender {

	@Value("${mail.title}")
	String title;
	
    @Autowired
    private UserMapper userMapper;

    private final static Logger LOG = LoggerFactory.getLogger(EmailSender.class);

    public void sendMaterialInfoToManager(final int workspaceId, final String title, final String context) {
        Properties props = new Properties();
        props.put("mail.smtp.host", "localhost");//props.put("mail.smtp.host", "localhost");
        props.put("mail.smtp.port", "25");
//        props.put("mail.smtp.auth", "false");
        
        Session session = Session.getDefaultInstance(props);
        try {
            List<String> emails = userMapper.getUserEmails(workspaceId);
            if (emails == null || emails.size() == 0) {
                return;
            }

            MimeMessage msg = new MimeMessage( session );
            msg.setFrom(new InternetAddress("localhost", "EMS 시스템 관리자", "utf-8" ));
            Address[] address = new Address[ emails.size() ];
            for ( int a = 0; a < emails.size(); a++ ) {
                address[a] = new InternetAddress( emails.get(a), "");
            }
            msg.addRecipients(Message.RecipientType.TO, address );
            msg.setSubject("","utf-8");

            Multipart multipart = new MimeMultipart();
            BodyPart messageBodyPart = new MimeBodyPart();
            String message = "본 메일은 EMS에서 발송하는 시스템 메일입니다.<br/>" + context;

            messageBodyPart.setContent(message, "text/html; charset=UTF-8");
            multipart.addBodyPart(messageBodyPart);
            msg.setContent(multipart);

            Transport.send(msg);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
