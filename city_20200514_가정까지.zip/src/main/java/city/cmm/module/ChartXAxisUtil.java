package city.cmm.module;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Map;

import org.joda.time.DateTime;
import org.joda.time.Period;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;

import city.cmm.util.CityUtil;
import city.domain.EnSearch;
import city.domain.Search;



public class ChartXAxisUtil {
    public static List<String> makeData(Map<String, Integer> indexMap, Search search) throws Exception {
        int periodType = search.getPeriodType();
        List<String> xAxisData = new ArrayList<>();

        /*
        if (periodType == EnSearch.CURRENT) {
            if ("".equals(search.getTime()) && "".equals(search.getSecondTime())) {
                return xAxisData;
            } else if (search.getDate().equals(search.getSecondDate()) && search.getTime().equals(search.getSecondTime())) {
                return xAxisData;
            }
            
            DateTime start = null;
            if (search.getTime() != null && !"".equals(search.getTime()) && !"-1".equals(search.getTime())) {
                start = DateTime.parse(String.format("%s %s", search.getDate(), search.getTime()), SmfemsUtil.realTimeFmt);
            } else {
                start = new DateTime(search.getDate());
            }
            DateTime finish = null;
            if (search.getSecondDate() != null && !"".equals(search.getSecondDate()) && !"-1".equals(search.getSecondDate())) {
                finish = DateTime.parse(String.format("%s %s", search.getSecondDate(), search.getSecondTime()), SmfemsUtil.realTimeFmt);
            } else {
                finish = new DateTime(search.getSecondDate());
            }
            
            String str = "";
            while (finish.compareTo(start) >= 0) {
                str = start.toString("yyyy-MM-dd HH:mm");
                indexMap.put(str, xAxisData.size());
                xAxisData.add(str);
                
                start = start.plusMinutes(1);
            }
        } else if (periodType == EnSearch.DAILY) {
            
            
            for (int i = 0; i < 24; i++) {
                String str = String.format("%02d:00", i);
                indexMap.put(str, xAxisData.size());
                xAxisData.add(str);
            }
        } else if (periodType == EnSearch.WEEKLY) {
            DateTime start = DateTime.parse(search.getDate(), CityUtil.fmt);
            DateTime finish = DateTime.parse(search.getSecondDate(), CityUtil.fmt);
            start.toGregorianCalendar().setFirstDayOfWeek(Calendar.MONDAY);
            finish.toGregorianCalendar().setFirstDayOfWeek(Calendar.MONDAY);
            
            while(finish.compareTo(start) >= 0) {
                Pair<String, Boolean> key = getKey(start);
                if (!indexMap.containsKey(key.getInput1())) {
                    indexMap.put(key.getInput1(), xAxisData.size());
                    xAxisData.add(key.getInput1());
                }
                
                if (!key.getInput2() || start.getWeekOfWeekyear() > 51) {
                    start = start.plus(Period.days(1));
                } else {
                    start = start.plus(Period.weeks(1));
                }
            }
        } else 
        */	
        if (periodType == EnSearch.MONTHLY) {
            Calendar startCal = Calendar.getInstance();
            startCal.setTime(Search.DATE_FORMAT.parse(search.getDate()));
            startCal.set(Calendar.DAY_OF_MONTH, 1);
            int max = startCal.getActualMaximum(Calendar.DAY_OF_MONTH);
            while (true) {
                String str = CityUtil.monthlyFormat.format(startCal.getTime());
                indexMap.put(str, xAxisData.size());
                xAxisData.add(str);
                int day = startCal.get(Calendar.DAY_OF_MONTH);
                startCal.add(Calendar.DAY_OF_MONTH, 1);
                if (day == max) {
                    break;
                }
            }
        } else if (periodType == EnSearch.ANNUAL) {
            for (int i = 1; i <= 12; i++) {
                String str;
                if (i < 10) {
                    str = "0" + Integer.toString(i);
                } else {
                    str = Integer.toString(i);
                }
                indexMap.put(str, xAxisData.size());
                xAxisData.add(str);
            }
        }
        return xAxisData;
    }
    

    public static List<String> makeDataForAnalytics(Map<String, Integer> indexMap, Search search) throws Exception {
        int periodType = search.getPeriodType();
        List<String> xAxisData = new ArrayList<>();

//        if (periodType == EnSearch.MONTHLY) {
//            Calendar startCal = Calendar.getInstance();
//            startCal.setTime(Search.DATE_FORMAT.parse(search.getDate()));
//            startCal.set(Calendar.DAY_OF_MONTH, 1);
//            int max = startCal.getActualMaximum(Calendar.DAY_OF_MONTH);
//            while (true) {
//                String str = CityUtil.monthlyFormat.format(startCal.getTime());
//                indexMap.put(str, xAxisData.size());
//                xAxisData.add(str);
//                int day = startCal.get(Calendar.DAY_OF_MONTH);
//                startCal.add(Calendar.DAY_OF_MONTH, 1);
//                if (day == max) {
//                    break;
//                }
//            }
//        } else 
        if (periodType == 0) { //EnSearch.ANNUAL) {
        	Calendar searchCal = Calendar.getInstance();
        	searchCal.setTime(Search.DATE_FORMAT.parse(search.getDate()));
        	int searchedYear = searchCal.YEAR;
        	int lastYear = searchCal.YEAR - 1;
        	
//          int max = startCal.getActualMaximum(Calendar.DAY_OF_MONTH);
        	
        	
        	
            for (int i = 1; i <= 12; i++) {
                String str;
                if (i < 10) {
                    str = "0" + Integer.toString(i);
                } else {
                    str = Integer.toString(i);
                }
                indexMap.put(str, xAxisData.size());
                xAxisData.add(str);
            }
        } else {
        	for (int i = 1; i <= 12; i++) {
                String str;
                if (i < 10) {
                    str = "0" + Integer.toString(i);
                } else {
                    str = Integer.toString(i);
                }
                indexMap.put(str, xAxisData.size());
                xAxisData.add(str);
            }
        }
        
        return xAxisData;
    }
        
    public static Integer getMapIndex(Search search, Map<String, Integer> indexMap, String date, String time) {
        try {
//            if (search.getPeriodType() == EnSearch.CURRENT) {
//                return indexMap.get(String.format("%s %s", date, time));
//            } else 
            if (
//            		search.getPeriodType() == EnSearch.DAILY 
//                    || 
                    search.getPeriodType() == EnSearch.MONTHLY 
                    || search.getPeriodType() == EnSearch.ANNUAL) {
                return indexMap.get(date);
            } 
//            else if (search.getPeriodType() == EnSearch.WEEKLY) {
//                return indexMap.get(String.format("%s-%s", date, time));
//            }
        } catch (Exception e) {
            
        }
        
        return null;
    }
    
    
    static DateTime parseWeek(DateTime date, boolean upDirct) {
        DateTime tmp = new DateTime();
        tmp = date;
        if (upDirct) {
            tmp = date.plusDays(7-date.getDayOfWeek());
            return tmp.getYear() == date.getYear() ? tmp : date;
        } else {
            tmp = tmp.minusDays(tmp.getDayOfWeek()-1);
            return tmp.getYear() == date.getYear() ? tmp : date;
        }
    }
    
    static Pair<String, Boolean> getKey(DateTime date) {
        Pair<String, Boolean> pair = new Pair();
        DateTime tmp = date.minusDays(date.getDayOfWeek()-1);
        pair.setInput2(tmp.getYear() == date.getYear());
        if (pair.getInput2()) {
            return pair.setInput1(String.format("%d-%02d", tmp.getYear(), tmp.getWeekOfWeekyear())); 
        } else {
           return pair.setInput1(String.format("%d-00", date.getYear()));
        }
    }

    public static boolean isIdCheck(int typeId, Pair<Integer, Integer> pair) {
        if (pair == null)
            return true;

        if (pair.getInput1() != null && pair.getInput1() == typeId)
            return true;
        else if (pair.getInput2() != null && pair.getInput2() == typeId)
            return true;

        return false;
    }
}
