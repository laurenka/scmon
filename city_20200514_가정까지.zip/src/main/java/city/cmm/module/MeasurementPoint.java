package city.cmm.module;

public class MeasurementPoint {
    int workspaceId;
    int id;
    int moduleId;
    String ip;
    String subIp;
    Integer port;
    int menuId;
    int useType;
    int publicType;

    float defaultValue;
    float constant;
    String lastUpdateDate;
    String lastUpdateTime;
    
    String unitId;
    int subId;
    int mmtType;
    int mmtStart;
    int mmtSize;
    
    int parentId;
    
    String menuName;
    String useTypeName;
    String transType;
    String product;
    String mgrNo;
    String parse;
    
    String code;
    
    int isUsed;
    int isAvg;
    Float minValue;
    Float maxValue;
    
    Float minValue2;
    Float maxValue2;
    
    int onTime;
    int offTime;
    
    String returnSTDate;
    String returnFHDate;
    
    int energyId;
    int energyCode;

    public int getWorkspaceId() {
        return workspaceId;
    }
    public void setWorkspaceId(int workspaceId) {
        this.workspaceId = workspaceId;
    }
    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }
    public int getModuleId() {
        return moduleId;
    }
    public void setModuleId(int moduleId) {
        this.moduleId = moduleId;
    }
    public String getIp() {
        return ip;
    }
    public void setIp(String ip) {
        this.ip = ip;
    }
    public String getSubIp() {
		return subIp;
	}
	public void setSubIp(String subIp) {
		this.subIp = subIp;
	}
	public Integer getPort() {
        return port;
    }
    public void setPort(Integer port) {
        this.port = port;
    }
    public int getMenuId() {
        return menuId;
    }
    public void setMenuId(int menuId) {
        this.menuId = menuId;
    }
    public int getUseType() {
        return useType;
    }
    public void setUseType(int useType) {
        this.useType = useType;
    }
    public int getPublicType() {
        return publicType;
    }
    public void setPublicType(int publicType) {
        this.publicType = publicType;
    }
    public float getDefaultValue() {
        return defaultValue;
    }
    public void setDefaultValue(float defaultValue) {
        this.defaultValue = defaultValue;
    }
    public float getConstant() {
        return constant;
    }
    public void setConstant(float constant) {
        this.constant = constant;
    }
    public String getLastUpdateDate() {
        return lastUpdateDate;
    }
    public void setLastUpdateDate(String lastUpdateDate) {
        this.lastUpdateDate = lastUpdateDate;
    }
    public String getLastUpdateTime() {
        return lastUpdateTime;
    }
    public void setLastUpdateTime(String lastUpdateTime) {
        this.lastUpdateTime = lastUpdateTime;
    }
    public String getUnitId() {
        return unitId;
    }
    public void setUnitId(String unitId) {
        this.unitId = unitId;
    }
    public int getSubId() {
        return subId;
    }
    public void setSubId(int subId) {
        this.subId = subId;
    }
    public int getMmtType() {
        return mmtType;
    }
    public void setMmtType(int mmtType) {
        this.mmtType = mmtType;
    }
    public int getMmtStart() {
        return mmtStart;
    }
    public void setMmtStart(int mmtStart) {
        this.mmtStart = mmtStart;
    }
    public int getMmtSize() {
        return mmtSize;
    }
    public void setMmtSize(int mmtSize) {
        this.mmtSize = mmtSize;
    }
    public String getMenuName() {
        return menuName;
    }
    public void setMenuName(String menuName) {
        this.menuName = menuName;
    }
    public String getUseTypeName() {
        return useTypeName;
    }
    public void setUseTypeName(String useTypeName) {
        this.useTypeName = useTypeName;
    }
    public String getTransType() {
        return transType;
    }
    public void setTransType(String transType) {
        this.transType = transType;
    }
    public String getProduct() {
        return product;
    }
    public void setProduct(String product) {
        this.product = product;
    }
    public String getMgrNo() {
        return mgrNo;
    }
    public void setMgrNo(String mgrNo) {
        this.mgrNo = mgrNo;
    }
    public String getParse() {
        return parse;
    }
    public void setParse(String parse) {
        this.parse = parse;
    }
    public String getCode() {
        return code;
    }
    public void setCode(String code) {
        this.code = code;
    }
    public int getIsUsed() {
        return isUsed;
    }
    public void setIsUsed(int isUsed) {
        this.isUsed = isUsed;
    }
    public int getIsAvg() {
        return isAvg;
    }
    public void setIsAvg(int isAvg) {
        this.isAvg = isAvg;
    }
    public Float getMinValue() {
        return minValue;
    }
    public void setMinValue(Float minValue) {
        this.minValue = minValue;
    }
    public Float getMaxValue() {
        return maxValue;
    }
    public void setMaxValue(Float maxValue) {
        this.maxValue = maxValue;
    }
    public Float getMinValue2() {
        return minValue2;
    }
    public void setMinValue2(Float minValue2) {
        this.minValue2 = minValue2;
    }
    public Float getMaxValue2() {
        return maxValue2;
    }
    public void setMaxValue2(Float maxValue2) {
        this.maxValue2 = maxValue2;
    }
    public int getOnTime() {
        return onTime;
    }
    public void setOnTime(int onTime) {
        this.onTime = onTime;
    }
    public int getOffTime() {
        return offTime;
    }
    public void setOffTime(int offTime) {
        this.offTime = offTime;
    }
    public int getParentId() {
        return parentId;
    }
    public void setParentId(int parentId) {
        this.parentId = parentId;
    }
    public String getReturnSTDate() {
        return returnSTDate;
    }
    public void setReturnSTDate(String returnSTDate) {
        this.returnSTDate = returnSTDate;
    }
    public String getReturnFHDate() {
        return returnFHDate;
    }
    public void setReturnFHDate(String returnFHDate) {
        this.returnFHDate = returnFHDate;
    }
    public int getEnergyId() {
        return energyId;
    }
    public void setEnergyId(int energyId) {
        this.energyId = energyId;
    }
    public int getEnergyCode() {
        return energyCode;
    }
    public void setEnergyCode(int energyCode) {
        this.energyCode = energyCode;
    }
    
    
    public String toString() {
    	return String.format("HOST:%s:%d MENU:%d UNIT:%s START:%s TYPE:%s PRODUCT:%s", ip, port, menuId, unitId, mmtStart, transType, product);
    }
}
