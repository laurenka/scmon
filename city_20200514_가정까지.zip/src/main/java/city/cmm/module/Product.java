package city.cmm.module;

import java.util.ArrayList;
import java.util.List;

//import city.manage.web.ScManageEnergy;


public class Product {
    protected String name;
    protected String ip;
    protected int port;
    protected int mmtStart;
    protected int mmtSize;
    
    protected int id;
    protected String unitId;
    protected int subId;
    protected int moduleId;
    protected MeasurementPoint mp;
//    protected ScManageEnergy mInfo;
    
    int energyId;
    int energyCode;
    
    private List<MeasurementPoint> menuList;
    
    public Product() {
        name = null;
        ip = null;
        port = -1;
        subId = -1;
        mmtStart = -1;
        mmtSize = -1;
        menuList = new ArrayList<>();
    }

    public boolean equals(Product pd) {
        if (!this.name.equals(pd.getName()) 
                || this.id != pd.getId()
                || !this.ip.equals(pd.getIp())
                || this.port != pd.getPort() 
                || this.subId != pd.getSubId()
                || this.mmtStart != pd.getMmtStart() 
                || this.mmtSize != pd.getMmtSize()) {
            return false;
        }
        
        return true;
    }
    
    public void addMenuId(MeasurementPoint mp) {
        boolean isExist = false;
        for(MeasurementPoint mId : menuList) {
            if (mId.getMenuId() == mp.getMenuId())  
                isExist = true;
        }
        
        if (!isExist) {
            menuList.add(mp);
        }
    }
    
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public String getIp() {
        return ip;
    }
    public void setIp(String ip) {
        this.ip = ip;
    }
    public int getPort() {
        return port;
    }
    public void setPort(int port) {
        this.port = port;
    }
    public int getSubId() {
        return subId;
    }
    public void setSubId(int subId) {
        this.subId = subId;
    }
    public int getMmtStart() {
        return mmtStart;
    }
    public void setMmtStart(int mmtStart) {
        this.mmtStart = mmtStart;
    }
    public int getMmtSize() {
        return mmtSize;
    }
    public void setMmtSize(int mmtSize) {
        this.mmtSize = mmtSize;
    }
    public List<MeasurementPoint> getMenuList() {
        return menuList;
    }
    public void setMenuList(List<MeasurementPoint> menuList) {
        this.menuList = menuList;
    }
    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }
    public String getUnitId() {
        return unitId;
    }
    public void setUnitId(String unitId) {
        this.unitId = unitId;
    }
    public int getModuleId() {
        return moduleId;
    }
    public void setModuleId(int moduleId) {
        this.moduleId = moduleId;
    }
    public int getEnergyId() {
        return energyId;
    }
    public void setEnergyId(int energyId) {
        this.energyId = energyId;
    }
    public int getEnergyCode() {
        return energyCode;
    }
    public void setEnergyCode(int energyCode) {
        this.energyCode = energyCode;
    }
	public MeasurementPoint getMp() {
		return mp;
	}
	public void setMp(MeasurementPoint mp) {//
		this.mp = mp;
	}
//	public void setMInfo(ScManageEnergy mInfo) {
//		this.mInfo = mInfo;
//	}
	
}
