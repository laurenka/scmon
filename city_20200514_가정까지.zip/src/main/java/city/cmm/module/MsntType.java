package city.cmm.module;


public enum MsntType {

    NONE("0"),
    DEFAULT("1"),
    TRANS("2"),
    DIRECTINPUT("3"),
    IMAGE("5"),
    DB("6");
    
    String id;
    MsntType(String id) {
        this.id = id;
    }
    
    public static MsntType find(String id) throws Exception {
        if ( id == null) throw new Exception(String.format("입력값[%s]이 없습니다.", id));
        
        for(MsntType type : values()) {
            if ( id.equals(type.id) ) {
                return type;
            }
        }
        
        throw new Exception(String.format("타입[%s]이 없습니다.", id));
    }
    
    public static MsntType find(int id) throws Exception {
        for(MsntType type : values()) {
            if (id == new Integer(type.id).intValue()) {
                return type;
            }
        }
        
        throw new Exception(String.format("타입[%s]이 없습니다.", id));
    }
}
