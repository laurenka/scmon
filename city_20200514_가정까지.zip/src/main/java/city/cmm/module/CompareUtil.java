package city.cmm.module;

import city.cmm.util.CityUtil;

public class CompareUtil {

    public static boolean isEquals(String in1, String in2) {
        if (CityUtil.isEmpty(in1) || CityUtil.isEmpty(in2)) {
            return false;
        }
        
        return in1.equals(in2);
    }
    
    public static boolean isEquals(Integer in1, Integer in2) {
        if (CityUtil.isEmpty(in1) || CityUtil.isEmpty(in2)) {
            return false;
        }
        
        return in1.intValue() == in2.intValue();
    }
    
    public static boolean isEquals(Float in1, Float in2) {
        if (CityUtil.isEmpty(in1) || CityUtil.isEmpty(in2)) {
            return false;
        }
        
        return in1.floatValue() == in2.floatValue();
    }
    
}
