package city.cmm.module;

public class Third<T, T1, T2> {
    public T input1;
    public T1 input2;
    public T2 input3;
    
    public T getInput1() {
        return input1;
    }
    public Third setInput1(T input1) {
        this.input1 = input1;
        return this;
    }
    public T1 getInput2() {
        return input2;
    }
    public Third setInput2(T1 input2) {
        this.input2 = input2;
        return this;
    }
    public T2 getInput3() {
        return input3;
    }
    public Third setInput3(T2 input3) {
        this.input3 = input3;
        return this;
    }
    
    @Override
    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        
        if (obj == null || obj.getClass() != this.getClass()) {
            return false;
        }
        
        Third th = (Third) obj;
        boolean isGood = true;
        if (isGood && th.getInput1() instanceof Integer) {
            isGood = CompareUtil.isEquals((Integer) th.getInput1(), (Integer) input1);
        } else if (isGood && th.getInput1() instanceof Float) {
            isGood = CompareUtil.isEquals((Float) th.getInput1(), (Float) input1);
        } else if (isGood && th.getInput1() instanceof String) {
            isGood = CompareUtil.isEquals((String) th.getInput1(), (String) input1);
        }

        if (isGood && th.getInput2() instanceof Integer) {
            isGood = CompareUtil.isEquals((Integer) th.getInput2(), (Integer) input2);
        } else if (isGood && th.getInput2() instanceof Float) {
            isGood = CompareUtil.isEquals((Float) th.getInput2(), (Float) input2);
        } else if (isGood && th.getInput2() instanceof String) {
            isGood = CompareUtil.isEquals((String) th.getInput2(), (String) input2);
        }

        if (isGood && th.getInput3() instanceof Integer) {
            isGood = CompareUtil.isEquals((Integer) th.getInput3(), (Integer) input3);
        } else if (isGood && th.getInput3() instanceof Float) {
            isGood = CompareUtil.isEquals((Float) th.getInput3(), (Float) input3);
        } else if (isGood && th.getInput3() instanceof String) {
            isGood = CompareUtil.isEquals((String) th.getInput3(), (String) input3);
        }
        
        return isGood;
    }
    
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((input1 == null) ? 0 : input1.hashCode());
        result = prime * result + ((input2 == null) ? 0 : input2.hashCode());
        result = prime * result + ((input3 == null) ? 0 : input3.hashCode());
        return result;
    }
}
