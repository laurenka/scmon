package city.login.web;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import city.cmm.util.CityUtil;
import city.domain.SimpleResult;
import city.domain.User;
import city.login.service.LoginService;
import city.login.service.UserSession;
import city.menu.service.MenuService;

@Controller
public class LoginController {

    public static String LOG_IN_ATTRIBUTE;
    @Value("${city.log_in_attribute_name}")
    public void setLOG_IN_ATTRIBUTE(String log_in_attribute_name) {
        LOG_IN_ATTRIBUTE = log_in_attribute_name;
    }
    
    public static String LOG_IN_GROUP = "LOG_IN_GROUP";
    
    @Value("${city.log_in_failure}")
    String LOG_IN_FAILURE;
    
    @Value("${city.log_in_pass_failure}")
    String LOG_IN_PASS_FAILURE;
    
    @Value("${city.log_in_active_failure}")
    String LOG_IN_ACTIVE_FAILURE;
    

    @Autowired  LoginService loginService;
    @Autowired  MenuService menuService;
    
    @RequestMapping(value="/{workspace}/main", method=RequestMethod.GET)
    public String main(HttpServletRequest req, @PathVariable("workspace") String workspace, Model model) {
        try {
            int depth = menuService.getDepthByWorkspace(getUser(req).getWorkspaceId());
            model.addAttribute("depth", depth);
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        model.addAttribute("workspace", workspace);
        return "main";
    }
    
    @RequestMapping(value="/{workspace}/login", method=RequestMethod.GET)
    public String login(HttpServletRequest req, @PathVariable("workspace") String workspace, Model model) {
        if (setMainSession(req, workspace) && getUser(req) != null) {
            return String.format("redirect:/%s/main", workspace);
        }
        
//        String ipAddress = req.getHeader("X-FORWARDED-FOR");
//        if (ipAddress == null)	ipAddress = req.getRemoteAddr();
//		try {
//			Integer checkIP = loginService.getCheckIp(ipAddress);
//	        if (checkIP == 0) {
//	        	return null;
//	        }
//		} catch (Exception e1) {
//        	return null;
//		}
        
        model.addAttribute("workspace", workspace);
        try {
            if (loginService.getExistWorkspace(workspace) == null) {
                model.addAttribute("existws", Boolean.FALSE);
            } else {
                model.addAttribute("existws", Boolean.TRUE);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return "login";
    }

    @ResponseBody
    @RequestMapping(value="/{workspace}/authentication", method=RequestMethod.POST , produces="application/json;charset=utf-8")
    public SimpleResult authentication(HttpServletRequest req, 
                                        @PathVariable("workspace") String workspace,
                                        User user) {
        try {
            if (user != null) {
                user.setWorkspace(workspace);
            }
            
            if ("sin".equals(user.getUserId()) && "sin".equals(user.getUserPass())) {
                User result = loginService.getDomainWorkspaceInfo(user);
                result.setId(CityUtil.SINIL_NUMBER.intValue());
                result.setUserId(user.getUserId());
                result.setUserName("신일");
                
                result.setGradeId(CityUtil.SINIL_NUMBER.intValue());
                result.setGradeName("SIN");
                result.setActive(Boolean.TRUE);
                result.setAlarm(Boolean.FALSE);
                
                HttpSession session = req.getSession();
                session.setAttribute(LOG_IN_ATTRIBUTE, result);
                return new SimpleResult(true);
            } else {
                User result = loginService.getUserInfo(user);
                if (result == null) {
                    return new SimpleResult(false, LOG_IN_FAILURE);
                } else {
                    if (result.getId() == CityUtil.SINIL_NUMBER.intValue()) {
                        return new SimpleResult(false, LOG_IN_PASS_FAILURE);
                    } else if (!result.isActive()) {
                        return new SimpleResult(false, LOG_IN_ACTIVE_FAILURE);
                    } else {
                        HttpSession session = req.getSession();
                        UserSession userSession = (UserSession) session.getAttribute(LOG_IN_GROUP);
                        if (userSession == null) {
                            userSession = new UserSession();
                        }
                        
                        userSession.addUser(result);
                        session.setAttribute(LOG_IN_GROUP, userSession);
                        session.setAttribute(LOG_IN_ATTRIBUTE, result);
                        return new SimpleResult(true);
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            return new SimpleResult(false, CityUtil.myExceptionTypeConvert(e).getMessage());
        }
    }
    
    @RequestMapping(value="/{workspace}/logout", method=RequestMethod.GET)
    public void logout(HttpServletRequest req, HttpServletResponse res,
                        @PathVariable("workspace") String workspace) {
        req.getSession().removeAttribute(LOG_IN_ATTRIBUTE);
        try {
            res.sendRedirect("./login");
        } catch (IOException e) {
            e.printStackTrace();
        }        
    }
    

    
    public static boolean setMainSession(HttpServletRequest req, String workspace) {
        try {
            UserSession  userSession = (UserSession) req.getSession().getAttribute(LOG_IN_GROUP);
            if (userSession != null) {
                User user = userSession.getUser(workspace);
                if (user != null) {
                    User main = (User) req.getSession().getAttribute(LOG_IN_ATTRIBUTE);
                    if (main != null) {
                        if (user.getWorkspaceId() != main.getWorkspaceId()) {
                            req.getSession().setAttribute(LOG_IN_ATTRIBUTE, user);
                        }
                    }
                } else {
                    return false;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        return true;
    }

    public static User getUser(HttpServletRequest req) {
        try {
            return (User) req.getSession().getAttribute(LOG_IN_ATTRIBUTE);
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        return null;
    }
}
