package city.login.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import city.dao.mapper.UserMapper;
import city.domain.User;

@Service("loginService")
public class LoginService {
    
    @Autowired
    private UserMapper userMapper;
    
    
    public User getUserInfo(User user) throws Exception {
        return userMapper.getUserInfo(user);
    }
    
    
    public Integer getExistWorkspace(String workspace) throws Exception {
        return userMapper.getExistWorkspace(workspace);
    }
    
    
    public User getDomainWorkspaceInfo(User user) throws Exception {
        return userMapper.getDomainWorkspaceInfo(user);
    }
    
    
    public Integer getCheckIp(String ip) throws Exception {
    	return userMapper.getCheckIp(ip);
    }
}
