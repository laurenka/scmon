package city.login.service;

import java.util.ArrayList;
import java.util.List;

import city.domain.User;

public class UserSession {
    private List<User> list = null;

    public List<User> getList() {
        return list;
    }
    public void setList(List<User> list) {
        this.list = list;
    }
    
    public void addUser(User user) throws Exception {
        if (list == null) {
            list = new ArrayList<>();
        }
        
        if (!isExist(user)) {
            list.add(user);
        }
    }
    
    public User getUser(String workspace) throws Exception {
        if (list == null) return null;
        
        for(User ur : list) {
            if (isEquals(ur.getWorkspace(), workspace)) {
                return ur;
            }
        }
        
        return null;
    }
    
    public boolean isExist(User user) throws Exception {
        if (list == null) return false;
        
        for(User ur : list) {
            if (isEquals(ur.getWorkspace(), user.getWorkspace())
                    && ur.getId() == user.getId()) {
                return true;
            }
        }
        
        return false;
    }
    
    boolean isEquals(String str1, String str2) {
        if (str1 == null || str2 == null)   return false;
        
        if (str1.toUpperCase().equals(str2.toUpperCase())) {
            return true;
        }
        
        return false;
    }
}
