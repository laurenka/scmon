

/**
 *
 */

    function deleteEq() {
        swalLoading(false);
        swal({
            title : '삭제 하시겠습니까?',
            text: '통계/유지보수/제어정보/생산정보/계측정보/성과기준정보\r\n모두 삭제됩니다.',
            showCancelButton : true,
            confirmButtonColor : '#DD6B55',
            confirmButtonText : '예',
            cancelButtonText : '취소',
            closeOnConfirm : false,
            allowEscapeKey: false,
            allowOutsideClick: false,
            id: 'input'
        }, function(isConfirm) {
            if (isConfirm) {
                swalLoading(true);
                setTimeout(function() {
                    deleteEqAction();
                }, 200);
            } else {
                swalLoading(false);
            }
            
        }, function() {
        });
    }

    function deleteEqAction() {
        var form = {
            id:document.editForm.id.value,
            moduleId:document.editForm.module.value
        };
        
        myPostAjaxNoAlert(deleteEquipmentUrl, form, function(response) {
            $('#editModal').modal("toggle");
            if (response.result) {
                swal("삭제에 성공하였습니다!");
            } else {
                swal("삭제에 실패했습니다!");
            }
            refreshList();
            swalLoading(false);
        });
    }
    
    
    function deleteLt() {
        swalLoading(false);
        swal({
            title : '삭제 하시겠습니까?',
            text: '설비/통계/유지보수/제어정보/생산정보/계측정보/성과기준정보\r\n모두 삭제됩니다.',
            showCancelButton : true,
            confirmButtonColor : '#DD6B55',
            confirmButtonText : '예',
            cancelButtonText : '취소',
            closeOnConfirm : false,
            allowEscapeKey: false,
            allowOutsideClick: false,
            id: 'input'
        }, function(isConfirm) {
            if (isConfirm) {
                swalLoading(true);
                setTimeout(function() {
                    deleteLtAction();
                }, 200);
            } else {
                swalLoading(false);
            }
            
        }, function() {
        });
    }
    
    function deleteLtAction() {
        var form = {
            id:document.locationForm.id.value,
            type:document.locationForm.type.value
        };
        
        myPostAjaxNoAlert(deleteLocationUrl, form, function(response) {
            $('#editModal').modal("toggle");
            if (response.result) {
                swal("삭제에 성공하였습니다!");
            } else {
                swal("삭제에 실패했습니다!");
            }
            refreshList();
            swalLoading(false);
        });
    }
    
    

    
    
    function deletePt() {
        swalLoading(false);
        swal({
            title : '삭제 하시겠습니까?',
            text: '생산품/생산품 엑셀 입력\r\n모두 삭제됩니다.',
            showCancelButton : true,
            confirmButtonColor : '#DD6B55',
            confirmButtonText : '예',
            cancelButtonText : '취소',
            closeOnConfirm : false,
            allowEscapeKey: false,
            allowOutsideClick: false,
            id: 'input'
        }, function(isConfirm) {
            if (isConfirm) {
                swalLoading(true);
                setTimeout(function() {
                    deletePtAction();
                }, 200);
            } else {
                swalLoading(false);
            }
            
        }, function() {
        });
    }
    
    function deletePtAction() {
        var form = {
            id:document.productionForm.id.value,
            typeId:document.productionForm.category.value
        };
        
        myPostAjaxNoAlert(deleteProductionUrl, form, function(response) {
            $('#editModal').modal("toggle");
            if (response.result) {
                swal("삭제에 성공하였습니다!");
            } else {
                swal("삭제에 실패했습니다!");
            }
            treeLoad();
            refreshList();
            swalLoading(false);
        });
    }