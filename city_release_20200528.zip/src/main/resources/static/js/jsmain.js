

/**
 *
 */
$(document).ready(function() {
    myPostAjaxNoAlert(contextPath + "/getMenu", null, function(response) {
        createNavigation({
            id: "side-menu",
            userIdTarget: "textID",
            userNameTarger: "userName",
            siteComboId: "siteSelect",
            data: response.data
        });

        var mainMenuSearch = "#" + "scDashboard";
        $(mainMenuSearch).addClass("active");
        collaseMenu();
        $(mainMenuSearch).click();
    });
    myPostAjaxNoAlert(contextPath + "/getModuleMenu", null, function(response) {
        if (response.data) {
            if (response.data.qm) {
                $.each(response.data.qm, function( index, value ) {
                    if (value.id*1 == 1) {
                        $("#iconCooling").addClass("active");
                    } else if (value.id*1 == 2) {
                        $("#iconLighting").addClass("active");
                    } else if (value.id == 3) {
                        $("#iconCompressor").addClass("active");
                    } else if (value.id == 4) {
                        $("#iconHeating").addClass("active");
                    } else if (value.id == 5) {
                        $("#iconBoiler").addClass("active");
                    } else if (value.id == 6) {
                        $("#iconVentilating").addClass("active");
                    } else if (value.id == 7) {
                        $("#iconFacility").addClass("active");
                    } else if (value.id == 8) {
                        $("#iconEguage").addClass("active");
                    } else if (value.id == 9) {
                        $("#iconEss").addClass("active");
                    }
                });
            }
        }
    });
    /**
     * Intercept key event
     * 8 : backspace
     * 116 : F5(refresh)
     * */
    $(window).on("keydown", function(e) {
        if (e.keyCode == 8) {
            if (e.target.nodeName != "INPUT" && e.target.nodeName != "TEXTAREA") {

                var back = $(".modal-backdrop");
                if (back.length > 0) {
                    $(".modal").modal("hide");
                } else {
                    // remove last stack;
                    var lastPage = applicationPageStack.pop();
                    if (lastPage) {
                        loadLastNavigation();
                    }
                }
                e.preventDefault();
            }
        } else if (e.keyCode == 116) {
            $(".modal").modal("hide");
            $(".modal-backdrop").remove();
            e.preventDefault();
            loadLastNavigation();
        }
    });
    $(document).ajaxStart(function() {
        Pace.restart();
    });

    // date picker
    $.fn.datepicker.dates['en'] = {
        days: ["일요일", "월요일", "화요일", "수요일", "목요일", "금요일", "토요일"],
        daysShort: ["일요일", "월요일", "화요일", "수요일", "목요일", "금요일", "토요일"],
        daysMin: ["일", "월", "화", "수", "목", "금", "토"],
        months: ["1월", "2월", "3월", "4월", "5월", "6월", "7월", "8월", "9월", "10월", "11월", "12월"],
        monthsShort: ["1월", "2월", "3월", "4월", "5월", "6월", "7월", "8월", "9월", "10월", "11월", "12월"],
        today: "오늘",
        clear: "취소",
        format: "yyyy-mm-dd",
        titleFormat: "yyyy mm", /* Leverages same syntax as 'format' */
        weekStart: 0
    };

    $(".alertBar").off("click").on("click", function(){
        showAlarmList();
    });

    //startAlarm();
});
var emptyFlag = true;
function startAlarm() {
    $('.alertBar').slick({
        autoplay: true,
        autoplaySpeed: 3000,
        dots: false,
        infinite: true,
        speed: 300,
        slide: 'div',
        cssEase: 'linear',
        vertical: true,
        pauseOnFocus: false,
        pauseOnHover: false,
        arrows: false
    });
    $('.alertBar').on('beforeChange', function(event, slick, currentSlide, nextSlide){
        if (slick.slideCount == 0) {
            $("#defaultAlarm").remove();
            $("#defaultAlarm2").remove();
            defaultAlertBar();
        }
    });
    //defaultAlertBar();
    $('.alertBar').slick('slickPlay');
    
    //getAlarm();
}
function defaultAlertBar() {
    var str = "<div id='defaultAlarm' class='alarm-item'>";
        str += "<h3>최근 발생한 알람이 존재 하지 않습니다.</h3>";
        str += "</div>";
    $('.alertBar').slick('slickAdd', str);
    var str2 = "<div id='defaultAlarm2' class='alarm-item'>";
        str2 += "<h3>최근 발생한 알람이 존재 하지 않습니다.</h3>";
        str2 += "</div>";
    $('.alertBar').slick('slickAdd', str2);
}
var lastId = -1;
function getAlarm() {
    myPostAjaxNoAlert(contextPath + "alarm/getAlarmList", {id: lastId, confirm: 0, page: 0, limit: 10}, function(response) {
        if (response.data) {
            makeAlertBar(response.data);
        }
    });
    
    setTimeout(getAlarm, 60000);
}

function makeAlertBar(alarms) {
    if (alarms.length != 0) {
        var defaultIndex = $("#defaultAlarm2").attr("data-slick-index");
        if (defaultIndex) {
            $("#defaultAlarm").remove();
            $("#defaultAlarm2").remove();
        }
        
        for (var i = 0; i < alarms.length; i++) {
            var alarm = alarms[i];
            var item = $("#" + alarm.id);
            if (item.length == 0) {
                if (alarm.id*1 > lastId*1) {
                    lastId = alarm.id;
                }
                var str = "<div id='slickAlarm" + alarm.id + "' class='alarm-item'>";
                     str += "<h3>" + alarm.date + "</h3>";
                     str += "<h3>" + alarm.alarmType + "</h3>";
                     str += "<h3>" + alarm.alarmContent + "</h3>";
                     str += "<h3>알람 발생</h3>";
                     str += "</div>";
                $('.alertBar').slick('slickAdd', str);
            }
        }
    } else {
        if (emptyFlag) {
            defaultAlertBar();
        }
    }
    
    emptyFlag = false;
    $('.alertBar').slick('slickPlay');
}

// Get Alarm list from server
function showAlarmList() {
    var page = 1;
    var limit = 10;

    $("#alarmModal").modal("toggle");
    loadAlarmList(page, limit);
}

function loadAlarmList(page, limit) {
    if (!limit) {
        limit = 10;
    }
  
    myPostAjaxNoAlert(contextPath + "alarm/getAlarmList", {id: -1, confirm: -1, page: page, limit: limit}, function(response) {
        if (response.data) {
            createTable({
                id: "alarmList",
                headColumn: ["", "발생일시", "알람 유형", "알람 내용", "조치 상태"],
                headColumnSize: ["60px", "130px", "120px", 1, "80px"],
                dataColumn: [{
                    name: "id",
                    align: "center"
                },{
                    name: "date",
                    align: "center"
                },{
                    name: "alarmType",
                    align: "center"
                },{
                    name: "alarmContentThumb",
                    align: "center"
                },{
                    name: "confirmed",
                    align: "center",
                    convert: function(value) {
                        return (value == 1)? "확인":"미확인";
                    }
                }],
                data: response.data,
                pagable: true,
                listeners: [{
                    event: "click",
                    target: "#alarmList tbody tr",
                    handler: function(e) {
                        $("#alarmModal").modal("hide");
                        $("#alarmEditModal").modal("toggle");
                        $("#alarmEditModal").off("hide.bs.modal").on("hide.bs.modal", function() {
                            $("#alarmModal").modal("toggle");
                        });
                        var form = document.alarmForm;
                        var data = e.currentTarget.data;
                        for (var name in data) {
                            var field = form[name];
                            if (field) {
                                field.value = data[name];
                            }
                        }
                        if (data["alarmContent"])
                        $("#alarmContentDiv").html(data["alarmContent"]);
                        
                        var confirmUser = form.confirmUser.value;
                        if (confirmUser == "") {
                            form.confirmUser.value = $("#userName").html();
                            $(".alarm-btn-1").show();
                            $(".alarm-btn-2").hide();
                            $("#confirmMessage").removeAttr("disabled", "disabled");
                        } else {
                            $(".alarm-btn-1").hide();
                            $(".alarm-btn-2").show();
                            $("#confirmMessage").attr("disabled", "disabled");
                        }
                        form.confirmedText.value = (data.confirmed == 1)? "확인":"미확인";
                    }
                }],
                load: loadAlarmList
            });
        }
    });
}
/**
 * Navigation page movement stack
 * */
var applicationPageStack = new Array();
/**
 * Change last page
 * */
function loadLastNavigation() {
    var url = applicationPageStack[applicationPageStack.length-1];
    changeNavigation(url);
};
/**
 * Load url
 * */
function loadNavigation(url) {
	chart = undefined;
    // add page movement only load
    applicationPageStack.push(url);
    changeNavigation(url);
}
/**
 * Change page
 * */
var perMinuteTimeInterval;
var isDashboardOn = false;
var isDisbutionDiagramOn = false;
function changeNavigation(url) {
    isDashboardOn = (url == 'scDashboard') ? true : false;
    isDisbutionDiagramOn = (url == 'distributiondiagram') ? true : false;
	clearInterval(perMinuteTimeInterval);
	
    $("#mainContent").load(contextPath + url, function(responseText, textStatus, jqXHR) {
        if (jqXHR.status == "500") {
            applicationPageStack.pop();
            $("#mainContent").load("./500");
        } else if (jqXHR.status == "404") {
            applicationPageStack.pop();
            $("#mainContent").load("./404");
        } else if (jqXHR.status == "901") {
            location.href="./login";
        }
    });
}

/** 경고 알림 확인 업데이트 */
function updateAlarm() {
    var form = document.alarmForm;
    var data = {
            id: form.id.value,
            confirmed: form.confirmed.value,
            confirmMessage: form.confirmMessage.value,
    };
    
    confirmAjax(contextPath + "alarm/update", "확인", "확인하시겠습니까?", data, function() {
        $("#alarmEditModal").off("hide.bs.modal");
        $("#alarmEditModal").modal("hide");
        showAlarmList();
        
        var index = $("#slickAlarm"+form.id.value).attr("data-slick-index");
        if (form.confirmed.value == 1) {
            $('.alertBar').slick('slickRemove', index);
            var totalSlides = $('.alertBar')[0].slick.slideCount;
            if (totalSlides == 0) {
                defaultAlertBar();
                $('.alertBar').slick('slickPlay');
            }
        } else {
            var defaultIndex = $("#defaultAlarm2").attr("data-slick-index");
            if (defaultIndex) {
                $("#defaultAlarm").remove();
                $("#defaultAlarm2").remove();
            }
            
            if (index == undefined) {
                var str = "<div id='slickAlarm" + form.id.value + "' class='alarm-item'>";
                str += "<h3>" + form.date.value + "</h3>";
                str += "<h3>" + form.alarmType.value + "</h3>";
                str += "<h3>" + form.alarmContent.value + "</h3>";
                str += "<h3>알람 발생</h3>";
                str += "</div>";
                $('.alertBar').slick('slickAdd', str);
            }
        }
    });
}

String.prototype.string = function(len){var s = '', i = 0; while (i++ < len) { s += this; } return s;};
String.prototype.zf = function(len){return "0".string(len - this.length) + this;};
Number.prototype.zf = function(len){return this.toString().zf(len);};
Date.prototype.format = function(f) {
    if (!this.valueOf()) return " ";

    var weekName = ["일요일", "월요일", "화요일", "수요일", "목요일", "금요일", "토요일"];
    var d = this;

    return f.replace(/(yyyy|yy|MM|dd|E|hh|mm|ss|a\/p)/gi, function($1) {
        switch ($1) {
            case "yyyy": return d.getFullYear();
            case "yy": return (d.getFullYear() % 1000).zf(2);
            case "MM": return (d.getMonth() + 1).zf(2);
            case "dd": return d.getDate().zf(2);
            case "E": return weekName[d.getDay()];
            case "HH": return d.getHours().zf(2);
            case "hh": return ((h = d.getHours() % 12) ? h : 12).zf(2);
            case "mm": return d.getMinutes().zf(2);
            case "ss": return d.getSeconds().zf(2);
            case "a/p": return d.getHours() < 12 ? "오전" : "오후";
            default: return $1;
        }
    });
};

function clickNaviIcon(icon, url, idModule) {
	chart = undefined;
    if (icon.className) {
        applicationPageStack.push(url);
        $("#mainContent").load("./"+url, function(responseText, textStatus, jqXHR) {
            document.getElementById("moduleSelect").value = idModule;
            search();

            if (jqXHR.status == "500") {
                applicationPageStack.pop();
                $("#mainContent").load("./500");
            } else if (jqXHR.status == "404") {
                applicationPageStack.pop();
                $("#mainContent").load("./404");
            } else if (jqXHR.status == "901") {
                location.href="./login"
            }
        });
    }
}

/**
 * @detail 해당 기간의 툴팁 타이틀을 제공한다.
 * @param {number} period periodType
 * @param {string} title
 * @return {string} newTitle
 * */
function getPeriodTooltipTitle(period, title) {
	var newTitle = "";
	if (period) {
		if (period == 0) {
			// 순시
			newTitle = title;
		} else if (period == 1) {
			// 일간
			if (title.split(":").length < 2) {
				newTitle = title + "시";	
			} else {
				newTitle = title;
			}
		} else if (period == 2) {
			// 주간
			var split = title.split("-");			
			if (split.length == 2) {
				newTitle += split[0] + "년 ";
				newTitle += split[1] + "주";
			} else {
				newTitle = title + "주";
			}    				
		} else if (period == 3) {
			// 월간   				
			var split = title.split("-");
			if (split.length == 3) {
				newTitle += split[0] + "년 ";
				newTitle += split[1] + "월 ";  					
				newTitle += split[2] + "일";	
			} else {
				newTitle = title + "일";   					
			}                				
		} else if (period == 4) {
			// 년간
			var split = title.split("-");
			if (split.length == 2) {
				newTitle += split[0] + "년 ";
				newTitle += split[1] + "월";
			} else {   					
				newTitle = title + "월";
			}    				
		}   			
	} else {
		newTitle = title;
	}
	return newTitle;
}






//<![CDATA[
var bol1 = false;
var bol2 = false;
function openLoading(vc) {
    if (bol1 || bol2) {
        return;
    }
    
    if (vc == 1)        {bol1 = true;}
    else if (vc == 2)   {bol1 = true; bol2 = true;}
    if (bol1 || bol2) {
        swalLoading(false);
        swal({
            title: '로딩중',
            closeOnConfirm : false,
            allowEscapeKey: false,
            allowOutsideClick: false
        });
        swalLoading(true);
    }
}
function closeLoading(vc) {
    if (vc == 1)        {bol1 = false;}
    else if (vc == 2)   {bol2 = false};
    if (!bol1 && !bol2) {
        swalLoading(false);
        $(".confirm").click();
    }
}



var delay = (function() {
    var timer = 0;
    return function(callback, ms){
        clearTimeout(timer);
        timer = setTimeout(callback, ms);
    }
})();



var chart=undefined;
function korResize() {
	if ($(".wrapper-content").width() > 1200) {
		$("#left_main").css("width", "50%")
		$("#right_main").css("width", "50%")
	} else {
		$("#left_main").css("width", "100%")
		$("#right_main").css("width", "100%")
	}
	
	if ($("#right_main")) {
		if ($("#right_main").width() > 880) {
			$(".rct_st2").css("font-size", "9pt");
		} else if ($("#right_main").width() > 650) {
			$(".rct_st2").css("font-size", "7pt");
		} else {
			$(".rct_st2").css("font-size", "5pt");
		}
	}
	if (chart) {
		chart.resize();
	}
}
//]]>