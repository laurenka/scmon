﻿

/**
 * Menu
 */
/* create menu item */
function createNavigation(option) {
    option = option || {
        id: "",
        userIdTarget: "",
        userNameTarger: "",
        siteComboId: "",
        data: {}
    };

    var container = document.getElementById(option.id);

    // user info
    var userId = document.getElementById(option.userIdTarget);
    userId.innerHTML = option.data.user.id;
    var userName = document.getElementById(option.userNameTarger);
    userName.innerHTML = option.data.user.userName;

    // menu
    var records = option.data.data;
    for (var i = 0; i < records.length; i++) {

        var record = records[i];
        var item = record.item;
        // list item
        var menuItem = appendChild(container, "li");
        menuItem.id = item.menuId;
        // link
        var menuLink = appendChild(menuItem, "a");
        if (item.href != "" && item.href != null) {
            menuItem.data = {};
            menuItem.data.href = item.href;
            menuItem.addEventListener("click", function(e) {
                loadNavigation(e.currentTarget.data.href);
            });
        }
        // icon
        var icon = appendChild(menuLink, "i", "fa fa-th-large " + item.icon);
        // label and arrow
        appendChild(menuLink, "span", "nav-label", item.name);
        appendChild(menuLink, "span", "fa arrow");

        // sub menu list
        var subMenuList = record.children;
        if (subMenuList != null && subMenuList.length > 0) {
            var subList = appendChild(menuItem,  "ul", "nav nav-second-level collapse");
            // sub menu
            for (var j = 0; j < subMenuList.length; j++) {
                var subRecord = subMenuList[j];
                var subMenuItem = appendChild(subList, "li");
                subMenuItem.id = subRecord.menuId;
                var subLink = appendChild(subMenuItem, "a", null, subRecord.name);
                subMenuItem.data = {};
                subMenuItem.data.href = subRecord.href;
                //console.log(subRecord.href);
                subMenuItem.addEventListener("click", function(e) {
                    loadNavigation(e.currentTarget.data.href);
                    console.log(e.currentTarget.data.href);
                    $(".nav-second-level li.active").removeClass("active");
                    $(e.currentTarget).addClass("active");
                });
            }
        }
    }
}
/**
 * Table
 */
/* create table */
function createTable(option) {
    option = option || {
        id: "",
        headColumn: [],
        headColumnSize: [],
        alignCenterColumn: [],
        data: {},
        dataColumn: [],
        load: false,
        pagable: false,
        listeners: [],
        firstHandler: function() {},
        pageHandler: function() {},
        prevHandler: function() {},
        nextHandler: function() {},
        lastHandler: function() {}
    };
    var container = document.getElementById(option.id);
    container.innerHTML = "";
    // create table
    // order row coloring, border, hover action
    var table = appendChild(container,"table", "table table-striped table-bordered table-hover");
    table.id = option.id + "Table";
    
    // table head
    var head = appendChild(table, "thead");
    var headTr = appendChild(head, "tr", "app-tr");

    var alignCenterTdIndexes = new Array();

    for (var i = 0; i < option.headColumn.length; i++) {
        var th = appendChild(headTr, "th", "th-" + i, option.headColumn[i]);
        th.style.textAlign = 'center';
        if (option.headColumn[i] === "splitter") {
            $(th).html("");
            $(th).addClass("grid-splitter");
            continue;
        }
        // column size
        var columnSize = option.headColumnSize[i];
        if (typeof columnSize === 'string') {
            // 문자열

            th.style.maxWidth = option.headColumnSize[i];
            th.style.minWidth = option.headColumnSize[i];
        } else {
            // 숫자
            if (i < option.headColumnSize.length) {
                th.style.flex = columnSize;
            } else {
                th.style.flex = 1;
            }
        }
    }

    if(option.alignCenterColumn) {
        for (var i = 0; i < option.dataColumn.length; i++) {
            var checkColumnName = typeof option.dataColumn[i] === "string" ? option.dataColumn[i] : option.dataColumn[i].name;
            if (option.alignCenterColumn.indexOf(checkColumnName) > -1) {
                alignCenterTdIndexes.push(i);
            }
        }
    }

    // table body
    var body = appendChild(table, "tbody");
    var records = option.data.data;

    if (records != null) {
        for (var i = 0; i < records.length; i++) {
            var record = records[i];
            if (record != null) {
                // tr
                var tr = appendChild(body, "tr", "app-tr");
                tr.data = record;
                tr.id = "tr"+record.id;

                // td
                for (var j = 0; j < option.headColumn.length; j++) {
                    var td = appendChild(tr, "td", "td-"+j);
                    if (alignCenterTdIndexes.indexOf(j) > -1) {
                        td.style.justifyContent = 'center';
                    }
                    if (j < option.dataColumn.length) {
                        var column = option.dataColumn[j];
                        if (option.headColumn[j] == "splitter") {
                            $(td).addClass("grid-splitter");
                            continue;
                        }
                        if (typeof column === "string") {
                            var innerHTML = "";
                            var splitColumn = column.split(".");
                            if (splitColumn.length > 1) {
                                var parentcolumn = record[splitColumn[0]];
                                if (parentcolumn) {
                                    innerHTML = parentcolumn[splitColumn[1]];
                                }
                            } else {
                                innerHTML = record[column];
                            }
                            td.innerHTML = innerHTML;
                        } else if (column instanceof Object) {
                            var innerHTML = "";
                            var splitColumn = column.name.split(".");
                            if (splitColumn.length > 1) {
                                var parentcolumn = record[splitColumn[0]];
                                if (parentcolumn) {
                                    innerHTML = parentcolumn[splitColumn[1]];
                                }
                            } else {
                                innerHTML = record[column.name];
                            }
                            var convert = column.convert;
                            if (convert) {
                                td.innerHTML = convert(innerHTML, record, option.data, j);
                            } else {
                                td.innerHTML = innerHTML;
                            }
                            if (column.align) {
                                if (column.align == "right") {
                                    td.style.justifyContent = 'flex-end';
                                } else if (column.align == "center") {
                                    td.style.justifyContent = 'center';
                                } else {
                                    td.style.justifyContent = 'flex-start';
                                }
                            }
                        }
                    }
                    if (typeof option.headColumnSize[j] === 'string') {
                        td.style.maxWidth = option.headColumnSize[j];
                        td.style.minWidth = option.headColumnSize[j];
                    } else {
                        if (j < option.headColumnSize.length) {
                            td.style.flex = option.headColumnSize[j];
                        } else {
                            td.style.flex = 1;
                        }
                    }
                }
            }
        }
    }

    if (option.additoryTag) {
        var additory = option.additoryTag;
        var rowDiv = appendChild(container, "div", "ibox-tools");
        rowDiv.style.float = "right";
        var buttonTag = appendChild(rowDiv, additory.tag, additory.clazz);
        buttonTag.innerHTML = additory.innerHTML;
        buttonTag.setAttribute("onclick", additory.onclick);
    }

    // paging bar
    if (option.pagable) {
        var div = appendChild(container, "div", "row");
        var data = option.data;

        // info
        var infoContainer = appendChild(div, "div", "col-sm-5");
        var info = appendChild(infoContainer, "div", "dataTables_info");
        info.innerHTML = "Showing " + ((data.start)? data.start:"0") + " to "
                + ((data.end)? data.end:"0") + " of "
                + ((data.totalSize)? data.totalSize:"0") + " entries";

        if (data.totalPage > 0) {
            // page button
            var pageContainer = appendChild(div, "div", "col-sm-12");
                pageContainer.align = "center";
            var buttonContainer = appendChild(pageContainer, "div", "dataTables_paginate paging_simple_numbers");
            var ul = appendChild(buttonContainer, "ul", "pagination");

            // first button
            var first = appendChild(ul, "li", "paginate_button previous");
            appendChild(first, "a", null, "<<");
            if (data.totalPage == 1) {
                first.disabled = "disabled";
            }
            //prev button
            var prev = appendChild(ul, "li", "paginate_button previous");
            appendChild(prev, "a", null, "<");
            if (data.totalPage == 1) {
                prev.disabled = "disabled";
            }

            var load = option.load;
            // number button
            var pageLimit = 10;
            var firstPage = Math.floor((data.page-1)/10)*pageLimit + 1;
            for (var i = firstPage; i < firstPage + pageLimit; i++) {
                if (i > data.totalPage) {
                    break;
                }
                var numberLi = appendChild(ul, "li");
                if (data.page == i) {
                    numberLi.className = "paginate_button normal active";
                } else {
                    numberLi.className = "paginate_button normal";
                }
                var link = appendChild(numberLi, "a", null, i);
                if (!load) {
                    link.addEventListener("click", function() {
                        if (option.pageHandler) {
                            option.pageHandler(this.innerHTML);
                        } else if (loadPage) {
                            loadPage(this.innerHTML);
                        } else {
                        }
                    });
                }
            }

            // next button
            var next = appendChild(ul, "li", "paginate_button next");
            appendChild(next, "a", null, ">");
            if (data.totalPage == 1) {
                next.disabled = "disabled";
            }
            // last button
            var last = appendChild(ul, "li", "paginate_button next");
            appendChild(last, "a", null, ">>");
            if (data.totalPage == 1) {
                last.disabled = "disabled";
            }
            if (load) {
                first.addEventListener("click", function(){
                    goFirstPage(option.id, load);
                });
                prev.addEventListener("click", function(){
                    prevPage(option.id, load);
                });

                $("#" + option.id + " .pagination .paginate_button.normal").on("click", function(e) {
                    var page = e.target.innerHTML;
                    load(page);
                });

                next.addEventListener("click", function(){
                    nextPage(option.id, load, data.totalPage);
                });
                last.addEventListener("click", function(){
                    lastPage(option.id, load, data.totalPage);
                });
            } else {
                first.addEventListener("click", function(){
                    if (option.firstHandler) {
                        option.firstHandler();
                    } else if (goFirstPage) {
                        goFirstPage();
                    } else {
                    }
                });
                prev.addEventListener("click", function(){
                    if (option.prevHandler) {
                        option.prevHandler();
                    } else if (prevPage) {
                        prevPage();
                    } else {
                    }
                });

                next.addEventListener("click", function(){
                    if (option.nextHandler) {
                        option.nextHandler();
                    } else if (nextPage) {
                        nextPage(option.id, null, data.totalPage);
                    } else {
                    }
                });
                last.addEventListener("click", function(){
                    if (option.lastHandler) {
                        option.lastHandler();
                    } else if (lastPage) {
                        lastPage(option.id, null, data.totalPage);
                    } else {
                    }
                });
            }
        }
    }

    // listener
    for (var i = 0; i < option.listeners.length; i++) {
        var listener = option.listeners[i];
        $(listener.target).off(listener.event).on(listener.event, listener.handler);
    }
}

function appendChild(container, tagName, className, innerHTML, value) {
    var child = document.createElement(tagName);
    container.appendChild(child);
    if (className) {
        child.className = className;
    }
    if (innerHTML) {
        child.innerHTML = innerHTML;
    }
    if (value || value == 0) {
        child.value = value;
    }
    return child;
}

/** EMS */
var EMS = {
        createElement: function(opt, container) {
            var defaultOpt = {
                    targetId: "",
                    items: []
            }
            // check target
            var targetId = opt.targetId;
            if (targetId) {
                container = document.getElementById(targetId);
            }

            if (container) {
                // item
                var item = document.createElement(opt.tag);
                container.appendChild(item);
                // property
                for (var field in opt) {
                    item[field] = opt[field];
                    if (item.style[field] == "") {
                        item.style[field] = opt[field];
                    };
                }

                // layout
                var layout = opt.layout;
                if (layout == "flex") {
                    $(item).addClass("flex-container");
                }

                // listeners
                var listeners = opt.listeners;
                if (listeners instanceof Object) {
                    for (var eventType in listeners) {
                        item.addEventListener(eventType, listeners[eventType]);
                    }
                }

                // child items
                var items = opt.items;
                if (items instanceof Array) {
                    for (var i = 0; i < items.length; i++) {
                        this.createElement(items[i], item);
                    }
                }
            }
        }
};

/**
 * Chart
 * */
function splitDateTime(x) {
    var res = x.split(" ");
    if (res.length == 2) {
        if (res[1] == '00:00')  return res[0];
        else                    return res[1];
    } else {
        return x;
    }
}
function createChart(id, inData, config, type) {
    if (inData.dataset) {
        if (inData.xAxisData) {
            var dataset = inData.dataset;
            var columns = new Array();
            for (var category in dataset) {
                var arr = new Array(category);
                Array.prototype.push.apply(arr, dataset[category]);
                columns.push(arr);
            }
            
            var data = {columns: columns};
            if(type != null) {
            	data['type']=type;
            }
            var axis = {
                x: {
                    type: 'category',
                    categories: inData.xAxisData,
                    tick: {
                        multiline: false,
                        format: function (x) {
                            if (x == 0) {
                                return inData.xAxisData[x];
                            } else {
                                return splitDateTime(inData.xAxisData[x]);
                            }
                        },
                        culling: {
                            max: 24
                        }
                    }
                },
                y: {
                    label: '전체'
                }
            };
            
            if (config && config.leftData) {
//                axes[config.leftData] = "y"
                axis.y.label = config.leftData;
            }
            if (config && config.multipleY) {
                var axes = {};
                axes[config.rightData] = "y2";
                data["axes"] = axes;
                
                axis.y2 = {
                    show: true,
                    label: config.rightData
                };
            }
            var point = {show:false};
            if (config && config.point*1 == 1) {
                point = {show:true};
            } else {
                point = {show:false};
            }
            var opt = {
                bindto: id,
                data: data,
                axis : axis,
                tooltip: {
                    format: {
                        title: function (d) {
                            var title = inData.xAxisData[d];
                            var period = $("select[name=periodType]").val();
                            if (period) {
                                return getPeriodTooltipTitle(period, title);
                            } else {
                                return inData.xAxisData[d]; 
                            }                             
                        },
                        value: function(value, ratio, id, index) {
                            return moneyFormat(value);
                        }
                    }
                },
                point: point
            }
            c3.generate(opt);            
        } else {
            log.error("not found field 'xAxisData' of data");
        }
    } else {
        log.error("not found field 'dataset' of data");
    }
}

//챠트 카테고리에 따른 x축 격자 수
function getAxisTickCount() {
    var form = document.searchForm;
    if (form) {
        var periodType = form.periodType.value;
        if (periodType == 0) {
            // 순시값
            // 시간단위만 표시
            var time = form.time.value.replace(/:/g,"");
            var secondTime = form.secondTime.value.replace(/:/g,"");
            if (secondTime > time) {
                var diff = secondTime - time;
                if (diff >= 100) {
                    return diff/100 + 1;
                } else {
                    return null;
                }
            } else if (secondTime == time) {
                return 25;
            } else if (secondTime < time){
                var diff = time - secondTime;
                if (diff > 100) {
                    return 24 - (diff/100) + 1;
                } else {
                    return null;
                }
            }
        } else {
            return null;
        }
    } else {
        return null;
    }
}

// 챠트 카테고리 문자 줄바꿈
function getAxisTickWidth() {
    var form = document.searchForm;
    if (form) {
        var periodType = form.periodType.value;
        if (periodType == 0) {
            return 35;
        } else if (periodType == 2) {
            return 45;
        } else {
            return null;
        }
    } else {
        return null;
    }
}


function createMeasurementPoint(checKURL, option) {
    option = option || {
        id: "",
        labelSize: 1,
        inputSize: 1,
        selectSize: 1,
        name: "unitCost",
        data: {}
    };
    var container = document.getElementById(option.id);
    container.innerHTML = "";
    var records = option.data.data;
    for (var i = 0; i < records.length; i++ ) {
        var record = records[i];
        var groupWrapper = appendChild(container, "div", "form-group col-sm-12");
        var label = appendChild(groupWrapper, "label", "control-label col-sm-" + option.labelSize);
        // label text
        label.innerHTML = record.typeName;
        //

        // select
        var selectWrapper = appendChild(groupWrapper, "div", "col-sm-" + option.selectSize);
        var select = appendChild(selectWrapper, "select", "form-control");
        select.name = option.name;

        select.dataset.id = record.id;
        select.dataset.usedType = record.useType;
        select.dataset.constant = record.constant;

        appendChild(select, "option", null, "사용안함", 0);
        appendChild(select, "option", null, "상수 데이터", 1);
        appendChild(select, "option", null, "통신 연동", 2);
        appendChild(select, "option", null, "검침 입력", 3);
        appendChild(select, "option", null, "공공데이터", 4);
        select.value = record.useType * 1;
        //

        var inputWrapper = appendChild(groupWrapper, "div", "col-sm-" + option.inputSize);
        var input = appendChild(inputWrapper, "input", "form-control hidden unitText");
        // input custom
        input.disabled = "disabled";
        
        if (record.useType == 4) {
            input.value = '기상청';
        } else {
            input.value = record.ip + ":" + record.port;
        }
        
        // input constant
        var constant = appendChild(inputWrapper, "input", "form-control numerical hidden");
        constant.placeholder = "값 입력";
        constant.name = "constant";
        constant.value = record.constant;

        // 마지막 입력일
        var dateGroup = appendChild(groupWrapper, "div", "input-group col-sm-2 date hidden");
        var dateAddon = appendChild(dateGroup, "span", "input-group-addon");
            appendChild(dateAddon, "i", "fa fa-calendar");
        var dateInput = appendChild(dateGroup, "input", "form-control", null, record.lastUpdateDate);
            dateInput.name = "lastUpdateDate";

        // 마지막 시간
        var timeGroup = appendChild(groupWrapper, "div", "input-group col-sm-2 clockpicker hidden");
            timeGroup.dataset.autoclose="true";
        var timeAddon = appendChild(timeGroup, "span", "input-group-addon");
            appendChild(timeAddon, "i", "fa fa-clock-o");
        var timeInput = appendChild(timeGroup, "input", "form-control", null, record.lastUpdateTime);
            timeInput.name = "lastUpdateTime";

        // 관리번호
        var mgrNoWrapper = appendChild(groupWrapper, "div", "col-sm-4 mgrNoWrapper hidden");
        var mgrNoLabel = appendChild(mgrNoWrapper, "label", "control-label col-sm-3");
        mgrNoLabel.innerHTML = "관리번호";
        var mgrDiv = appendChild(mgrNoWrapper, "div", "col-sm-9");
        var mgrNo = appendChild(mgrDiv, "input", "form-control");
        mgrNo.name = "mgrNo";
        mgrNo.value = record.mgrNo;


        // type
        var typeWrapper = appendChild(groupWrapper, "div", "col-sm-4 typeWrapper hidden");
        var timeLabel = appendChild(typeWrapper, "label", "control-label col-sm-3");
        timeLabel.innerHTML = "관리번호";
        var typeDiv = appendChild(typeWrapper, "div", "col-sm-9");
        var typeNo = appendChild(typeDiv, "input", "form-control");
        typeNo.name = "type";
        typeNo.value = record.type;


        // select event
        $(select).on("change", function (e) {
            var item = e.currentTarget;
            var wrapper = e.currentTarget.parentNode.parentNode;
            var value = e.currentTarget.value;
            var ipPort = wrapper.querySelector("input");
            var constantInput = wrapper.querySelector("input[name=constant]");
            var lastUpdate = wrapper.querySelector(".date");
            var lastTime = wrapper.querySelector(".clockpicker");
            var no = wrapper.querySelector(".mgrNoWrapper");
            if (value == 2) {
                // chaining
                myPostAjaxNoAlert('./system/measurement/checkMeasurementPoint', {id: e.currentTarget.dataset.id}, function(response){
                    swal("알림", "통신 연동이 정상 작동합니다.", "success");
                    $(ipPort).removeClass("hidden");
                    $(constantInput).addClass("hidden");
                    $(no).removeClass("hidden");
                    $(lastUpdate).addClass("hidden");
                    $(lastTime).addClass("hidden");
                }, function() {
                    swal("알림", "통신 연동이 올바르게 작동하지 않습니다.", "error");
                    item.value = 0;
                    $(constantInput).addClass("hidden");
                    $(ipPort).addClass("hidden");
                    $(no).addClass("hidden");
                    $(lastUpdate).addClass("hidden");
                    $(lastTime).addClass("hidden");
                });
            } else if (value == 1) {
                // constant
                $(constantInput).removeClass("hidden");
                $(lastUpdate).addClass("hidden");
                $(lastTime).addClass("hidden");
                $(ipPort).addClass("hidden");
                $(no).addClass("hidden");
            } else if (value == 3) {
                // date and constant
                $(lastUpdate).removeClass("hidden");
                $(lastTime).removeClass("hidden");
                $(constantInput).removeClass("hidden");
                $(ipPort).addClass("hidden");
                $(no).addClass("hidden");
            } else if (value == 4) {
                $(ipPort).removeClass("hidden");
                $(ipPort).addClass("right_title");
            } else {
                $(lastUpdate).addClass("hidden");
                $(lastTime).addClass("hidden");
                $(constantInput).addClass("hidden");
                $(ipPort).addClass("hidden");
                $(no).addClass("hidden");
            }
        });

        if (select.value == 2) {
            // chaining
            $(input).removeClass("hidden");
            $(mgrNoWrapper).removeClass("hidden");
        } else {
            // constant
            $(select).change();
        }
    }

    $(".date").datepicker({
        todayBtn:"linked",
        todayHighlight: true,
        keyboardNavigation: false,
        forceParse: false,
        calendarWeeks: false,
        autoclose: true
    });
    $('.clockpicker').clockpicker();
}

/** nestable */
function makeNestable(id, data, colorArr, iconArr) {
    // container
    var container = document.getElementById(id);
        container.innerHTML = "";
    // wrapper
    var wrapper = appendChild(container, "div", "dd");
        wrapper.id = "nestable";
    var ol = appendChild(wrapper, "ol", "dd-list");
    if (data.length && data.length > 0) {
        for (var i = 0; i < data.length; i++ ) {
            createDDItem(ol, data[i], colorArr, iconArr, 0);
        }
    }
    // collapse all
    $(wrapper).nestable();

    // disable dragable
    $('.dd-item').on("mousedown", function(e) {
        e.preventDefault();
        return false;
    });

    // listener
    $('.dd-item').on("click", function(e) {
        // callapse
        var target = e.target;
        if (target.nodeName == "BUTTON") {
            var ol = e.currentTarget.querySelector("ol");
            if (ol.style.display == "") {
                ol.style.display = "none";
            } else {
                ol.style.display = "";
            }
        }
        return false;
    });
//    $("#nestable").nestable("collapseAll");
}

function createDDItem(container, record, colorArr, iconArr, index) {
    // item
    var recordItem = record.item;
    var item = appendChild(container, "li", "dd-item");
        item.data = recordItem;
    var ddHandle = appendChild(item, "div", "dd-handle");
    var iconSpan = appendChild(ddHandle, "span", "label " + colorArr[index]);
    var icon = appendChild(iconSpan, "i", "fa " + iconArr[index]);
        ddHandle.innerHTML += "&nbsp;&nbsp;&nbsp;";
    var nameSpan = appendChild(ddHandle, "span", null, recordItem.name);
    // subItem
    var children = record.children;
    if (children.length && children.length > 0) {
        var index = index + 1;
        var ol = appendChild(item, "ol", "dd-list");
        for (var i = 0; i < children.length; i++) {
            createDDItem(ol, children[i], colorArr, iconArr, index);
        }
    }
}

function createEquipmentSpecInfo(option) {
    option = option || {
        id: "",
        labelSize: 1,
        inputSize: 1,
        unitDimensionSize: 1,
        data: {}
    };
    var container = document.getElementById(option.id);
    container.innerHTML = "";

    var records = option.data.data;

    if (records.length != 0) {
        for (var i = 0; i < records.length; i++ ) {
            var record = records[i];
            var groupWrapper = appendChild(container, 'div', 'form-group');
            var label = appendChild(groupWrapper, 'label', 'control-label col-sm-' + option.labelSize);
            // label text
            label.innerHTML = record.value;

            var inputWrapper = appendChild(groupWrapper, 'div', 'col-sm-' + option.inputSize);

            var inputItem = appendChild(inputWrapper, 'input', 'form-control'); //option.classAttribute);
            inputItem.setAttribute('type', 'text' );
            var inputItemName='specInfo[' + i + '].specItem';
            inputItem.setAttribute('name', inputItemName);
            inputItem.value = record.specItem;
            $(inputItem).hide();

            if (record.comboValues != null && record.comboValues != '') {
                var comboSpec = appendChild(inputWrapper, 'select', 'form-control ' + record.specItem);
                var comboName = 'specInfo[' + i + '].value';
                comboSpec.setAttribute('name', comboName);
                var comboOptionArray = record.comboValues.split(',');
                var comboOptions = new Array();
                for (var j = 0; comboOptionArray.length > j; j++) {
                    var obj = {};
                    obj['name'] = comboOptionArray[j];
                    comboOptions.push(obj);
                }

                makeComboOpt(comboSpec, comboOptions, 'name', 'name');

            } else {
                var input = appendChild(inputWrapper, 'input', 'form-control');
                input.setAttribute('type', 'text' );
                var inputName='specInfo[' + i + '].value';
                input.setAttribute('name', inputName);
            }

            var unitDimension = appendChild(groupWrapper, 'label', 'control-label col-sm-' + option.unitDimensionSize);
            unitDimension.setAttribute('style', 'text-align: left');
            if (record.unitDimension != 'NULL' && record.unitDimension != null) {
                unitDimension.innerHTML = record.unitDimension;
            }
            
        }
    }
}





function createRunState(id) {
    return '<div id="' + id + '" style="width: 100%;text-align: center;"></div>';
}

function getDateUnitString(type) {
    if (type == 1) {
        return "시간";
    } else if (type == 2) {
        return "일";
    } else if (type == 3) {
        return "개월";
    } else if (type == 4) {
        return "년";
    } else {
        return "";
    }
}

function getProgressBar(value, limit, amount, amountType, addButton) {
    if (value == null) {
        value = 0;
    }
    // <![CDATA[
    var str = "";
    if (amount) {
        str += "<div class='col-sm-3 progress-text'>" + amount + " " + getDateUnitString(amountType) + "</div>";
        str += "<div class='progress progress-sm col-sm-5 app-progress'>";
    } else {
        str += "<div class='progress progress-sm col-sm-8 app-progress'>";
    }
    if (value > limit) {
        str += "<div style='width:" + value + "%;' class='progress-bar progress-bar-danger'></div>";
    } else {
        str += "<div style='width:" + value + "%;' class='progress-bar'></div>";
    }
    str += "</div>" +
    "<div class='progress-text'>" + value + "%</div>";
    // ]]>
    return str;
}

function convertProgressBar(list, index, max) {
    if (list.length > index) {
        var item = list[index];
        if (item.changed == 1) {
            return null;
        } else {
            var percent = item.usedPercent;
            if (percent != null) {
                return getProgressBar(percent, max);
            } else {
                return null;
            }
        }
    } else {
        return null;
    }
}
