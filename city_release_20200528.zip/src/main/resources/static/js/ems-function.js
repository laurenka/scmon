

function allClearForm() {
    $(".has-error").removeClass("has-error");
    $(".hiddenInput").removeAttr("style");
}

function getPriodType(id) {
    if (id == 1) return " 시간";
    if (id == 2) return " 일";
    if (id == 3) return " 월";
    if (id == 4) return " 년";
}


function collaseMenu() {
    $(".metismenu>li").on("click",function(e){

        var el = e.currentTarget;
        var ul = el.querySelector('ul');

        // menu active reset
        $.each($(".metismenu>li.active"),function(index, item) {
            if(item != el) {
                $(item).removeClass("active");
                item.dataset.collapse="false";
            }
        });
        $.each($(".in"),function(index, item) {
            if (item != ul) {
                $(item).removeClass("in");
            }
        });

        $(el).addClass("active");
        // sub menu collapse
        var targetIsUl = false;
        if(ul) {
            var li = null;
            if (e.target.nodeName == "LI") {
                li = ul.querySelector("#" + e.target.id);
            } else if (e.target.nodeName == "A") {
                li = ul.querySelector("#" + e.target.offsetParent.id);
            }
            if (li) targetIsUl = true;
        }
        if(el.dataset.collapse == "true" && !targetIsUl) {
            el.dataset.collapse = "false";
            $(ul).removeClass("in");
        } else {
            el.dataset.collapse = "true";
            $(ul).addClass("in");
        }
    });
    // remove userInfo
    $(".userInfo").off("click");
}
/**
 * form data ajax
 * */
function ajaxFormData(form, url, title, text, callback, alwaysCallBack, bScroll) {
    var fd = new FormData(form);
    $.ajax({
        url: url,
        type: "POST",
        data: fd,
        async: true,
        cache: false,
        contentType: false,
        processData: false,
        success : function( response ) {
            if ( response.result ) {
                mySwal( title + "성공", text, "success", {
                    method : callback,
                    el : response
                })
            } else {
                if (bScroll) {
                    appSweetAlert({
                        title: title + "실패",
                        text: response.message,
                        type: "error",
                        width: "500px",
                        height: "300px"
                    });
                } else {
                    appSweetAlert({
                        title: title + "실패",
                        text: response.message,
                        type: "error",
                        width: "500px"
                    });
                }
                
            }
        },
        error : function ( xhr, textStatus, error) {
            if (xhr.status == 901) {
                location.href = "./logout";
            } else {
                swal( title + "실패", textStatus, "error");
            }
        }
    })
    .always(function() {
        if (alwaysCallBack) {
            alwaysCallBack();
        }
    });
}

/**
 * ajax call
 */
function myPostAjax(url, title, text, data, callback, contentType, failCallback, alwaysCallBack ) {
    myPostAjax(url, title, text, data, callback, contentType, failCallback, alwaysCallBack, false );
}


function swalLoading(view) {
    if (view) {
        $(".cancel").addClass("hidden");
        $(".confirm").addClass("hidden");
        if ($("#loadingImage")) {
            if ($("#loadingImage")[0] == undefined) {
                $(".sa-button-container").append('<div id="loadingImage" style="line-height: 70px; height: 70px;"><img src="../images/30.gif" /></div>');
            } else {
                $("#loadingImage").removeClass("hidden");
            }
        }
        
    } else {
        $(".cancel").removeClass("hidden");
        $(".confirm").removeClass("hidden");
        if ($("#loadingImage")) {
            $("#loadingImage").addClass("hidden");
        }
    }
}

function myPostAjax(url, title, text, data, callback, contentType, failCallback, alwaysCallBack, bAsync ) {
    var option = {
        url : url,
        method : 'POST',
        async: bAsync,
        data : data,
        dataType : "json",
        success : function( response ) {
            if ( response.result ) {
                mySwal( title + "성공", text, "success", {
                    method : callback,
                    el : response
                });
            } else {
                if (failCallback) {
                    mySwal(title + "실패", response.message, "error", failCallback)
                } else {
                    swal(title + "실패", response.message, "error");
                }
            }
        },
        error : function ( xhr, textStatus, error) {
            if (xhr.status == 901) {
                location.href = "./logout";
            } else {
                swal( title + "실패", textStatus, "error");
            }
        }
    };

    if (contentType) {
        option.contentType = contentType;
    }

    $.ajax(option)
    .always(function() {
        if (alwaysCallBack) {
            alwaysCallBack();
        }
    });;
}
function myPostAjaxNoAlert( url, data, callback, failCallback ) {
    myPostAjaxNoAlert( url, data, callback, failCallback, true );
}
function myPostAjaxNoAlert( url, data, callback, failCallback, bAsync ) {
    $.ajax({
        url : url,
        method : 'POST',
        data : data,
        async: bAsync,
        dataType : "json",
        success : function( response ) {
            if ( response.result ) {
                callback( response );
            } else {
                if (failCallback) {
                    failCallback(response);
                }
            }
        },
        error : function ( xhr, textStatus, error) {
            if (xhr.status == 901) {
                location.href = "./logout";
            } else {
                if (failCallback) {
                    failCallback();
                }
            }
        }
    });
}

function myPostAjaxSyncNoAlert( url, data, callback, failCallback ) {
    $.ajax({
        url : url,
        method : 'POST',
        async : false,
        data : data,
        dataType : "json",
        success : function( response ) {
            if ( response.result ) {
                callback( response );
            } else {
                if (failCallback) {
                    failCallback(response);
                }
            }
        },
        error : function ( xhr, textStatus, error) {
            if (xhr.status == 901) {
                location.href = "./logout";
            } else {
                if (failCallback) {
                    failCallback();
                }
            }
        }
    });
}

// confirm alert for AJAX request
function confirmAjax( url, title, text, data, callback, contentType ) {
    swal({
        title : title + ' 하시겠습니까?',
        type : 'warning',
        showCancelButton : true,
        confirmButtonColor : '#DD6B55',
        confirmButtonText : '예',
        cancelButtonText : '취소',
        closeOnConfirm : false
    }, function() {
        if (contentType) {
            myPostAjax( url, title, text, data, callback, contentType);
        } else {
            myPostAjax( url, title, text, data, callback );
        }
    });
}
/**
 * make combo box option
 */
function makeDefaultComboOpt(combo, data, value, html, noChange) {
    combo.innerHTML="";
    
    var defaultOpt = document.createElement('option');
    defaultOpt.value = -1;
    defaultOpt.innerHTML = '선택';
    combo.appendChild(defaultOpt);
    
    for ( var i = 0; i < data.length ; i ++ ) {
        var record = data[i];
        var item = document.createElement('option');
        item.value = record[value];
        item.innerHTML = record[html];
        item.record = record;
        combo.appendChild( item );
    }
    
    if (!noChange) {
        $(combo).change();
    }
}
function makeDefaultComboOptSelect(combo, data, value, html, text, noChange) {
    combo.innerHTML="";
    
    var defaultOpt = document.createElement('option');
    defaultOpt.value = -1;
    defaultOpt.innerHTML = '선택';
    combo.appendChild(defaultOpt);
    
    for ( var i = 0; i < data.length ; i ++ ) {
        var record = data[i];
        var item = document.createElement('option');
        item.value = record[value];
        item.innerHTML = record[html];
        item.record = record;
        item.selected = (record[html] == text);
        combo.appendChild( item );
    }
    
    if (!noChange) {
        $(combo).change();
    }
}
function makeComboOpt(combo, data, value, html, noChange) {
    combo.innerHTML="";
    
    for ( var i = 0; i < data.length ; i ++ ) {
        var record = data[i];
        var item = document.createElement('option');
        item.value = record[value];
        item.innerHTML = record[html];
        item.record = record;
        combo.appendChild( item );
    }
    
    if (!noChange) {
        $(combo).change();
    }
}
function makeComboOptSelect(combo, data, value, html, text, noChange) {
    combo.innerHTML="";
    
    for ( var i = 0; i < data.length ; i ++ ) {
        var record = data[i];
        var item = document.createElement('option');
        item.value = record[value];
        item.innerHTML = record[html];
        item.record = record;
        item.selected = (record[html] == text);
        combo.appendChild( item );
    }
    
    if (!noChange) {
    	$(combo).change();
    }
}

function makeTextCombo(combo, data, value, html, defaultItem, noChange, defaultValue) {
    combo.innerHTML="";
    var first = appendChild(combo, "option", null, defaultItem);
    first.value = "0";
    if (defaultValue) {
        first.value = defaultValue;
    }
    for ( var i = 0; i < data.length ; i ++ ) {
        var record = data[i];
        var item = document.createElement('option');
        item.value = record[value];
        item.innerHTML = record[html];
        item.record = record;
        combo.appendChild( item );
    }
    if (!noChange) {
        $(combo).change();
    }
}
function makeTextComboSelect(combo, data, value, html, defaultItem, noChange, defaultValue, text) {
    combo.innerHTML="";
    var first = appendChild(combo, "option", null, defaultItem);
    first.value = "0";
    if (defaultValue) {
        first.value = defaultValue;
    }
    for ( var i = 0; i < data.length ; i ++ ) {
        var record = data[i];
        var item = document.createElement('option');
        item.value = record[value];
        item.innerHTML = record[html];
        item.record = record;
        item.selected = (record[html] == text);
        combo.appendChild( item );
    }
    if (!noChange) {
        $(combo).change();
    }
}

function makeTextComboSelectId(combo, data, value, html, defaultItem, noChange, defaultValue, id) {
    combo.innerHTML="";
    var first = appendChild(combo, "option", null, defaultItem);
    first.value = "0";
    if (defaultValue) {
        first.value = defaultValue;
    }
    for ( var i = 0; i < data.length ; i ++ ) {
        var record = data[i];
        var item = document.createElement('option');
        item.value = record[value];
        item.innerHTML = record[html];
        item.record = record;
        item.selected = (record[value] == id);
        combo.appendChild( item );
    }
    if (!noChange) {
        $(combo).change();
    }
}


/**
 *  for inline swal function with callback
 */
function mySwal( title, text, type, callback) {
    setTimeout(function() {

        swalLoading(false);
        swal(title, text, type);
        $(".confirm")[0].onclick = function() {
            $(".sweet-overlay").remove();
            $(".sweet-alert").remove();
            if (callback instanceof Function) {
                callback();
            } else {
                if ( callback.method ) {
                    callback.method(callback.el);
                }
            }
        }

    }, 500);
}

/**
 *  Confirm alert
 * */
function appConfirmAlert(title, callback) {
    swal({
        title : title + ' 하시겠습니까?',
        type : 'warning',
        showCancelButton : true,
        confirmButtonColor : '#DD6B55',
        confirmButtonText : '예',
        cancelButtonText : '취소',
        closeOnConfirm : false
    }, function() {
        if (callback) {
            callback();
        }
    });
}
/**
 * Alert
 * */
function appSweetAlert(config) {
    setTimeout(function() {
        
        swalLoading(false);
        swal({
            title: config.title,
            text: config.text,
            type: config.type,
            html: true
        }, function() {
            var callback = config.callback;
            if (callback) {
                callback();
            }
        });
        var hBody = document.querySelector(".hidden-body");
        var sweetAlert = document.querySelector(".sweet-alert");
        sweetAlert.style.width = config.width;
        var sweetAlertP = document.querySelector(".sweet-alert p");
        if (config.height) {
            sweetAlertP.style.height = config.height;
        } else {
            sweetAlertP.style.height = "0px";
        }
        hBody.appendChild(sweetAlert);
        
    }, 500);
}

/**
 * page
 *
 */
function goFirstPage(id, pageHandler) {
    var active;
    if (id) {
        active = document.querySelector("#" + id + ' .pagination li.active a');
    } else {
        active = document.querySelector('.pagination li.active a');
    }
    if (active) {
        var page = active.innerHTML*1;
        if (page > 1) {
            if (pageHandler) {
                pageHandler(1);
            } else {
                loadPage(1);
            }
        } else {
            swal('알림','첫번째 페이지 입니다.');
        }
    } else {
        swal('알림','선택된 페이지가 없습니다.');
    }
}
function prevPage(id, pageHandler) {
    var active;
    if (id) {
        active = document.querySelector("#" + id + ' .pagination li.active a');
    } else {
        active = document.querySelector('.pagination li.active a');
    }
    if (active) {
        var page = active.innerHTML*1;
        if (page > 1) {
            if (pageHandler) {
                pageHandler((page-10>1?page-10:1));
            } else {
                loadPage((page-10>1?page-10:1));
            }
        } else {
            swal('알림','첫번째 페이지 입니다.');
        }
    } else {
        swal('알림','선택된 페이지가 없습니다.');
    }
}

function nextPage(id, pageHandler, totalPage) {
    var active, buttons;
    if (id) {
        active = document.querySelector("#" + id + ' .pagination li.active a');
        buttons = document.querySelectorAll("#" + id + ' .pagination li.normal a');
    } else {
        active = document.querySelector('.pagination li.active a');
        buttons = document.querySelectorAll('.pagination li.normal a');
    }
    if (active) {
        if(buttons.length != 0) {
            var page = active.innerHTML*1;
            if(page < totalPage) {
                if (pageHandler) {
                    pageHandler((page+10<totalPage?page+10:totalPage));
                } else {
                    loadPage((page+10<totalPage?page+10:totalPage));
                }
            } else {
                swal('알림','마지막 페이지 입니다.');
            }
        } else {
            swal('알림','페이지 리스트가 없습니다.');
        }
    } else {
        swal('알림','선택된 페이지가 없습니다.');
    }
}
function lastPage(id, pageHandler, totalPage) {
    var active, buttons;
    if (id) {
        active = document.querySelector("#" + id + ' .pagination li.active a');
        buttons = document.querySelectorAll("#" + id + ' .pagination li.normal a');
    } else {
        active = document.querySelector('.pagination li.active a');
        buttons = document.querySelectorAll('.pagination li.normal a');
    }
    if (active) {
        if(buttons.length != 0) {
            var page = active.innerHTML*1;
            if(page < totalPage) {
                if (pageHandler) {
                    pageHandler(totalPage);
                } else {
                    loadPage(totalPage);
                }
            } else {
                swal('알림','마지막 페이지 입니다.');
            }
        } else {
            swal('알림','페이지 리스트가 없습니다.');
        }
    } else {
        swal('알림','선택된 페이지가 없습니다.');
    }
}
/**
 *  validation
 * */
function resetCheckValid() {
    finalRegistrationForm();
}

function validate(search) {
    search = search || '.checkValid';
    var checkValidList = $(search);
    var validation = true;
    $.each(checkValidList, function(index, item) {
        var value = item.value;
        var pTag = item.parentNode.querySelector('p');
        if (value == "" || value == null) {
            item.parentNode.parentNode.className += " has-error";
            if(pTag) {
                $(pTag).show();
            }
            validation = false;
        } else {
            $(item.parentNode.parentNode).removeClass("has-error");
            if(pTag) {
                $(pTag).hide();
            }
        }
    });
    return validation;
}

function validateExceptionally(search, validateFunction ) {
    var checkValidList = $(search);
    var validation = true;
    $.each(checkValidList, function(index, item) {
        var value = item.value;
        var pTag = item.parentNode.querySelector('p');

        var parentItem = item;
        while ($(parentItem).hasClass("form-group") == false) {
            parentItem = parentItem.parentNode;
        }
        if (validateFunction(item)) {
            $(parentItem).addClass("has-error");
            if(pTag) {
                $(pTag).show();
            }
            validation = false;
        } else {
            $(parentItem).removeClass("has-error");
            if(pTag) {
                $(pTag).hide();
            }
        }
    });
    return validation;
}

function finalRegistrationForm() {
    $(".has-error p").hide();
    $(".has-error").removeClass("has-error");

}

// convert form to object
jQuery.fn.serializeObject = function() {
    var obj = null;
    try {
        // this[0].tagName이 form tag일 경우
        if(this[0].tagName && this[0].tagName.toUpperCase() == "FORM" ) {
            var arr = this.serializeArray();
            if (arr) {
                obj = {};
                jQuery.each(arr, function() {
                    // obj의 key값은 arr의 name, obj의 value는 value값
                    obj[this.name] = this.value;
                });
            }
        }
    }catch(e) {
        alert(e.message);
    }finally  {}
    return obj;
}

function moneyFormatWon( value ) {
    if (value != null && value != undefined)
        return accounting.formatNumber(Math.floor(value/1000));
    else 
        return "";
}

function moneyFormat( value) {
    if (value != null && value != undefined)
        return accounting.formatNumber(value, 2); // £ -500,000
    else 
        return "";
//    format( "#,##0.####", 1234567.890)
}

function floatNumberFormat( value, float ) {
	if (!float)	float = 0;
	
    return accounting.formatNumber( value, float );
}

/**
 * Download
 */
function download(url, config) {
    document.download.action = url;
    var T = document.download;
    var inputTags = T.querySelectorAll('input');
    for (var i = 0; inputTags.length > i; i++) {
        var fieldName = inputTags[i].name;
        if (fieldName in config) {
            inputTags[i].disabled = false;
            inputTags[i].value = config[fieldName];
        } else {
            inputTags[i].disabled = true;
        }
    }
    //임시저장
    var t = T.target;
    var a = T.action;
    T.target    = "iframeFF";
    //복구
    T.submit();
    T.target    = t;
    T.action    = a;
}

function nestableDivActive(search) {
    // remove active item
    $(".dd-handle-active").removeClass("dd-handle-active");
    $(search).addClass("dd-handle-active");
}





function get(value) {
    if (value) {
        return value;
    } else {
        return "";
    }
}

String.prototype.format = String.prototype.f = function() {
    var s = this, i = arguments.length;
    while (i--) {
        s = s.replace(new RegExp('\\{' + i + '\\}', 'gm'), arguments[i]);
    }
    return s;
};


function renameColumn(type, struct) {
    if (type == 1) {
        struct[1].name = '시간';
    } else if (type == 2) {
        struct[1].name = '주차';
    } else if (type == 3) {
        struct[1].name = '일';
    } else if (type == 4) {
        struct[1].name = '월';
    }
    return struct;
}
