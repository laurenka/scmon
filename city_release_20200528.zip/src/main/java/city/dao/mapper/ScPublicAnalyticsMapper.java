package city.dao.mapper;

import java.util.List;
import java.util.Map;

import city.beans.Cl;
import city.beans.ClasC;
import city.beans.EqCate;
import city.beans.EquipCate;
import city.beans.SearchUsed;
import city.domain.ComboData;
import city.domain.Search;

public interface ScPublicAnalyticsMapper {
	List<ComboData> getEnergyList() throws Exception;
	List<ComboData> getClasAList(Search search) throws Exception;
	List<ComboData> getClasList(Search search) throws Exception;
	List<ComboData> getClasBList(Search search) throws Exception;
	List<ComboData> getClasCList(Search search) throws Exception;
	List<ComboData> getEqCateList(Search search) throws Exception;
	List<ClasC> getClassB11ChartList(Search search) throws Exception;
	List<ClasC> getClassB21ChartList(Search search) throws Exception;
	List<ClasC> getClassB22ChartList(Search search) throws Exception;
	List<ClasC> getClassB23ChartList(Search search) throws Exception;
	List<ClasC> getClassB24ChartList(Search search) throws Exception;
	List<ClasC> getClassB25ChartList(Search search) throws Exception;
	List<ClasC> getClassB26ChartList(Search search) throws Exception;
	List<ClasC> getClassB31ChartList(Search search) throws Exception;
	List<ClasC> getClassB41ChartList(Search search) throws Exception;
	List<ClasC> getClassB42ChartList(Search search) throws Exception;
	List<ClasC> getClassB43ChartList(Search search) throws Exception;
	List<ClasC> getClassB44ChartList(Search search) throws Exception;
	List<ClasC> getClassB45ChartList(Search search) throws Exception;
	List<ClasC> getClassB46ChartList(Search search) throws Exception;
//	List<ClasC> getClassCChartList(Map search) throws Exception;
	
	
	List<Cl> getChartList(SearchUsed search) throws Exception;
	List<Cl> getSeasonChartList(SearchUsed search) throws Exception;
	List<Cl> getMonthChartList(SearchUsed search) throws Exception;
	
	
	
}
