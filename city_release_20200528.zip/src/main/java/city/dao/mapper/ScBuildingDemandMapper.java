package city.dao.mapper;

import java.util.List;

import city.beans.Cl;
import city.beans.SearchUsed;
import city.domain.ComboData;
import city.domain.Search;


public interface ScBuildingDemandMapper {
	List<ComboData> getEnergyList() throws Exception;
	List<ComboData> getClasBList(Search search) throws Exception;
	List<ComboData> getClasCList(Search search) throws Exception;
	List<ComboData> getClasList(Search search) throws Exception;
	List<Cl> getChartList(SearchUsed search) throws Exception;
}
