package city.dao.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import city.domain.ComboData;
import city.menu.service.MenuItem;

public interface MenuMapper {
    List<MenuItem> getMenuList(@Param("typeId") int typeId) throws Exception;
    List<ComboData> getModule(@Param("deptId") int deptId, @Param("locationId") int locationId) throws Exception;
    
    List<MenuItem> getParentMenuItem(@Param("schema") String schema, @Param("userGrant") int userGrant) throws Exception;
    List<MenuItem> getMenuItem(@Param("schema") String schema, @Param("parentId") int parentId) throws Exception;
    List<MenuItem> getMappingMenuItem(@Param("schema") String schema) throws Exception;
    
    
    int getDepthByWorkspace(@Param("workspaceId") int workspaceId) throws Exception;
    List<MenuItem> getTabList(@Param("domainId") int domainId) throws Exception;
}
