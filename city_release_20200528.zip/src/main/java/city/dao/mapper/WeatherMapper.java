package city.dao.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.springframework.dao.DataAccessException;

import city.domain.User;
import city.web.weather.Location;
import city.web.weather.Weather;

public interface WeatherMapper {

    Location getCompanyLocationById(User user) throws DataAccessException;
    
    List<Location> getLocationList() throws Exception;
    
    void insertWeatherInfo(@Param("location") Location location, @Param("weather") Weather weather) throws Exception;
    
    Weather getWeatherForCurrent(@Param("workspaceId") int workspaceId) throws Exception;
}
