package city.dao.mapper;

import java.util.List;

import city.beans.ScDashboardItem;

public interface ScDashboardMapper {

    ScDashboardItem getCurrCateToe(ScDashboardItem item) throws Exception;
    ScDashboardItem getCurrEnergyToe(ScDashboardItem item) throws Exception;
    ScDashboardItem getCurrEnergyPieToe(ScDashboardItem item) throws Exception;
    ScDashboardItem getCurrEnergyBar(ScDashboardItem item) throws Exception;
}