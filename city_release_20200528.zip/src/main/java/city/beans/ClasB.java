package city.beans;

public class ClasB {

	private String regidential;             
	private String commercial;              
	private String research;					
	private String educational;             
	private String publ;                    
	private String medical;                 
	private String religious;               
	private String industrial;              
	private String automobile;				
	private String electricVehicleCharger;
	private String park;                
	private String urbanInfra;          
	private String streetLight;               
	private String trafficLight;
	private String insertDate;
	
	public String getRegidential() {
		return regidential;
	}
	public void setRegidential(String regidential) {
		this.regidential = regidential;
	}
	public String getCommercial() {
		return commercial;
	}
	public void setCommercial(String commercial) {
		this.commercial = commercial;
	}
	public String getResearch() {
		return research;
	}
	public void setResearch(String research) {
		this.research = research;
	}
	public String getEducational() {
		return educational;
	}
	public void setEducational(String educational) {
		this.educational = educational;
	}
	public String getPubl() {
		return publ;
	}
	public void setPubl(String publ) {
		this.publ = publ;
	}
	public String getMedical() {
		return medical;
	}
	public void setMedical(String medical) {
		this.medical = medical;
	}
	public String getReligious() {
		return religious;
	}
	public void setReligious(String religious) {
		this.religious = religious;
	}
	public String getIndustrial() {
		return industrial;
	}
	public void setIndustrial(String industrial) {
		this.industrial = industrial;
	}
	public String getAutomobile() {
		return automobile;
	}
	public void setAutomobile(String automobile) {
		this.automobile = automobile;
	}
	public String getElectricVehicleCharger() {
		return electricVehicleCharger;
	}
	public void setElectricVehicleCharger(String electricVehicleCharger) {
		this.electricVehicleCharger = electricVehicleCharger;
	}
	public String getPark() {
		return park;
	}
	public void setPark(String park) {
		this.park = park;
	}
	public String getUrbanInfra() {
		return urbanInfra;
	}
	public void setUrbanInfra(String urbanInfra) {
		this.urbanInfra = urbanInfra;
	}
	public String getStreetLight() {
		return streetLight;
	}
	public void setStreetLight(String streetLight) {
		this.streetLight = streetLight;
	}
	public String getTrafficLight() {
		return trafficLight;
	}
	public void setTrafficLight(String trafficLight) {
		this.trafficLight = trafficLight;
	}       
	public String getInsertDate() {
		return insertDate;
	}
	public void setInsertDate(String insertDate) {
		this.insertDate = insertDate;
	}
}
