package city.beans;

public class ClasC {
	
	private String detachedHouse;     
	private String sharedHouse;         
	private String neighboringLiving;
	private String sales;
	private String accommodation;
	private String generalBusiness;
	private String research;
	private String kindergarten;
	private String elementarySchool;
	private String middleSchool;
	private String highSchool;
	private String publicOffices;
	private String indoorGym;
	private String performance;
	private String trainingCenter;
	private String generalHospital;
	private String specializedHospital;
	private String church;
	private String temple;
	private String cathedral;
	private String smartFarm;
	private String gasStation;
	private String gasFilingStation;
	private String parkingLot;
	private String quickCharger;
	private String slowCharger;
	private String managementOffice;
	private String toilet;
	private String waterSupply;
	private String sewageTreatment;
	private String wasteTreatment;
	private String electricitySupply;
	private String smartStreetLight;
	private String trafficLight;
	private String insertDate;
	
	public String getDetachedHouse() {
		return detachedHouse;
	}
	public void setDetachedHouse(String detachedHouse) {
		this.detachedHouse = detachedHouse;
	}
	public String getSharedHouse() {
		return sharedHouse;
	}
	public void setSharedHouse(String sharedHouse) {
		this.sharedHouse = sharedHouse;
	}
	public String getNeighboringLiving() {
		return neighboringLiving;
	}
	public void setNeighboringLiving(String neighboringLiving) {
		this.neighboringLiving = neighboringLiving;
	}
	public String getSales() {
		return sales;
	}
	public void setSales(String sales) {
		this.sales = sales;
	}
	public String getAccommodation() {
		return accommodation;
	}
	public void setAccommodation(String accommodation) {
		this.accommodation = accommodation;
	}
	public String getGeneralBusiness() {
		return generalBusiness;
	}
	public void setGeneralBusiness(String generalBusiness) {
		this.generalBusiness = generalBusiness;
	}
	public String getResearch() {
		return research;
	}
	public void setResearch(String research) {
		this.research = research;
	}
	public String getKindergarten() {
		return kindergarten;
	}
	public void setKindergarten(String kindergarten) {
		this.kindergarten = kindergarten;
	}
	public String getElementarySchool() {
		return elementarySchool;
	}
	public void setElementarySchool(String elementarySchool) {
		this.elementarySchool = elementarySchool;
	}
	public String getMiddleSchool() {
		return middleSchool;
	}
	public void setMiddleSchool(String middleSchool) {
		this.middleSchool = middleSchool;
	}
	public String getHighSchool() {
		return highSchool;
	}
	public void setHighSchool(String highSchool) {
		this.highSchool = highSchool;
	}
	public String getPublicOffices() {
		return publicOffices;
	}
	public void setPublicOffices(String publicOffices) {
		this.publicOffices = publicOffices;
	}
	public String getIndoorGym() {
		return indoorGym;
	}
	public void setIndoorGym(String indoorGym) {
		this.indoorGym = indoorGym;
	}
	public String getPerformance() {
		return performance;
	}
	public void setPerformance(String performance) {
		this.performance = performance;
	}
	public String getTrainingCenter() {
		return trainingCenter;
	}
	public void setTrainingCenter(String trainingCenter) {
		this.trainingCenter = trainingCenter;
	}
	public String getGeneralHospital() {
		return generalHospital;
	}
	public void setGeneralHospital(String generalHospital) {
		this.generalHospital = generalHospital;
	}
	public String getSpecializedHospital() {
		return specializedHospital;
	}
	public void setSpecializedHospital(String specializedHospital) {
		this.specializedHospital = specializedHospital;
	}
	public String getChurch() {
		return church;
	}
	public void setChurch(String church) {
		this.church = church;
	}
	public String getTemple() {
		return temple;
	}
	public void setTemple(String temple) {
		this.temple = temple;
	}
	public String getCathedral() {
		return cathedral;
	}
	public void setCathedral(String cathedral) {
		this.cathedral = cathedral;
	}
	public String getSmartFarm() {
		return smartFarm;
	}
	public void setSmartFarm(String smartFarm) {
		this.smartFarm = smartFarm;
	}
	public String getGasStation() {
		return gasStation;
	}
	public void setGasStation(String gasStation) {
		this.gasStation = gasStation;
	}
	public String getGasFilingStation() {
		return gasFilingStation;
	}
	public void setGasFilingStation(String gasFilingStation) {
		this.gasFilingStation = gasFilingStation;
	}
	public String getParkingLot() {
		return parkingLot;
	}
	public void setParkingLot(String parkingLot) {
		this.parkingLot = parkingLot;
	}
	public String getQuickCharger() {
		return quickCharger;
	}
	public void setQuickCharger(String quickCharger) {
		this.quickCharger = quickCharger;
	}
	public String getSlowCharger() {
		return slowCharger;
	}
	public void setSlowCharger(String slowCharger) {
		this.slowCharger = slowCharger;
	}
	public String getManagementOffice() {
		return managementOffice;
	}
	public void setManagementOffice(String managementOffice) {
		this.managementOffice = managementOffice;
	}
	public String getToilet() {
		return toilet;
	}
	public void setToilet(String toilet) {
		this.toilet = toilet;
	}
	public String getWaterSupply() {
		return waterSupply;
	}
	public void setWaterSupply(String waterSupply) {
		this.waterSupply = waterSupply;
	}
	public String getSewageTreatment() {
		return sewageTreatment;
	}
	public void setSewageTreatment(String sewageTreatment) {
		this.sewageTreatment = sewageTreatment;
	}
	public String getWasteTreatment() {
		return wasteTreatment;
	}
	public void setWasteTreatment(String wasteTreatment) {
		this.wasteTreatment = wasteTreatment;
	}
	public String getElectricitySupply() {
		return electricitySupply;
	}
	public void setElectricitySupply(String electricitySupply) {
		this.electricitySupply = electricitySupply;
	}
	public String getSmartStreetLight() {
		return smartStreetLight;
	}
	public void setSmartStreetLight(String smartStreetLight) {
		this.smartStreetLight = smartStreetLight;
	}
	public String getTrafficLight() {
		return trafficLight;
	}
	public void setTrafficLight(String trafficLight) {
		this.trafficLight = trafficLight;
	}
	public String getInsertDate() {
		return insertDate;
	}
	public void setInsertDate(String insertDate) {
		this.insertDate = insertDate;
	}
	
	
}
