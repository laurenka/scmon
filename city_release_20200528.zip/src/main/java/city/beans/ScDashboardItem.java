package city.beans;

import java.util.List;

public class ScDashboardItem {
	
	
    public int workspaceId;
    public int id;
    public int energyId;
    public String name;
    public String energy;
    public String date;
    public String date2;
    public String value;
    public String unit;
    public String value2;
    public String unit2;
    public String value3;
    public String unit3;
    public String value4;
    public String unit4;
    public String value5;
    public String unit5;
    public String value6;
    public String unit6;
    public String value7;
    public String unit7;
    public String value8;
    public String unit8;    
    public List<Integer> ids;
    public String inDate;
    
    public int clasA;
    
    public ScDashboardItem() {
        init("");
    }
    public ScDashboardItem(String name) {
        init(name);
    }
    
    private void init(String name) {
        workspaceId = -1;
        id = -1;
        energyId = -1;
        
        this.name = name;
        date = "";
        date2 = "";
        value = "0";
        unit = "";
        value2 = "0";
        unit2 = "";
        value3 = "0";
        unit3 = "";
        value4 = "0";
        unit4 = "";
        value5 = "0";
        unit5 = "";
        value6 = "0";
        unit6 = "";
        value7 = "0";
        unit7 = "";
        value8 = "0";
        unit8 = "";
    }
    
    
    public String getInDate() {
		return inDate;
	}
	public void setInDate(String inDate) {
		this.inDate = inDate;
	}
	public int getWorkspaceId() {
        return workspaceId;
    }
    public void setWorkspaceId(int workspaceId) {
        this.workspaceId = workspaceId;
    }
    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }
    public int getEnergyId() {
        return energyId;
    }
    public void setEnergyId(int energyId) {
        this.energyId = energyId;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public String getEnergy() {
        return energy;
    }
    public void setEnergy(String energy) {
        this.energy = energy;
    }
    public String getDate() {
        return date;
    }
    public void setDate(String date) {
        this.date = date;
    }
    public String getDate2() {
        return date2;
    }
    public void setDate2(String date2) {
        this.date2 = date2;
    }
    public String getValue() {
        return value;
    }
    public void setValue(String value) {
        this.value = value;
    }
    public String getUnit() {
        return unit;
    }
    public void setUnit(String unit) {
        this.unit = unit;
    }
    public String getValue2() {
        return value2;
    }
    public void setValue2(String value2) {
        this.value2 = value2;
    }
    public String getUnit2() {
        return unit2;
    }
    public void setUnit2(String unit2) {
        this.unit2 = unit2;
    }
    public String getValue3() {
        return value3;
    }
    public void setValue3(String value3) {
        this.value3 = value3;
    }
    public String getUnit3() {
        return unit3;
    }
    public void setUnit3(String unit3) {
        this.unit3 = unit3;
    }
    public String getValue4() {
        return value4;
    }
    public void setValue4(String value4) {
        this.value4 = value4;
    }
    public String getUnit4() {
        return unit4;
    }
    public void setUnit4(String unit4) {
        this.unit4 = unit4;
    }
    
    public String getValue5() {
		return value5;
	}
	public void setValue5(String value5) {
		this.value5 = value5;
	}
	public String getUnit5() {
		return unit5;
	}
	public void setUnit5(String unit5) {
		this.unit5 = unit5;
	}
	public String getValue6() {
		return value6;
	}
	public void setValue6(String value6) {
		this.value6 = value6;
	}
	public String getUnit6() {
		return unit6;
	}
	public void setUnit6(String unit6) {
		this.unit6 = unit6;
	}
	public String getValue7() {
		return value7;
	}
	public void setValue7(String value7) {
		this.value7 = value7;
	}
	public String getUnit7() {
		return unit7;
	}
	public void setUnit7(String unit7) {
		this.unit7 = unit7;
	}
	public String getValue8() {
		return value8;
	}
	public void setValue8(String value8) {
		this.value8 = value8;
	}
	public String getUnit8() {
		return unit8;
	}
	public void setUnit8(String unit8) {
		this.unit8 = unit8;
	}
	public List<Integer> getIds() {
        return ids;
    }
    public void setIds(List<Integer> ids) {
        this.ids = ids;
    }
	public int getClasA() {
		return clasA;
	}
	public void setClasA(int clasA) {
		this.clasA = clasA;
	}
    
    
}
