package city.beans;

public class EqCate {
	private String acousticCommunication;
	private String acousticCommunicationFacility;
	private String bookMaterials;
	private String catering;
	private String coolingAndHeating;
	private String cultural;
	private String detachedHouse;
	private String educationalMaterials;
	private String emergencyGenerator;
	private String freezeProtectionElectricHeater;
	private String fuelCell;
	private String heating;
	private String heatingAndheatingWater;
	private String horizontalLighting;
	private String hygiene;
	private String kitchen;
	private String laundryHygiene;
	private String lightControlPanel;
	private String Lighting;
	private String medicalEquipment;
	private String monitoring;
	private String office;
	private String other;
	private String otherCommercial;
	private String otherHousehold;
	private String performanceEquipment;
	private String physicalFacilities;
	private String power;
	private String publicFacilitie;
	private String publicFacility;
	private String rapidCharge;
	private String reasearchMaterials;
	private String religiousFacility;
	private String sales;
	private String signalControlPanel;
	private String slowCharge;
	private String streetLighting;
	private String toiletElectricWaterHeater;
	private String trafficLight;
	private String trainingEquipment;
	private String insertDate;
	private String heatingKero;
	private String heatingLng;
	private String cateringKero;
	private String cateringLng;
	private String heatingAndheatingWaterLng;
	private String emergencyGeneratorLng;
	
	
	public String getCateringKero() {
		return cateringKero;
	}
	public void setCateringKero(String cateringKero) {
		this.cateringKero = cateringKero;
	}
	public String getCateringLng() {
		return cateringLng;
	}
	public void setCateringLng(String cateringLng) {
		this.cateringLng = cateringLng;
	}
	public String getHeatingAndheatingWaterLng() {
		return heatingAndheatingWaterLng;
	}
	public void setHeatingAndheatingWaterLng(String heatingAndheatingWaterLng) {
		this.heatingAndheatingWaterLng = heatingAndheatingWaterLng;
	}
	public String getEmergencyGeneratorLng() {
		return emergencyGeneratorLng;
	}
	public void setEmergencyGeneratorLng(String emergencyGeneratorLng) {
		this.emergencyGeneratorLng = emergencyGeneratorLng;
	}
	public String getHeatingKero() {
		return heatingKero;
	}
	public void setHeatingKero(String heatingKero) {
		this.heatingKero = heatingKero;
	}
	public String getHeatingLng() {
		return heatingLng;
	}
	public void setHeatingLng(String heatingLng) {
		this.heatingLng = heatingLng;
	}
	public String getInsertDate() {
		return insertDate;
	}
	public void setInsertDate(String insertDate) {
		this.insertDate = insertDate;
	}
	public String getAcousticCommunication() {
		return acousticCommunication;
	}
	public void setAcousticCommunication(String acousticCommunication) {
		this.acousticCommunication = acousticCommunication;
	}
	public String getAcousticCommunicationFacility() {
		return acousticCommunicationFacility;
	}
	public void setAcousticCommunicationFacility(String acousticCommunicationFacility) {
		this.acousticCommunicationFacility = acousticCommunicationFacility;
	}
	public String getBookMaterials() {
		return bookMaterials;
	}
	public void setBookMaterials(String bookMaterials) {
		this.bookMaterials = bookMaterials;
	}
	public String getCatering() {
		return catering;
	}
	public void setCatering(String catering) {
		this.catering = catering;
	}
	public String getCoolingAndHeating() {
		return coolingAndHeating;
	}
	public void setCoolingAndHeating(String coolingAndHeating) {
		this.coolingAndHeating = coolingAndHeating;
	}
	public String getCultural() {
		return cultural;
	}
	public void setCultural(String cultural) {
		this.cultural = cultural;
	}
	public String getDetachedHouse() {
		return detachedHouse;
	}
	public void setDetachedHouse(String detachedHouse) {
		this.detachedHouse = detachedHouse;
	}
	public String getEducationalMaterials() {
		return educationalMaterials;
	}
	public void setEducationalMaterials(String educationalMaterials) {
		this.educationalMaterials = educationalMaterials;
	}
	public String getEmergencyGenerator() {
		return emergencyGenerator;
	}
	public void setEmergencyGenerator(String emergencyGenerator) {
		this.emergencyGenerator = emergencyGenerator;
	}
	public String getFreezeProtectionElectricHeater() {
		return freezeProtectionElectricHeater;
	}
	public void setFreezeProtectionElectricHeater(String freezeProtectionElectricHeater) {
		this.freezeProtectionElectricHeater = freezeProtectionElectricHeater;
	}
	public String getFuelCell() {
		return fuelCell;
	}
	public void setFuelCell(String fuelCell) {
		this.fuelCell = fuelCell;
	}
	public String getHeating() {
		return heating;
	}
	public void setHeating(String heating) {
		this.heating = heating;
	}
	public String getHeatingAndheatingWater() {
		return heatingAndheatingWater;
	}
	public void setHeatingAndheatingWater(String heatingAndheatingWater) {
		this.heatingAndheatingWater = heatingAndheatingWater;
	}
	public String getHorizontalLighting() {
		return horizontalLighting;
	}
	public void setHorizontalLighting(String horizontalLighting) {
		this.horizontalLighting = horizontalLighting;
	}
	public String getHygiene() {
		return hygiene;
	}
	public void setHygiene(String hygiene) {
		this.hygiene = hygiene;
	}
	public String getKitchen() {
		return kitchen;
	}
	public void setKitchen(String kitchen) {
		this.kitchen = kitchen;
	}
	public String getLaundryHygiene() {
		return laundryHygiene;
	}
	public void setLaundryHygiene(String laundryHygiene) {
		this.laundryHygiene = laundryHygiene;
	}
	public String getLightControlPanel() {
		return lightControlPanel;
	}
	public void setLightControlPanel(String lightControlPanel) {
		this.lightControlPanel = lightControlPanel;
	}
	public String getLighting() {
		return Lighting;
	}
	public void setLighting(String lighting) {
		Lighting = lighting;
	}
	public String getMedicalEquipment() {
		return medicalEquipment;
	}
	public void setMedicalEquipment(String medicalEquipment) {
		this.medicalEquipment = medicalEquipment;
	}
	public String getMonitoring() {
		return monitoring;
	}
	public void setMonitoring(String monitoring) {
		this.monitoring = monitoring;
	}
	public String getOffice() {
		return office;
	}
	public void setOffice(String office) {
		this.office = office;
	}
	public String getOther() {
		return other;
	}
	public void setOther(String other) {
		this.other = other;
	}
	public String getOtherCommercial() {
		return otherCommercial;
	}
	public void setOtherCommercial(String otherCommercial) {
		this.otherCommercial = otherCommercial;
	}
	public String getOtherHousehold() {
		return otherHousehold;
	}
	public void setOtherHousehold(String otherHousehold) {
		this.otherHousehold = otherHousehold;
	}
	public String getPerformanceEquipment() {
		return performanceEquipment;
	}
	public void setPerformanceEquipment(String performanceEquipment) {
		this.performanceEquipment = performanceEquipment;
	}
	public String getPhysicalFacilities() {
		return physicalFacilities;
	}
	public void setPhysicalFacilities(String physicalFacilities) {
		this.physicalFacilities = physicalFacilities;
	}
	public String getPower() {
		return power;
	}
	public void setPower(String power) {
		this.power = power;
	}
	public String getPublicFacilitie() {
		return publicFacilitie;
	}
	public void setPublicFacilitie(String publicFacilitie) {
		this.publicFacilitie = publicFacilitie;
	}
	public String getPublicFacility() {
		return publicFacility;
	}
	public void setPublicFacility(String publicFacility) {
		this.publicFacility = publicFacility;
	}
	public String getRapidCharge() {
		return rapidCharge;
	}
	public void setRapidCharge(String rapidCharge) {
		this.rapidCharge = rapidCharge;
	}
	public String getReasearchMaterials() {
		return reasearchMaterials;
	}
	public void setReasearchMaterials(String reasearchMaterials) {
		this.reasearchMaterials = reasearchMaterials;
	}
	public String getReligiousFacility() {
		return religiousFacility;
	}
	public void setReligiousFacility(String religiousFacility) {
		this.religiousFacility = religiousFacility;
	}
	public String getSales() {
		return sales;
	}
	public void setSales(String sales) {
		this.sales = sales;
	}
	public String getSignalControlPanel() {
		return signalControlPanel;
	}
	public void setSignalControlPanel(String signalControlPanel) {
		this.signalControlPanel = signalControlPanel;
	}
	public String getSlowCharge() {
		return slowCharge;
	}
	public void setSlowCharge(String slowCharge) {
		this.slowCharge = slowCharge;
	}
	public String getStreetLighting() {
		return streetLighting;
	}
	public void setStreetLighting(String streetLighting) {
		this.streetLighting = streetLighting;
	}
	public String getToiletElectricWaterHeater() {
		return toiletElectricWaterHeater;
	}
	public void setToiletElectricWaterHeater(String toiletElectricWaterHeater) {
		this.toiletElectricWaterHeater = toiletElectricWaterHeater;
	}
	public String getTrafficLight() {
		return trafficLight;
	}
	public void setTrafficLight(String trafficLight) {
		this.trafficLight = trafficLight;
	}
	public String getTrainingEquipment() {
		return trainingEquipment;
	}
	public void setTrainingEquipment(String trainingEquipment) {
		this.trainingEquipment = trainingEquipment;
	}

}
