package city.manage.web;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import city.beans.Cl;
import city.beans.ClasB;
import city.beans.SearchUsed;
import city.dao.mapper.ScPublicDemandMapper;
import city.domain.ComboData;
import city.domain.Search;

@Service("scPublicDemandService")
public class ScPublicDemandService {

    @Autowired
    ScPublicDemandMapper scPublicDemandMapper;
    
    public List<ComboData> getEnergyList() throws Exception {
        return scPublicDemandMapper.getEnergyList();
    }
    
    public List<ComboData> getClasBList(Search search) throws Exception {
        return scPublicDemandMapper.getClasBList(search);
    }
    
    public List<ComboData> getClasCList(Search search) throws Exception {
        return scPublicDemandMapper.getClasCList(search);
    }
    
    public List<ComboData> getClasList(Search search) throws Exception {
        return scPublicDemandMapper.getClasList(search);
    }
    
    public List<Cl> getChartList(SearchUsed search) throws Exception {
        return scPublicDemandMapper.getChartList(search);
    }
    
    
}
