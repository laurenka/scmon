package city.manage.web;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import city.beans.Cl;
import city.beans.EqCate;
import city.beans.SearchUsed;
import city.cmm.module.CalculationUtil;
import city.cmm.module.ChartXAxisUtil;
import city.cmm.util.CityUtil;
import city.domain.ComboData;
import city.domain.Search;
import city.domain.SimpleDataResult;
import city.domain.SimpleResult;
import city.menu.service.MenuService;

@Controller
public class ScBuildingAnalyticsController {
    @Autowired MenuService menuService;
    @Autowired ScBuildingAnalyticsService scBuildingAnalyticsService;
 
    @RequestMapping(value="/{workspace}/scBuildingAnalytics")
    public String getScManageAnalytics(HttpServletRequest req, Model model, @PathVariable("workspace") String workspace) {
    	model.addAttribute("workspace", workspace);
        return "scBuildingAnalytics";
    }

    @ResponseBody
    @RequestMapping(value="/{ws}/scBuildingAnalytics/getEnergy", method=RequestMethod.POST, produces="application/json;charset=utf8")
    public SimpleResult getEnergyList(HttpServletRequest req) {
        try {          
        	return new SimpleDataResult(true, scBuildingAnalyticsService.getEnergyList());       
        } catch (Exception e) {
            e.printStackTrace();
            return new SimpleResult(false, e.getMessage());
        }
    }
    
    @ResponseBody
    @RequestMapping(value="/{ws}/scBuildingAnalytics/getClasB", method=RequestMethod.POST, produces="application/json;charset=utf8")
    public SimpleResult getClasBList(HttpServletRequest req, Search search) {
        try {          
        	return new SimpleDataResult(true, scBuildingAnalyticsService.getClasBList(search));       
        } catch (Exception e) {
            e.printStackTrace();
            return new SimpleResult(false, e.getMessage());
        }
    }
    
    @ResponseBody
    @RequestMapping(value="/{ws}/scBuildingAnalytics/getClasC", method=RequestMethod.POST, produces="application/json;charset=utf8")
    public SimpleResult getClasCList(HttpServletRequest req, Search search) {
        try {          
        	return new SimpleDataResult(true, scBuildingAnalyticsService.getClasCList(search));       
        } catch (Exception e) {
            e.printStackTrace();
            return new SimpleResult(false, e.getMessage());
        }
    }
    
    @ResponseBody
    @RequestMapping(value = "/{ws}/scBuildingAnalytics/getChartList", method = RequestMethod.POST, produces = "application/json;charset=utf-8")
    public SimpleResult getChartList(HttpServletRequest req, Search search) {
        search.setIsChart(1);
        search.calcTime();
        search.setItem(1);
        
        
        Map<String, Object> chartData = new HashMap<>();
        Map<String, List<String>> dataMap = new HashMap<>();
        Map<String, List<String>> dataMap1 = new HashMap<>();
        Map<String, Integer> indexMap = new HashMap<>();
        
        try {
        	if(search.getPeriodType() == 0) {
        		
	        	if(search.getClas() == 0) search.setClasField("id");
	            else search.setClasField("id");
	        	List<ComboData> columns = scBuildingAnalyticsService.getClasList(search);
	        	
	        	SearchUsed su = new SearchUsed();
	            su.setEnergy(search.getEnergy());
	            su.setPeriodType(search.getPeriodType());
	            su.setDate(search.getDate());
	            su.setList(columns);
	            
	            List<Cl> thisYearList = scBuildingAnalyticsService.getSeasonChartList(su);
	            
	            Calendar currentCal = Calendar.getInstance();
	            currentCal.setTime(Search.DATE_FORMAT.parse(search.getDate()));
	            String currDate = Search.MONTH_FORMAT.format(new Date(currentCal.getTimeInMillis()));
	            
	            Calendar lastCal = Calendar.getInstance();
	            lastCal.setTime(Search.DATE_FORMAT.parse(search.getDate()));
	            lastCal.add(Calendar.YEAR, -1);
	           
	            su.setDate(Search.DATE_FORMAT.format(new Date(lastCal.getTimeInMillis())));
	           
	            List<Cl> lastYearList = scBuildingAnalyticsService.getSeasonChartList(su);       
            
            
            
            
            
	            List<String> xAxisData = new ArrayList<String>();
	            xAxisData.add("봄");
	            xAxisData.add("여름");
	            xAxisData.add("가을");
	            xAxisData.add("겨울");
		        chartData.put("xAxisData", xAxisData);
		        chartData.put("dataset", dataMap);
	            
	            List<String> dIndex = new ArrayList<String>();
	            dIndex.add("0");
	            dIndex.add("1");
	            dIndex.add("2");
	            dIndex.add("3");
		        
	            String lastYear = Search.YEAR_FORMAT.format(new Date(lastCal.getTimeInMillis()));
	            String currYear = Search.YEAR_FORMAT.format(new Date(currentCal.getTimeInMillis()));
	            
	            List<List<String>> groupDatas = new ArrayList<List<String>>();
	            List<String> groupData1 = new ArrayList<String>();
	            groupData1.add("3월(" + lastYear + ")");
	            groupData1.add("4월(" + lastYear + ")");
	            groupData1.add("5월(" + lastYear + ")");
	            List<String> groupData2 = new ArrayList<String>();
	            groupData2.add("6월(" + lastYear + ")");
	            groupData2.add("7월(" + lastYear + ")");
	            groupData2.add("8월(" + lastYear + ")");
	            List<String> groupData3 = new ArrayList<String>();
	            groupData3.add("9월(" + lastYear + ")");
	            groupData3.add("10월(" + lastYear + ")");
	            groupData3.add("11월(" + lastYear + ")");
	            List<String> groupData4 = new ArrayList<String>();
	            groupData4.add("12월(" + lastYear + ")");
	            groupData4.add("1월(" + lastYear + ")");
	            groupData4.add("2월(" + lastYear + ")");
	            List<String> groupData5 = new ArrayList<String>();
	            groupData5.add("3월(" + currYear + ")");
	            groupData5.add("4월(" + currYear + ")");
	            groupData5.add("5월(" + currYear + ")");
	            List<String> groupData6 = new ArrayList<String>();
	            groupData6.add("6월(" + currYear + ")");
	            groupData6.add("7월(" + currYear + ")");
	            groupData6.add("8월(" + currYear + ")");
	            List<String> groupData7 = new ArrayList<String>();
	            groupData7.add("9월(" + currYear + ")");
	            groupData7.add("10월(" + currYear + ")");
	            groupData7.add("11월(" + currYear + ")");
	            List<String> groupData8 = new ArrayList<String>();
	            groupData8.add("12월(" + currYear + ")");
	            groupData8.add("1월(" + currYear + ")");
	            groupData8.add("2월(" + currYear + ")");
	            groupDatas.add(groupData1);
	            groupDatas.add(groupData2);
	            groupDatas.add(groupData3);
	            groupDatas.add(groupData4);
	            groupDatas.add(groupData5);
	            groupDatas.add(groupData6);
	            groupDatas.add(groupData7);
	            groupDatas.add(groupData8);
	            chartData.put("groupData", groupDatas);
	            
	            for(int i=1; i<=12; i++) {
	            	System.out.println(""+ i + "월(" + lastYear + ")" + ", " + ""+ i + "월(" + currYear + ")");
	            	dataMap.put(""+ i + "월(" + lastYear + ")", new ArrayList<String>(Arrays.asList(new String[dIndex.size()])));
	            	dataMap.put(""+ i + "월(" + currYear + ")", new ArrayList<String>(Arrays.asList(new String[dIndex.size()])));
	            }	        
		        
	            for (Cl cc : lastYearList) {
	            	if(cc!=null) {
	            		if(cc.getInsertDate().equals("03")) dataMap.get("3월(" + lastYear + ")").set(0, CalculationUtil.getValue(cc, columns.get(0)));
	            		else if(cc.getInsertDate().equals("06")) dataMap.get("6월(" + lastYear + ")").set(1, CalculationUtil.getValue(cc, columns.get(0)));
	            		else if(cc.getInsertDate().equals("09")) dataMap.get("9월(" + lastYear + ")").set(2, CalculationUtil.getValue(cc, columns.get(0)));
	            		else if(cc.getInsertDate().equals("12")) dataMap.get("12월(" + lastYear + ")").set(3, CalculationUtil.getValue(cc, columns.get(0)));
	
	            		else if(cc.getInsertDate().equals("04")) dataMap.get("4월(" + lastYear + ")").set(0, CalculationUtil.getValue(cc, columns.get(0)));
	            		else if(cc.getInsertDate().equals("07")) dataMap.get("7월(" + lastYear + ")").set(1, CalculationUtil.getValue(cc, columns.get(0)));
	            		else if(cc.getInsertDate().equals("10")) dataMap.get("10월(" + lastYear + ")").set(2, CalculationUtil.getValue(cc, columns.get(0)));
	            		else if(cc.getInsertDate().equals("01")) dataMap.get("1월(" + lastYear + ")").set(3, CalculationUtil.getValue(cc, columns.get(0)));
	
	            		else if(cc.getInsertDate().equals("05")) dataMap.get("5월(" + lastYear + ")").set(0, CalculationUtil.getValue(cc, columns.get(0)));
	            		else if(cc.getInsertDate().equals("08")) dataMap.get("8월(" + lastYear + ")").set(1, CalculationUtil.getValue(cc, columns.get(0)));
	            		else if(cc.getInsertDate().equals("11")) dataMap.get("11월(" + lastYear + ")").set(2, CalculationUtil.getValue(cc, columns.get(0)));
	            		else if(cc.getInsertDate().equals("02")) dataMap.get("2월(" + lastYear + ")").set(3, CalculationUtil.getValue(cc, columns.get(0)));
	            	}
	            }
	            
	            for (Cl cc : thisYearList) {
	            	if(cc!=null) {
	            		if(cc.getInsertDate().equals("03")) dataMap.get("3월(" + currYear + ")").set(0, CalculationUtil.getValue(cc, columns.get(0)));
	            		else if(cc.getInsertDate().equals("06")) dataMap.get("6월(" + currYear + ")").set(1, CalculationUtil.getValue(cc, columns.get(0)));
	            		else if(cc.getInsertDate().equals("09")) dataMap.get("9월(" + currYear + ")").set(2, CalculationUtil.getValue(cc, columns.get(0)));
	            		else if(cc.getInsertDate().equals("12")) dataMap.get("12월(" + currYear + ")").set(3, CalculationUtil.getValue(cc, columns.get(0)));
	
	            		else if(cc.getInsertDate().equals("04")) dataMap.get("4월(" + currYear + ")").set(0, CalculationUtil.getValue(cc, columns.get(0)));
	            		else if(cc.getInsertDate().equals("07")) dataMap.get("7월(" + currYear + ")").set(1, CalculationUtil.getValue(cc, columns.get(0)));
	            		else if(cc.getInsertDate().equals("10")) dataMap.get("10월(" + currYear + ")").set(2, CalculationUtil.getValue(cc, columns.get(0)));
	            		else if(cc.getInsertDate().equals("01")) dataMap.get("1월(" + currYear + ")").set(3, CalculationUtil.getValue(cc, columns.get(0)));

	            		else if(cc.getInsertDate().equals("05")) dataMap.get("5월(" + currYear + ")").set(0, CalculationUtil.getValue(cc, columns.get(0)));
	            		else if(cc.getInsertDate().equals("08")) dataMap.get("8월(" + currYear + ")").set(1, CalculationUtil.getValue(cc, columns.get(0)));
	            		else if(cc.getInsertDate().equals("11")) dataMap.get("11월(" + currYear + ")").set(2, CalculationUtil.getValue(cc, columns.get(0)));
	            		else if(cc.getInsertDate().equals("02")) dataMap.get("2월(" + currYear + ")").set(3, CalculationUtil.getValue(cc, columns.get(0)));
	            	}
	            }
	        } else { //period type : 1 (직전년도간 월별 비교)
	        	if(search.getClas() == 0) search.setClasField("id");
	            else search.setClasField("id");
	        	List<ComboData> columns = scBuildingAnalyticsService.getClasList(search);
	        	
	        	SearchUsed su = new SearchUsed();
	            su.setEnergy(search.getEnergy());
	            su.setPeriodType(search.getPeriodType());
	            su.setDate(search.getDate());
	            su.setList(columns);
	            
	            List<Cl> thisYearList = scBuildingAnalyticsService.getMonthChartList(su);
	            
	            Calendar currentCal = Calendar.getInstance();
	            currentCal.setTime(Search.DATE_FORMAT.parse(search.getDate()));
	            String currDate = Search.MONTH_FORMAT.format(new Date(currentCal.getTimeInMillis()));
	            
	            Calendar lastCal = Calendar.getInstance();
	            lastCal.setTime(Search.DATE_FORMAT.parse(search.getDate()));
	            lastCal.add(Calendar.YEAR, -1);
	           
	            su.setDate(Search.DATE_FORMAT.format(new Date(lastCal.getTimeInMillis())));
	           
	            List<Cl> lastYearList = scBuildingAnalyticsService.getMonthChartList(su);       
            
	            List<String> xAxisData = new ArrayList<String>();	            
	            List<String> dIndex = new ArrayList<String>();
	            for(int i=0; i<12 ;i++) {
	            	xAxisData.add(""+(i+1));
	            	dIndex.add(""+i);  
	            }
	            chartData.put("xAxisData", xAxisData);
		        chartData.put("dataset", dataMap);
	            
		        String lastYear = Search.YEAR_FORMAT.format(new Date(lastCal.getTimeInMillis()));
	            String currYear = Search.YEAR_FORMAT.format(new Date(currentCal.getTimeInMillis()));
	            
            	dataMap.put(lastYear, new ArrayList<String>(Arrays.asList(new String[dIndex.size()])));
            	dataMap.put(currYear, new ArrayList<String>(Arrays.asList(new String[dIndex.size()])));	            	        		        		        		       
	            
            	int i = 0;
	            for (Cl cc : lastYearList) {
	            	if(cc!=null) {	            		
	            		dataMap.get(lastYear).set(i, CalculationUtil.getValue(cc, columns.get(0)));
	            		i++;
	            	}
	            }
	            int j = 0;
	            for (Cl cc : thisYearList) {
	            	if(cc!=null) {	            		
	            		dataMap.get(currYear).set(j, CalculationUtil.getValue(cc, columns.get(0)));
	            		j++;
	            	}
	            }
	        }
        
            return new SimpleDataResult(true, chartData);
        } catch (Exception e) {
            e.printStackTrace();
            return new SimpleResult(false, CityUtil.myExceptionTypeConvert(e).getMessage());
        }
    }    
    
}
