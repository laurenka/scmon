package city.manage.web;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import city.beans.Cl;
import city.beans.ClasB;
import city.beans.SearchUsed;
import city.dao.mapper.ScIndustryDemandMapper;
import city.domain.ComboData;
import city.domain.Search;

@Service("scIndustryDemandService")
public class ScIndustryDemandService {

    @Autowired
    ScIndustryDemandMapper scIndustryDemandMapper;
    
    public List<ComboData> getEnergyList() throws Exception {
        return scIndustryDemandMapper.getEnergyList();
    }
    
    public List<ComboData> getClasBList(Search search) throws Exception {
        return scIndustryDemandMapper.getClasBList(search);
    }
    
    public List<ComboData> getClasCList(Search search) throws Exception {
        return scIndustryDemandMapper.getClasCList(search);
    }
    
    public List<ComboData> getClasList(Search search) throws Exception {
        return scIndustryDemandMapper.getClasList(search);
    }
    
    public List<Cl> getChartList(SearchUsed search) throws Exception {
        return scIndustryDemandMapper.getChartList(search);
    }
    
    
}
