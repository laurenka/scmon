package city.manage.web;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.joda.time.DateTime;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import city.beans.Cl;
import city.beans.ScDashboardItem;
import city.beans.EqCate;
import city.beans.SearchUsed;
import city.cmm.module.CalculationUtil;
import city.cmm.module.ChartXAxisUtil;
import city.cmm.util.CityUtil;
import city.domain.ComboData;
import city.domain.Search;
import city.domain.SimpleDataResult;
import city.domain.SimpleResult;
import city.menu.service.MenuService;

@Controller
public class ScDashboardController {
    @Autowired MenuService menuService;
    @Autowired ScDashboardService scDashboardService;
 
    @RequestMapping(value="/{workspace}/scDashboard")
    public String getScDashboard(HttpServletRequest req, Model model, @PathVariable("workspace") String workspace) {
    	model.addAttribute("workspace", workspace);
        return "scDashboard";
    }

    @ResponseBody
    @RequestMapping(value="/{ws}/getCurrCateToe", method=RequestMethod.POST, produces="application/json;charset=utf8")
    public SimpleResult getCurrCateToe(HttpServletRequest req, Model model) {
        try {
            DateTime now = new DateTime().withSecondOfMinute(0).plusMinutes(-2);
            ScDashboardItem searchItem = new ScDashboardItem();
            searchItem.setDate(now.toString(CityUtil.realTimeFmt));
  
            model.addAttribute("cateToe", scDashboardService.getCurrCateToe(searchItem));

            return new SimpleDataResult(true, model);
        } catch (Exception e) {
            e.printStackTrace();
        }

        return new SimpleResult(false);
    }
    
    @ResponseBody
    @RequestMapping(value="/{ws}/getCurrEnergyToe", method=RequestMethod.POST, produces="application/json;charset=utf8")
    public SimpleResult getCurrEnergyToe(HttpServletRequest req, Model model) {
        try {
            DateTime now = new DateTime().withSecondOfMinute(0).plusMinutes(-2);
            ScDashboardItem searchItem = new ScDashboardItem();
            searchItem.setDate(now.toString(CityUtil.realTimeFmt));
  
            model.addAttribute("energyToe", scDashboardService.getCurrEnergyToe(searchItem));

            return new SimpleDataResult(true, model);
        } catch (Exception e) {
            e.printStackTrace();
        }

        return new SimpleResult(false);
    }
    
    @ResponseBody
    @RequestMapping(value="/{ws}/getCurrEnergyPieToe", method=RequestMethod.POST, produces="application/json;charset=utf8")
    public SimpleResult getCurrEnergyPieToe(HttpServletRequest req, Model model,
    		@RequestParam(value="clasA", required=false, defaultValue="-1") Integer clasA) {
        try {
            DateTime now = new DateTime().withSecondOfMinute(0).plusMinutes(-2);
            ScDashboardItem searchItem = new ScDashboardItem();
            searchItem.setDate(now.toString(CityUtil.realTimeFmt));
            searchItem.setClasA(clasA);
            model.addAttribute("energyPieToe", scDashboardService.getCurrEnergyPieToe(searchItem));

            return new SimpleDataResult(true, model);
        } catch (Exception e) {
            e.printStackTrace();
        }

        return new SimpleResult(false);
    }
    
    @ResponseBody
    @RequestMapping(value="/{ws}/getCurrEnergyBar", method=RequestMethod.POST, produces="application/json;charset=utf8")
    public SimpleResult getCurrEnergyBarToe(HttpServletRequest req, Model model,
    		@RequestParam(value="clasA", required=false, defaultValue="-1") Integer clasA) {
        try {
            DateTime now = new DateTime().withSecondOfMinute(0).plusMinutes(-2);
            ScDashboardItem searchItem = new ScDashboardItem();
            searchItem.setDate(now.toString(CityUtil.realTimeFmt));
            searchItem.setClasA(clasA);
            model.addAttribute("energyBar", scDashboardService.getCurrEnergyBar(searchItem));
            
            
            
//            List<ComboData> columns = scDashboardService.getClasList(search);
            
            return new SimpleDataResult(true, model);
        } catch (Exception e) {
            e.printStackTrace();
        }

        return new SimpleResult(false);
    }
}
