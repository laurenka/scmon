package city.manage.web;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import city.beans.Cl;
import city.beans.ClasC;
import city.beans.EqCate;
import city.beans.EquipCate;
import city.beans.SearchUsed;
import city.dao.mapper.ScPublicAnalyticsMapper;
import city.domain.ComboData;
import city.domain.Search;

@Service("scPublicAnalyticsService")
public class ScPublicAnalyticsService {

    @Autowired
    ScPublicAnalyticsMapper scPublicAnalyticsMapper;
    
    public List<ComboData> getEnergyList() throws Exception {
        return scPublicAnalyticsMapper.getEnergyList();
    }
    
    public List<ComboData> getClasAList(Search search) throws Exception {
        return scPublicAnalyticsMapper.getClasAList(search);
    }
    
    public List<ComboData> getClasList(Search search) throws Exception {
        return scPublicAnalyticsMapper.getClasList(search);
    }
    
    public List<ComboData> getClasBList(Search search) throws Exception {
        return scPublicAnalyticsMapper.getClasBList(search);
    }
    
    public List<ComboData> getClasCList(Search search) throws Exception {
        return scPublicAnalyticsMapper.getClasCList(search);
    }
    
    public List<ComboData> getEqCateList(Search search) throws Exception {
        return scPublicAnalyticsMapper.getEqCateList(search);
    } 
    
    public List<ClasC> getClassB11ChartList(Search search) throws Exception {
        return scPublicAnalyticsMapper.getClassB11ChartList(search);
    }
    
    public List<ClasC> getClassB21ChartList(Search search) throws Exception {
        return scPublicAnalyticsMapper.getClassB21ChartList(search);
    }
    

    public List<ClasC> getClassB22ChartList(Search search) throws Exception {
        return scPublicAnalyticsMapper.getClassB22ChartList(search);
    }

    public List<ClasC> getClassB23ChartList(Search search) throws Exception {
        return scPublicAnalyticsMapper.getClassB23ChartList(search);
    }

    public List<ClasC> getClassB24ChartList(Search search) throws Exception {
        return scPublicAnalyticsMapper.getClassB24ChartList(search);
    }

    public List<ClasC> getClassB25ChartList(Search search) throws Exception {
        return scPublicAnalyticsMapper.getClassB25ChartList(search);
    }

    public List<ClasC> getClassB26ChartList(Search search) throws Exception {
        return scPublicAnalyticsMapper.getClassB26ChartList(search);
    }

    public List<ClasC> getClassB31ChartList(Search search) throws Exception {
        return scPublicAnalyticsMapper.getClassB31ChartList(search);
    }

    public List<ClasC> getClassB41ChartList(Search search) throws Exception {
        return scPublicAnalyticsMapper.getClassB41ChartList(search);
    }

    public List<ClasC> getClassB42ChartList(Search search) throws Exception {
        return scPublicAnalyticsMapper.getClassB42ChartList(search);
    }

    public List<ClasC> getClassB43ChartList(Search search) throws Exception {
        return scPublicAnalyticsMapper.getClassB43ChartList(search);
    }

    public List<ClasC> getClassB44ChartList(Search search) throws Exception {
        return scPublicAnalyticsMapper.getClassB44ChartList(search);
    }

    public List<ClasC> getClassB45ChartList(Search search) throws Exception {
        return scPublicAnalyticsMapper.getClassB45ChartList(search);
    }

    public List<ClasC> getClassB46ChartList(Search search) throws Exception {
        return scPublicAnalyticsMapper.getClassB46ChartList(search);
    }

    public List<Cl> getChartList(SearchUsed search) throws Exception {
        return scPublicAnalyticsMapper.getChartList(search);
    }
    
    public List<Cl> getSeasonChartList(SearchUsed search) throws Exception {
        return scPublicAnalyticsMapper.getSeasonChartList(search);
    }
    
    public List<Cl> getMonthChartList(SearchUsed search) throws Exception {
        return scPublicAnalyticsMapper.getMonthChartList(search);
    }
    
//    public List<ClasC> getClassCChartList(Map search) throws Exception {
//        return scPublicAnalyticsMapper.getClassCChartList(search);
//    }
}
