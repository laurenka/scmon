package city.manage.web;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import city.beans.Cl;
import city.beans.SearchUsed;
import city.dao.mapper.ScPublicEnergyMapper;
import city.domain.ComboData;
import city.domain.Search;

@Service("scPublicEnergyService")
public class ScPublicEnergyService {

    @Autowired
    ScPublicEnergyMapper scPublicEnergyMapper;
    
    public List<ComboData> getEnergyList() throws Exception {
        return scPublicEnergyMapper.getEnergyList();
    }
    
    public List<ComboData> getClasBList(Search search) throws Exception {
        return scPublicEnergyMapper.getClasBList(search);
    }
    
    public List<ComboData> getClasList(Search search) throws Exception {
        return scPublicEnergyMapper.getClasList(search);
    }
   
    public List<Cl> getChartList(SearchUsed search) throws Exception {
        return scPublicEnergyMapper.getChartList(search);
    }
    
}
