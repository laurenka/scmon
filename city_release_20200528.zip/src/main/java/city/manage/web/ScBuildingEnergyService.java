package city.manage.web;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import city.beans.Cl;
import city.beans.SearchUsed;
import city.dao.mapper.ScBuildingEnergyMapper;
import city.domain.ComboData;
import city.domain.Search;

@Service("scBuildingEnergyService")
public class ScBuildingEnergyService {

    @Autowired
    ScBuildingEnergyMapper scBuildingEnergyMapper;
    
    public List<ComboData> getEnergyList() throws Exception {
        return scBuildingEnergyMapper.getEnergyList();
    }
    
    public List<ComboData> getClasBList(Search search) throws Exception {
        return scBuildingEnergyMapper.getClasBList(search);
    }
    
    public List<ComboData> getClasList(Search search) throws Exception {
        return scBuildingEnergyMapper.getClasList(search);
    }
   
    public List<Cl> getChartList(SearchUsed search) throws Exception {
        return scBuildingEnergyMapper.getChartList(search);
    }
    
}
