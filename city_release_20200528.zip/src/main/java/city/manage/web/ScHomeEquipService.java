package city.manage.web;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import city.beans.ClasC;
import city.beans.EqCate;
import city.beans.EquipCate;
import city.beans.SearchUsed;
import city.dao.mapper.ScHomeEquipMapper;
import city.domain.ComboData;
import city.domain.Search;

@Service("scHomeEquipService")
public class ScHomeEquipService {

    @Autowired
    ScHomeEquipMapper scHomeEquipMapper;
    
    public List<ComboData> getEnergyList() throws Exception {
        return scHomeEquipMapper.getEnergyList();
    }
    
    public List<ComboData> getClasAList(Search search) throws Exception {
        return scHomeEquipMapper.getClasAList(search);
    }
    
    public List<ComboData> getClasBList(Search search) throws Exception {
        return scHomeEquipMapper.getClasBList(search);
    }
    
    public List<ComboData> getClasCList(Search search) throws Exception {
        return scHomeEquipMapper.getClasCList(search);
    }
    
    public List<ComboData> getEqCateList(Search search) throws Exception {
        return scHomeEquipMapper.getEqCateList(search);
    } 
    
    public List<ComboData> getEqCate(Search search) throws Exception {
        return scHomeEquipMapper.getEqCate(search);
    } 
    
    public List<ClasC> getClassB11ChartList(Search search) throws Exception {
        return scHomeEquipMapper.getClassB11ChartList(search);
    }
    
    public List<ClasC> getClassB21ChartList(Search search) throws Exception {
        return scHomeEquipMapper.getClassB21ChartList(search);
    }
    

    public List<ClasC> getClassB22ChartList(Search search) throws Exception {
        return scHomeEquipMapper.getClassB22ChartList(search);
    }

    public List<ClasC> getClassB23ChartList(Search search) throws Exception {
        return scHomeEquipMapper.getClassB23ChartList(search);
    }

    public List<ClasC> getClassB24ChartList(Search search) throws Exception {
        return scHomeEquipMapper.getClassB24ChartList(search);
    }

    public List<ClasC> getClassB25ChartList(Search search) throws Exception {
        return scHomeEquipMapper.getClassB25ChartList(search);
    }

    public List<ClasC> getClassB26ChartList(Search search) throws Exception {
        return scHomeEquipMapper.getClassB26ChartList(search);
    }

    public List<ClasC> getClassB31ChartList(Search search) throws Exception {
        return scHomeEquipMapper.getClassB31ChartList(search);
    }

    public List<ClasC> getClassB41ChartList(Search search) throws Exception {
        return scHomeEquipMapper.getClassB41ChartList(search);
    }

    public List<ClasC> getClassB42ChartList(Search search) throws Exception {
        return scHomeEquipMapper.getClassB42ChartList(search);
    }

    public List<ClasC> getClassB43ChartList(Search search) throws Exception {
        return scHomeEquipMapper.getClassB43ChartList(search);
    }

    public List<ClasC> getClassB44ChartList(Search search) throws Exception {
        return scHomeEquipMapper.getClassB44ChartList(search);
    }

    public List<ClasC> getClassB45ChartList(Search search) throws Exception {
        return scHomeEquipMapper.getClassB45ChartList(search);
    }

    public List<ClasC> getClassB46ChartList(Search search) throws Exception {
        return scHomeEquipMapper.getClassB46ChartList(search);
    }

    public List<EqCate> getChartList(SearchUsed search) throws Exception {
        return scHomeEquipMapper.getChartList(search);
    }
    
//    public List<ClasC> getClassCChartList(Map search) throws Exception {
//        return scHomeEquipMapper.getClassCChartList(search);
//    }
}
