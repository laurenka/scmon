package city.manage.web;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import city.beans.EqCate;
import city.beans.SearchUsed;
import city.cmm.module.CalculationUtil;
import city.cmm.module.ChartXAxisUtil;
import city.cmm.util.CityUtil;
import city.domain.ComboData;
import city.domain.Search;
import city.domain.SimpleDataResult;
import city.domain.SimpleResult;
import city.menu.service.MenuService;

@Controller
public class ScBuildingEquipController {
    @Autowired MenuService menuService;
    @Autowired ScBuildingEquipService scBuildingEquipService;
 
    @RequestMapping(value="/{workspace}/scBuildingEquip")
    public String getScManageEquip(HttpServletRequest req, Model model, @PathVariable("workspace") String workspace) {
    	model.addAttribute("workspace", workspace);
        return "scBuildingEquip";
    }

    @ResponseBody
    @RequestMapping(value="/{ws}/scBuildingEquip/getEnergy", method=RequestMethod.POST, produces="application/json;charset=utf8")
    public SimpleResult getEnergyList(HttpServletRequest req) {
        try {          
        	return new SimpleDataResult(true, scBuildingEquipService.getEnergyList());       
        } catch (Exception e) {
            e.printStackTrace();
            return new SimpleResult(false, e.getMessage());
        }
    }       
    
    @ResponseBody
    @RequestMapping(value="/{ws}/scBuildingEquip/getClasB", method=RequestMethod.POST, produces="application/json;charset=utf8")
    public SimpleResult getClasBList(HttpServletRequest req, Search search) {
        try {          
        	return new SimpleDataResult(true, scBuildingEquipService.getClasBList(search));       
        } catch (Exception e) {
            e.printStackTrace();
            return new SimpleResult(false, e.getMessage());
        }
    }
    
    @ResponseBody
    @RequestMapping(value="/{ws}/scBuildingEquip/getClasC", method=RequestMethod.POST, produces="application/json;charset=utf8")
    public SimpleResult getClasCList(HttpServletRequest req, Search search) {
        try {          
        	return new SimpleDataResult(true, scBuildingEquipService.getClasCList(search));       
        } catch (Exception e) {
            e.printStackTrace();
            return new SimpleResult(false, e.getMessage());
        }
    }
    
    @ResponseBody
    @RequestMapping(value="/{ws}/scBuildingEquip/getEqCate", method=RequestMethod.POST, produces="application/json;charset=utf8")
    public SimpleResult getClasAList(HttpServletRequest req, Search search) {
        try {          
        	return new SimpleDataResult(true, scBuildingEquipService.getEqCateList(search));       
        } catch (Exception e) {
            e.printStackTrace();
            return new SimpleResult(false, e.getMessage());
        }
    }

    @ResponseBody
    @RequestMapping(value = "/{ws}/scBuildingEquip/getChartList", method = RequestMethod.POST, produces = "application/json;charset=utf-8")
    public SimpleResult getChartList(HttpServletRequest req, Search search) {
        search.setIsChart(1);
        search.calcTime();
        search.setItem(1);
        
        Map<String, Object> chartData = new HashMap<>();
        Map<String, List<String>> dataMap = new HashMap<>();
        Map<String, Integer> indexMap = new HashMap<>();
        
        try {
            List<ComboData> columns = scBuildingEquipService.getEqCate(search);

            List<String> xAxisData = city.cmm.module.ChartXAxisUtil.makeData(indexMap, search);
            chartData.put("xAxisData", xAxisData);
            chartData.put("dataset", dataMap);
            
            for (ComboData cd : columns) {
                List<String> dataList = new ArrayList<>(Arrays.asList(new String[xAxisData.size()]));
                dataMap.put(cd.getName(), dataList);
            }
            
            SearchUsed su = new SearchUsed();
            su.setEnergy(search.getEnergy());
            su.setPeriodType(search.getPeriodType());
            su.setDate(search.getDate());
            su.setList(columns);
            List<EqCate> list = scBuildingEquipService.getChartList(su);

            for (EqCate cc : list) {
            	if(cc!=null) {
	            	Integer index = 0;
	            	if(search.getPeriodType() == 0) index = ChartXAxisUtil.getMapIndex(search, indexMap, cc.getInsertDate().substring(8, 10), null);
	            	else index = ChartXAxisUtil.getMapIndex(search, indexMap, cc.getInsertDate().substring(5, 7), null);
	            	for (ComboData cd : columns) {
	                  dataMap.get(cd.getName()).set(index, CalculationUtil.getValue(cc, cd));
	            	}
            	}
            }
            
            return new SimpleDataResult(true, chartData);
        } catch (Exception e) {
            e.printStackTrace();
            return new SimpleResult(false, CityUtil.myExceptionTypeConvert(e).getMessage());
        }
    }
}
