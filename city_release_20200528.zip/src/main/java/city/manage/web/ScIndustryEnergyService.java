package city.manage.web;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import city.beans.Cl;
import city.beans.SearchUsed;
import city.dao.mapper.ScIndustryEnergyMapper;
import city.domain.ComboData;
import city.domain.Search;

@Service("scIndustryEnergyService")
public class ScIndustryEnergyService {

    @Autowired
    ScIndustryEnergyMapper scIndustryEnergyMapper;
    
    public List<ComboData> getEnergyList() throws Exception {
        return scIndustryEnergyMapper.getEnergyList();
    }
    
    public List<ComboData> getClasBList(Search search) throws Exception {
        return scIndustryEnergyMapper.getClasBList(search);
    }
    
    public List<ComboData> getClasList(Search search) throws Exception {
        return scIndustryEnergyMapper.getClasList(search);
    }
   
    public List<Cl> getChartList(SearchUsed search) throws Exception {
        return scIndustryEnergyMapper.getChartList(search);
    }
    
}
