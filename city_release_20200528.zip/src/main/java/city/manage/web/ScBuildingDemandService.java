package city.manage.web;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import city.beans.Cl;
import city.beans.ClasB;
import city.beans.SearchUsed;
import city.dao.mapper.ScBuildingDemandMapper;
import city.domain.ComboData;
import city.domain.Search;

@Service("scBuildingDemandService")
public class ScBuildingDemandService {

    @Autowired
    ScBuildingDemandMapper scBuildingDemandMapper;
    
    public List<ComboData> getEnergyList() throws Exception {
        return scBuildingDemandMapper.getEnergyList();
    }
    
    public List<ComboData> getClasBList(Search search) throws Exception {
        return scBuildingDemandMapper.getClasBList(search);
    }
    
    public List<ComboData> getClasCList(Search search) throws Exception {
        return scBuildingDemandMapper.getClasCList(search);
    }
    
    public List<ComboData> getClasList(Search search) throws Exception {
        return scBuildingDemandMapper.getClasList(search);
    }
    
    public List<Cl> getChartList(SearchUsed search) throws Exception {
        return scBuildingDemandMapper.getChartList(search);
    }
    
    
}
