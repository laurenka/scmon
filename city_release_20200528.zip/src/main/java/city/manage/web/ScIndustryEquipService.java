package city.manage.web;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import city.beans.ClasC;
import city.beans.EqCate;
import city.beans.EquipCate;
import city.beans.SearchUsed;
import city.dao.mapper.ScIndustryEquipMapper;
import city.domain.ComboData;
import city.domain.Search;

@Service("scIndustryEquipService")
public class ScIndustryEquipService {

    @Autowired
    ScIndustryEquipMapper scIndustryEquipMapper;
    
    public List<ComboData> getEnergyList() throws Exception {
        return scIndustryEquipMapper.getEnergyList();
    }
    
    public List<ComboData> getClasAList(Search search) throws Exception {
        return scIndustryEquipMapper.getClasAList(search);
    }
    
    public List<ComboData> getClasBList(Search search) throws Exception {
        return scIndustryEquipMapper.getClasBList(search);
    }
    
    public List<ComboData> getClasCList(Search search) throws Exception {
        return scIndustryEquipMapper.getClasCList(search);
    }
    
    public List<ComboData> getEqCateList(Search search) throws Exception {
        return scIndustryEquipMapper.getEqCateList(search);
    } 
    
    public List<ComboData> getEqCate(Search search) throws Exception {
        return scIndustryEquipMapper.getEqCate(search);
    } 
    
    public List<ClasC> getClassB11ChartList(Search search) throws Exception {
        return scIndustryEquipMapper.getClassB11ChartList(search);
    }
    
    public List<ClasC> getClassB21ChartList(Search search) throws Exception {
        return scIndustryEquipMapper.getClassB21ChartList(search);
    }
    

    public List<ClasC> getClassB22ChartList(Search search) throws Exception {
        return scIndustryEquipMapper.getClassB22ChartList(search);
    }

    public List<ClasC> getClassB23ChartList(Search search) throws Exception {
        return scIndustryEquipMapper.getClassB23ChartList(search);
    }

    public List<ClasC> getClassB24ChartList(Search search) throws Exception {
        return scIndustryEquipMapper.getClassB24ChartList(search);
    }

    public List<ClasC> getClassB25ChartList(Search search) throws Exception {
        return scIndustryEquipMapper.getClassB25ChartList(search);
    }

    public List<ClasC> getClassB26ChartList(Search search) throws Exception {
        return scIndustryEquipMapper.getClassB26ChartList(search);
    }

    public List<ClasC> getClassB31ChartList(Search search) throws Exception {
        return scIndustryEquipMapper.getClassB31ChartList(search);
    }

    public List<ClasC> getClassB41ChartList(Search search) throws Exception {
        return scIndustryEquipMapper.getClassB41ChartList(search);
    }

    public List<ClasC> getClassB42ChartList(Search search) throws Exception {
        return scIndustryEquipMapper.getClassB42ChartList(search);
    }

    public List<ClasC> getClassB43ChartList(Search search) throws Exception {
        return scIndustryEquipMapper.getClassB43ChartList(search);
    }

    public List<ClasC> getClassB44ChartList(Search search) throws Exception {
        return scIndustryEquipMapper.getClassB44ChartList(search);
    }

    public List<ClasC> getClassB45ChartList(Search search) throws Exception {
        return scIndustryEquipMapper.getClassB45ChartList(search);
    }

    public List<ClasC> getClassB46ChartList(Search search) throws Exception {
        return scIndustryEquipMapper.getClassB46ChartList(search);
    }

    public List<EqCate> getChartList(SearchUsed search) throws Exception {
        return scIndustryEquipMapper.getChartList(search);
    }
    
//    public List<ClasC> getClassCChartList(Map search) throws Exception {
//        return scIndustryEquipMapper.getClassCChartList(search);
//    }
}
