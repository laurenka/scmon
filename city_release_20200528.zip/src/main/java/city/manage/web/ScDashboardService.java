package city.manage.web;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import city.beans.ScDashboardItem;
import city.dao.mapper.ScDashboardMapper;

@Service("scDashboardService")
public class ScDashboardService {

    @Autowired
    ScDashboardMapper scDashboardMapper;
   
    public ScDashboardItem getCurrCateToe(ScDashboardItem search) throws Exception {
        return scDashboardMapper.getCurrCateToe(search);
    }
    
    public ScDashboardItem getCurrEnergyToe(ScDashboardItem search) throws Exception {
        return scDashboardMapper.getCurrEnergyToe(search);
    }
    
    public ScDashboardItem getCurrEnergyPieToe(ScDashboardItem search) throws Exception {
        return scDashboardMapper.getCurrEnergyPieToe(search);
    }
    
    public ScDashboardItem getCurrEnergyBar(ScDashboardItem search) throws Exception {
        return scDashboardMapper.getCurrEnergyBar(search);
    }
}
