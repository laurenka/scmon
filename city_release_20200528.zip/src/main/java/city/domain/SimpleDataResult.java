package city.domain;

public class SimpleDataResult extends SimpleResult {
    
    private Object data;

    public SimpleDataResult(boolean result) {
        super(result);        
    }

    public SimpleDataResult(boolean result, Object data) {
        super(result);
        this.data = data;
    }    

    public Object getData() {
        return data;
    }

    public void setData(Object data) {
        this.data = data;
    }
}
