package city.domain;

public class FileInfo {
    private int domainId;
    private Integer id;
    private String fileName;
    private String filePath;

    public int getDomainId() {
        return domainId;
    }
    public void setDomainId(int domainId) {
        this.domainId = domainId;
    }
    public Integer getId() {
        return id;
    }
    public void setId(Integer id) {
        this.id = id;
    }
    public String getFileName() {
        return fileName;
    }
    public void setFileName(String fileOriginalName) {
        this.fileName = fileOriginalName;
    }
    public String getFilePath() {
        return filePath;
    }
    public void setFilePath(String filePath) {
        this.filePath = filePath;
    }
}
