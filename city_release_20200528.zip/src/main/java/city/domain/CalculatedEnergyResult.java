package city.domain;

public class CalculatedEnergyResult {
	String check_date;
	double fil_rslt_valu;
	public String getCheck_date() {
		return check_date;
	}
	public void setCheck_date(String check_date) {
		this.check_date = check_date;
	}
	public double getFil_rslt_valu() {
		return fil_rslt_valu;
	}
	public void setFil_rslt_valu(double fil_rslt_valu) {
		this.fil_rslt_valu = fil_rslt_valu;
	}
	
}
