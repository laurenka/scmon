package city.domain;

public class ComboData {

    private String id;
    private String name;
    private String subName;
    private String subName2;
    private String subName3;
    

    public ComboData() {
    }

    public ComboData(String id, String name) {
        this.id = id;
        this.name = name;
    }

   

	public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSubName() {
        return subName;
    }

    public void setSubName(String subName) {
        this.subName = subName;
    }

    public String getSubName2() {
        return subName2;
    }

    public void setSubName2(String subName2) {
        this.subName2 = subName2;
    }

    public String getSubName3() {
        return subName3;
    }

    public void setSubName3(String subName3) {
        this.subName3 = subName3;
    }

}
