package city.domain;

import java.util.ArrayList;
import java.util.List;

public class TreeMenuItem<T> {
    private T item;
    @SuppressWarnings("rawtypes")
    private List children = new ArrayList();
    
    public TreeMenuItem( T item ) {
        this.item = item;
    }
    
    public T getItem() {
        return item;
    }

    public void setItem(T item) {
        this.item = item;
    }    

    @SuppressWarnings("rawtypes")
    public List getChildren() {
        return children;
    }

    @SuppressWarnings("rawtypes")
    public void setChildren(List children) {
        this.children = children;
    }
    
    @SuppressWarnings("unchecked")
    public void addChildren(Object item) {
        this.children.add(item);
    }
}
