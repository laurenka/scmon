package city.web.user;

import java.sql.SQLException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import city.domain.ComboData;
import city.domain.SimpleDataResult;
import city.domain.SimpleResult;
import city.domain.User;
import city.cmm.util.CityUtil;
//import city.web.alert.AlarmService;
import city.login.web.LoginController;

@Controller
public class UserController {

    @Autowired UserService userService;
//    @Autowired AlarmService alarmService;

    @RequestMapping("/{workspace}/systemAccount")
    public String systemAccount(HttpServletRequest req,Model model, @PathVariable("workspace") String workspace) {
        model.addAttribute("workspace", workspace);
        model.addAttribute("depth", LoginController.getUser(req).getDeptId());
        return "systemAccount";
    }

    @ResponseBody
    @RequestMapping(value = "/{workspace}/system/account/selectUsers")
    public SimpleResult selectUser(
            HttpServletRequest req, 
            Model model,
            @RequestParam(value="page", required=true) int page,
            @RequestParam(value="limit", required=true) int limit) {
        try {
            User user = LoginController.getUser(req);
            List<User> list = userService.getUserList(user, limit * (page - 1), limit);
            int totalSize = userService.getUserCount(user);
            
            CityUtil.makePageModel(model, page, limit, list, totalSize);
            return new SimpleDataResult(true, model);
        } catch (Exception e) {
            e.printStackTrace();
            return new SimpleResult(false, e.getMessage());
        }
    }
    
    @ResponseBody
    @RequestMapping(value="/{workspace}/system/account/getUserGrantList", method=RequestMethod.POST, produces = "application/json;charset=utf-8")
    public SimpleDataResult getUserGrantList(HttpServletRequest req) {
        List<ComboData> list = null;
        try {
            list = userService.getUserGrantList(LoginController.getUser(req).getDeptId()); 
            return new SimpleDataResult(true, list);
        } catch (Exception e) {
            e.printStackTrace();
            return new SimpleDataResult(false, list);
        }
    }
    
    @ResponseBody
    @RequestMapping(value="/{workspace}/system/account/insertUser", method=RequestMethod.POST, produces="application/json;charset=utf-8")
    public SimpleResult insertUser(HttpServletRequest req, User user) {
        try {
            user.setWorkspaceId(LoginController.getUser(req).getWorkspaceId());
            userService.insertUser(user);
        } catch (SQLException e) {
            e.printStackTrace();
            Exception my = CityUtil.myExceptionTypeConvert(e);
            return new SimpleResult(false, my.getMessage());
        } catch (Exception e) {
            e.printStackTrace();
            Exception my = CityUtil.myExceptionTypeConvert(e);
            return new SimpleResult(false, my.getMessage());
        }
        
//        try {
//            alarmService.insertUserInsertAlaram(LoginController.getUser(req).getWorkspaceId(), user.getUserName());
//        } catch (Exception e) {
//            e.printStackTrace();
//        }

        return new SimpleResult(true);
    }
    
    @ResponseBody
    @RequestMapping(value="/{workspace}/system/account/updateUser", method=RequestMethod.POST, produces="application/json;charset=utf-8")
    public SimpleResult updateUser(HttpServletRequest req, User user) {
        Integer oriUser = null;
        try {
//            oriUser = alarmService.getUserGradeById(user.getId());
            userService.updateUser(user);
        } catch (Exception e) {
            e.printStackTrace();
            Exception my = CityUtil.myExceptionTypeConvert(e);
            return new SimpleResult(false, my.getMessage());
        }
        
//        try {
//            if (oriUser != user.getGradeId()) {
//                alarmService.insertUserUpdateAlaram(LoginController.getUser(req).getWorkspaceId(), user.getUserName(), user.getGradeId());
//            }
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
        
        return new SimpleResult(true);
    }
    
    @ResponseBody
    @RequestMapping(value="/{workspace}/system/account/deleteUser", method=RequestMethod.POST, produces="application/json;charset=utf-8")
    public SimpleResult deleteUser(HttpServletRequest req, User user) {
//        try {
//            alarmService.insertUserDeleteAlaram(LoginController.getUser(req).getWorkspaceId(), userService.getUserName(user));
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
        
        try {
            userService.deleteUser(user);
        } catch (Exception e) {
            e.printStackTrace();
            Exception my = CityUtil.myExceptionTypeConvert(e);
            return new SimpleResult(false, my.getMessage());
        }
        return new SimpleResult(true);
    }

    @ResponseBody
    @RequestMapping(value = "/{workspace}/system/account/selfInfo", method=RequestMethod.POST, produces="application/json;charset=utf-8")
    public SimpleResult selectSelfInfo(HttpServletRequest req, Model model) {
        try {
            model.addAttribute("self", userService.getSelfInfo(LoginController.getUser(req)));
            return new SimpleDataResult(true, model);
        } catch (Exception e) {
            e.printStackTrace();
            return new SimpleResult(false, e.getMessage());
        }
    }
    
    @ResponseBody
    @RequestMapping(value = "/{workspace}/system/account/checkNowPassword", method=RequestMethod.POST, produces="application/json;charset=utf-8")
    public SimpleResult checkNowPassword(HttpServletRequest req, User user) {
        try {
            user.setWorkspaceId(LoginController.getUser(req).getWorkspaceId());
            User validUser = userService.checkSelfPass(user);
            if (validUser == null) {
                return new SimpleResult(false, "아이디가 존재하지 않습니다.");
            } else {
                String validation = validUser.getUserPass();
                if ("1".equals(validation)) {
                    return new SimpleResult(true);
                } else {
                    return new SimpleResult(false, "비밀번호가 맞지 않습니다.");
                }
            }
        } catch(Exception e) {
            e.printStackTrace();
            Exception my = CityUtil.myExceptionTypeConvert(e);
            return new SimpleResult(false, my.getMessage());
        }
    }

    @ResponseBody
    @RequestMapping(value = "/{workspace}/system/account/updateSelfInfo",  method = RequestMethod.POST, produces = "application/json;charset=utf-8")
    public SimpleResult updateSelfInfo(HttpServletRequest req, User user) {
        try {
            user.setWorkspaceId(LoginController.getUser(req).getWorkspaceId());
            userService.updateSelfInfo(user);
            LoginController.getUser(req).setUserName(user.getUserName());
            return new SimpleResult(true);
        } catch (Exception e) {
            e.printStackTrace();
            Exception my = CityUtil.myExceptionTypeConvert(e);
            return new SimpleResult(false, my.getMessage());      
        }
    }
    
    
    
    
    

    @RequestMapping("/{workspace}/systemHost")
    public String host(HttpServletRequest req,Model model, @PathVariable("workspace") String workspace) {
        model.addAttribute("workspace", workspace);
        model.addAttribute("depth", LoginController.getUser(req).getDeptId());
        return "systemHost";
    }

//    @ResponseBody
//    @RequestMapping(value = "/{workspace}/system/getHostList",  method = RequestMethod.POST, produces = "application/json;charset=utf-8")
//    public SimpleResult getHostList(HttpServletRequest req, Model model, @RequestParam(value="page", required=true) int page, @RequestParam(value="limit", required=true) int limit) {
//        try {
//            List<HostFilter> list = userService.getHostInfo(limit * (page - 1), limit);
//            int totalSize = userService.getHostInfoCount();
//            
//            SmfemsUtil.makePageModel(model, page, limit, list, totalSize);
//            return new SimpleDataResult(true, model);
//        } catch (Exception e) {
//            e.printStackTrace();
//            return new SimpleResult(false, e.getMessage());
//        }
//    }
//    
//    @ResponseBody
//    @RequestMapping(value = "/{workspace}/system/insertHost",  method = RequestMethod.POST, produces = "application/json;charset=utf-8")
//    public SimpleResult insertHost(HttpServletRequest req, Model model, HostFilter hostFilter) {
//        try {
//        	userService.insertHost(hostFilter);
//            return new SimpleDataResult(true);
//        } catch (Exception e) {
//            e.printStackTrace();
//            return new SimpleResult(false, e.getMessage());
//        }
//    }
//    
//    @ResponseBody
//    @RequestMapping(value = "/{workspace}/system/updateHost",  method = RequestMethod.POST, produces = "application/json;charset=utf-8")
//    public SimpleResult updateHost(HttpServletRequest req, Model model, HostFilter hostFilter) {
//        try {
//        	userService.updateHost(hostFilter);
//            return new SimpleDataResult(true);
//        } catch (Exception e) {
//            e.printStackTrace();
//            return new SimpleResult(false, e.getMessage());
//        }
//    }
//    
//    @ResponseBody
//    @RequestMapping(value = "/{workspace}/system/deleteHost",  method = RequestMethod.POST, produces = "application/json;charset=utf-8")
//    public SimpleResult deleteHost(HttpServletRequest req, Model model, HostFilter hostFilter) {
//        try {
//        	userService.deleteHost(hostFilter);
//            return new SimpleDataResult(true);
//        } catch (Exception e) {
//            e.printStackTrace();
//            return new SimpleResult(false, e.getMessage());
//        }
//    }
}
