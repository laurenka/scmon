package city.web.user;

import java.sql.SQLException;
import java.util.List;

import org.apache.ibatis.session.RowBounds;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import city.dao.mapper.UserMapper;
import city.domain.ComboData;
import city.domain.User;

@Service("userService")
public class UserService {
	
    
    @Autowired
    private UserMapper userMapper;
    
    
    public List<User> getUserList(User user, int start, int limit) throws Exception {
        return userMapper.getUserList(user, start, limit);
    }
    
    
    public int getUserCount(User user) throws Exception {
        return userMapper.getUserCount(user);
    }
    
    
    public List<ComboData> getUserGrantList(int deptId) throws Exception {
        return userMapper.getUserGrantList(deptId);
    }
    
    @Transactional(propagation=Propagation.REQUIRED, isolation=Isolation.DEFAULT, rollbackFor={Exception.class,SQLException.class}, readOnly=false)
    public void insertUser(User user) throws Exception{
        userMapper.insertUser(user);
    }
    
    @Transactional(propagation=Propagation.REQUIRED, isolation=Isolation.DEFAULT, rollbackFor={Exception.class,SQLException.class}, readOnly=false)
    public void updateUser(User user ) throws Exception {
        userMapper.updateUser(user);
    }
    
    @Transactional(propagation=Propagation.REQUIRED, isolation=Isolation.DEFAULT, rollbackFor={Exception.class,SQLException.class}, readOnly=false)
    public void deleteUser(User user) throws Exception {
        userMapper.deleteUser(user);
    }
    
    
    public User getSelfInfo(User user) throws Exception {
        return userMapper.getSelfInfo(user);
    }
    
    
    public User checkSelfPass(User user) throws Exception {
        return userMapper.checkSelfPass(user);
    }
    
    @Transactional(propagation=Propagation.REQUIRED, isolation=Isolation.DEFAULT, rollbackFor={Exception.class,SQLException.class}, readOnly=false)
    public void updateSelfInfo(User user) throws Exception {
        userMapper.updateSelfInfo(user);
    }
    
    
    public String getUserName(User user) throws Exception {
        return userMapper.getUserName(user);
    }
    
    
    
    
    
    
    
    
//    public List<HostFilter> getHostInfo(int start, int limit) throws Exception {
//    	return userMapper.getHostInfo(start, limit);
//    }
   
    
    public Integer getHostInfoCount() throws Exception {
    	return userMapper.getHostInfoCount();
    }
    
//    @Transactional(propagation=Propagation.REQUIRED, isolation=Isolation.DEFAULT, rollbackFor={Exception.class,SQLException.class}, readOnly=false)
//    public void insertHost(HostFilter hf) throws Exception {
//    	userMapper.insertHost(hf);
//    }
//    
//    @Transactional(propagation=Propagation.REQUIRED, isolation=Isolation.DEFAULT, rollbackFor={Exception.class,SQLException.class}, readOnly=false)
//    public void updateHost(HostFilter hf) throws Exception {
//    	userMapper.updateHost(hf);
//    }
//    
//    @Transactional(propagation=Propagation.REQUIRED, isolation=Isolation.DEFAULT, rollbackFor={Exception.class,SQLException.class}, readOnly=false)
//    public void deleteHost(HostFilter hf) throws Exception {
//    	userMapper.deleteHost(hf);
//    }
}
