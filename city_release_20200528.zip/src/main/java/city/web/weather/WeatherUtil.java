package city.web.weather;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.StringReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

public class WeatherUtil {

    public String getData(String date, String time, String nx, String ny) throws Exception {
        StringBuilder urlBuilder = new StringBuilder("http://apis.data.go.kr/1360000/VilageFcstInfoService/getUltraSrtNcst");
        urlBuilder.append("?" + URLEncoder.encode("serviceKey","UTF-8") + "=" + "6TC%2ByQEfvLUXN6hM%2FoQjNkOBU0r3pDiu2JOpATkqsLo69%2FlFJI2mUCv354q%2FsYUHOMUkUkS88nfXaFGI3c29cA%3D%3D"); /*Service Key*/
        urlBuilder.append("&" + URLEncoder.encode("base_date","UTF-8") + "=" + URLEncoder.encode(date, "UTF-8")); /*�삁蹂댁씪�옄*/
        urlBuilder.append("&" + URLEncoder.encode("base_time","UTF-8") + "=" + URLEncoder.encode(time, "UTF-8")); /*�삁蹂댁떆媛�*/
        urlBuilder.append("&" + URLEncoder.encode("nx","UTF-8") + "=" + URLEncoder.encode(nx, "UTF-8")); /*�삁蹂댁��젏X醫뚰몴*/
        urlBuilder.append("&" + URLEncoder.encode("ny","UTF-8") + "=" + URLEncoder.encode(ny, "UTF-8")); /*�삁蹂댁��젏Y醫뚰몴*/
        urlBuilder.append("&" + URLEncoder.encode("numOfRows","UTF-8") + "=" + URLEncoder.encode("99", "UTF-8")); /*寃��깋嫄댁닔*/
        urlBuilder.append("&" + URLEncoder.encode("pageNo","UTF-8") + "=" + URLEncoder.encode("1", "UTF-8")); /*�럹�씠吏� 踰덊샇*/

        URL url = new URL(urlBuilder.toString());
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("GET");
        conn.setRequestProperty("Content-type", "application/json");
        
        BufferedReader rd;
        if(conn.getResponseCode() >= 200 && conn.getResponseCode() <= 300) {
            rd = new BufferedReader(new InputStreamReader(conn.getInputStream()));
        } else {
            rd = new BufferedReader(new InputStreamReader(conn.getErrorStream()));
        }
        StringBuilder sb = new StringBuilder();
        String line;
        while ((line = rd.readLine()) != null) {
            sb.append(line);
        }
        rd.close();
        conn.disconnect();
        
        return sb.toString();
    }
    
    public Weather getInfo(String result) throws Exception {
        Weather weather = new Weather();
        
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        DocumentBuilder builder = factory.newDocumentBuilder();
        Document doc = builder.parse( new InputSource(new StringReader(result)) );
        
        doc.getDocumentElement().normalize();
        
        NodeList nList = doc.getElementsByTagName("item");
        for(int i=0; i<nList.getLength();i++) {
            Node nNode = nList.item(i);
            if (nNode.getNodeType() == Node.ELEMENT_NODE) {
                Element eElement = (Element) nNode;
                String category = getTagValue("category", eElement);

                if ( "LGT".equals(category) ) {
                    weather.setThunderstroke(getTagValue("obsrValue", eElement));
                } else if ( "PTY".equals(category) ) {
                    weather.setPrecipitation(getTagValue("obsrValue", eElement)); //fcstValue
                } else if ( "SKY".equals(category) ) {
                    weather.setSky(getTagValue("obsrValue", eElement));
                } else if ( "T1H".equals(category) ) {
                    weather.setTemp(new Double(getTagValue("obsrValue", eElement)).doubleValue());
                } else if ( "RN1".equals(category) ) {
                    weather.setRain(new Double(getTagValue("obsrValue", eElement)).doubleValue());
                } else if ( "REH".equals(category) ) {
                    weather.setHumidity(new Double(getTagValue("obsrValue", eElement)).doubleValue());
                }
            }
        }
        
        return weather;
    }
    
    private static String getTagValue(String sTag, Element eElement) {
        NodeList nlList = eElement.getElementsByTagName(sTag).item(0).getChildNodes();
        Node nValue = (Node) nlList.item(0);
        return nValue.getNodeValue();
    }
    
}
