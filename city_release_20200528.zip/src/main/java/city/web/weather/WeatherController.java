package city.web.weather;

import java.text.SimpleDateFormat;
import java.util.Locale;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import city.login.web.LoginController;

@Controller
public class WeatherController {

    @Autowired
    WeatherService weatherService;

    @Value("${weather.dateFormat}")
    private String message;

    static SimpleDateFormat dateFormat= new SimpleDateFormat("yyyyMMdd", Locale.KOREA);
    static SimpleDateFormat timeFormat = new SimpleDateFormat("HH", Locale.KOREA);
    
    @RequestMapping("/getWeatherInfo")
    public String getInfo(HttpServletRequest req, Model model, @RequestParam(value="workspaceId", required=false, defaultValue="-1") Integer workspaceId) {
        if (LoginController.getUser(req) == null) {
            return "include/weather :: empty";
        }
        
        try {
            if (workspaceId == -1) {
                workspaceId = LoginController.getUser(req).getWorkspaceId();
            }
            Weather info = weatherService.getWeatherForCurrent(workspaceId);
            
            if (info != null) {
                model.addAttribute("weather", info);
                return "include/weather :: weather";
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return "include/weather :: empty";
    }
}
