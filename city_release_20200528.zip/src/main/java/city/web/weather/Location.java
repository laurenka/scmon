package city.web.weather;

public class Location {
   
    private int id;
    private String nx;
    private String ny;
    
    
    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }
    public String getNx() {
        return nx;
    }
    public void setNx(String nx) {
        this.nx = nx;
    }
    public String getNy() {
        return ny;
    }
    public void setNy(String ny) {
        this.ny = ny;
    }
}
