package city.web.weather;

public class Weather {
    
    String date;
    String time;
    int addressId;
    
    String thunderstroke;
    String precipitation;
    String sky;
    double temp;
    double rain;
    double humidity;
    
    
    public String getDate() {
        return date;
    }
    public void setDate(String date) {
        this.date = date;
    }
    public String getTime() {
        return time;
    }
    public void setTime(String time) {
        this.time = time;
    }
    public int getAddressId() {
        return addressId;
    }
    public void setAddressId(int addressId) {
        this.addressId = addressId;
    }
    public String getThunderstroke() {
        return thunderstroke;
    }
    public void setThunderstroke(String thunderstroke) {
        this.thunderstroke = thunderstroke;
    }
    public String getPrecipitation() {
        return precipitation;
    }
    public void setPrecipitation(String precipitation) {
        this.precipitation = precipitation;
    }
    public String getSky() {
        return sky;
    }
    public void setSky(String sky) {
        this.sky = sky;
    }
    public double getTemp() {
        return temp;
    }
    public void setTemp(double temp) {
        this.temp = temp;
    }
    public double getRain() {
        return rain;
    }
    public void setRain(double rain) {
        this.rain = rain;
    }
    public String getTempDiv() {
        return String.format("%.2f", temp);
    }
    public int getSkyDiv() {
        if ( "0".equals(precipitation) ) {
        	return 11;
//            switch( sky ) {
//            case "1":
//                return 11;
//            case "2":
//                return 12;
//            case "3":
//                return 13;
//            case "4":
//                return 14;
//            default: 
//                return -1;
//            }
        } else {
            switch( precipitation ) {
            case "1":
                return 21;
            case "2":
                return 22;
            case "3":
                return 23;
            default:
                return -2;
            }
        }
    }
    public double getHumidity() {
        return humidity;
    }
    public void setHumidity(double humidity) {
        this.humidity = humidity;
    }
}
