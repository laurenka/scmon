package city.web.weather;

import java.util.List;

import org.joda.time.DateTime;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

@Component
public class WeatherScheduler {
    
    @Autowired
    WeatherService weatherService;
    
    DateTimeFormatter dateDtf = DateTimeFormat.forPattern("yyyyMMdd");
    DateTimeFormatter timeDtf = DateTimeFormat.forPattern("HHmm");
    
    @Scheduled(cron = "${city.measurement.expression}")//@Scheduled(cron="* 0/1 * * * *")//    @Scheduled(cron="0 41 * * * *") 
    public void per1Hour() {
        try {
            DateTime dateTime = new DateTime();
            dateTime = dateTime.plusHours(-1);
            WeatherUtil weather = new WeatherUtil();
            
            List<Location> list = weatherService.getLocationList();
            for(Location location : list) {
                String result = weather.getData(dateDtf.print(dateTime), timeDtf.print(dateTime), location.getNx(), location.getNy());
                Weather info = weather.getInfo(result);
                
                weatherService.insertWeatherInfo(location, info);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
