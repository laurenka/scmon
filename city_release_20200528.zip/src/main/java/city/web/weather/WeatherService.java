package city.web.weather;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Service;

import city.dao.mapper.WeatherMapper;
import city.domain.User;

@Service("weatherService")
public class WeatherService {
    
    @Autowired
    WeatherMapper weatherMapper;
    
    public Location getCompanyLocationById(User user) throws DataAccessException {
        return weatherMapper.getCompanyLocationById(user);
    }
    
    public List<Location> getLocationList() throws Exception {
        return weatherMapper.getLocationList();
    }
    
    public void insertWeatherInfo(Location location, Weather weather) throws Exception {
        weatherMapper.insertWeatherInfo(location, weather);
    }
    
    public Weather getWeatherForCurrent(int workspaceId) throws Exception {
    	return weatherMapper.getWeatherForCurrent(workspaceId);
    }
    
}
