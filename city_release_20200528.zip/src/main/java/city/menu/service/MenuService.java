package city.menu.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import city.dao.mapper.MenuMapper;
import city.domain.ComboData;


@Service("menuService")
public class MenuService {
    
    @Autowired
    private MenuMapper menuMapper;
    
    public List<MenuItem> getMenuList(int typeId) throws Exception {
        return menuMapper.getMenuList(typeId);
    }
    
    public List<ComboData> getModule(int deptId, int locationId) throws Exception {
        return menuMapper.getModule(deptId, locationId);
    }
    
    public List<MenuItem> getParentMenuItem(String schema, int userGrant) throws Exception {
        return menuMapper.getParentMenuItem(schema, userGrant);
    };
    
    public List<MenuItem> getMenuItem(String schema, int parentId) throws Exception {
        return menuMapper.getMenuItem(schema, parentId);
    };
    
    public List<MenuItem> getMappingMenuItem(String schema) throws Exception {
        return menuMapper.getMappingMenuItem(schema);
    };
    
    public int getDepthByWorkspace(int workspaceId) throws Exception {
        return menuMapper.getDepthByWorkspace(workspaceId);
    }
    
    public List<MenuItem> getTabList(int domainId) throws Exception {
        return menuMapper.getTabList(domainId);
    }
}
