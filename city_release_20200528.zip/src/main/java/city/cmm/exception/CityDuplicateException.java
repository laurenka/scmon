package city.cmm.exception;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class CityDuplicateException extends Exception {
    
    private static final long serialVersionUID = 1L;
    
    @Value("${city.exception.duplicate}")
    private String message;

    @Override
    public String getMessage() {
        return message;
    }
}
