package city.cmm.module;

import java.lang.reflect.Field;

import city.domain.ComboData;



public class CalculationUtil {
    public static <T> String getValue(T t, ComboData cd) {
        try {
            Class<? extends Object> cls = t.getClass();
            if (cls != null) {
                Field field = getField(cls, cd.getSubName());
                if(field == null) {
                	return null;
                }
                field.setAccessible(true);
                Object value = field.get(t);
                if (value == null) {
                    return null;
                }
                
                return (String) value;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }
    
    /**
	 * Returns the first {@link Field} in the hierarchy for the specified name
	 */
	public static Field getField(Class<?> clazz, String name) {
	    Field field = null;
	    while (clazz != null && field == null) {
	        try {
	            field = clazz.getDeclaredField(name);
	        } catch (Exception e) {
	        }
	        clazz = clazz.getSuperclass();
	    }
	    return field;
	}
}