package city.cmm.module;

public enum EnModuleType {
    COOLING(1),
    LIGHTING(2),
    COMPRESSOR(3),
    HEATING(4),
    BOILER(5),
    VENTILATION(6),
    PRODUCT_EQUIPMENT(7),
    ENERGY(8),
    ESS(9);

    private int id;
    public static EnModuleType find (int id) {
        for (EnModuleType en : values()) {
            if (en.getId() == id) {
                return en;
            }
        }
        return null;
    }
    private EnModuleType(int id) {
        this.id = id;
    }

    public int getId() {
        return id;
    }
}
