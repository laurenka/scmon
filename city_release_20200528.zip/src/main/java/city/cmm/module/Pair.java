package city.cmm.module;

public class Pair<T, T1> {
    T input1;
    T1 input2;
    
    public Pair() {
        input1 = null;
        input2 = null;
    }
    
    public Pair(T input1, T1 input2) {
        this.input1 = input1;
        this.input2 = input2;
    }
    
    public T getInput1() {
        return input1;
    }
    public Pair<T, T1> setInput1(T input1) {
        this.input1 = input1;
        return this;
    }
    public T1 getInput2() {
        return input2;
    }
    public Pair<T, T1> setInput2(T1 input2) {
        this.input2 = input2;
        return this;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        
        if (obj == null || obj.getClass() != this.getClass()) {
            return false;
        }
        
        Pair pair = (Pair) obj;
        boolean isGood = true;
        if (isGood && pair.getInput1() instanceof Integer) {
            isGood = CompareUtil.isEquals((Integer) pair.getInput1(), (Integer) input1);
        } else if (isGood && pair.getInput1() instanceof Float) {
            isGood = CompareUtil.isEquals((Float) pair.getInput1(), (Float) input1);
        } else if (isGood && pair.getInput1() instanceof String) {
            isGood = CompareUtil.isEquals((String) pair.getInput1(), (String) input1);
        }

        if (isGood && pair.getInput2() instanceof Integer) {
            isGood = CompareUtil.isEquals((Integer) pair.getInput2(), (Integer) input2);
        } else if (isGood && pair.getInput2() instanceof Float) {
            isGood = CompareUtil.isEquals((Float) pair.getInput2(), (Float) input2);
        } else if (isGood && pair.getInput2() instanceof String) {
            isGood = CompareUtil.isEquals((String) pair.getInput2(), (String) input2);
        }
        
        return isGood;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((input1 == null) ? 0 : input1.hashCode());
        result = prime * result + ((input2 == null) ? 0 : input2.hashCode());
        return result;
    }
}
