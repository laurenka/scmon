package city.cmm.util;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import city.domain.User;
import city.login.web.LoginController;

public class LoginInterceptor extends HandlerInterceptorAdapter {

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
            throws Exception {
        String path = request.getServletPath();
        if ("/OCR/PUT".equals(path) || path.contains("/images") || path.contains("/css") || path.contains("/js")
                || path.contains("/getWeatherInfo") || path.contains("/font-awesome")) {
            return true;
        }
        if (path.contains("/error")) {
            return false;
        }

        String[] arrayPath = path.split("/");
        if (arrayPath.length < 3) {
            return false;
        }
        

        boolean checkSession = LoginController.setMainSession(request, arrayPath[1]);
        User user = LoginController.getUser(request);
        if (checkSession && user != null) {
            return true;
        } else {
            if (arrayPath.length == 3) {
                if ("login".equals(arrayPath[2]) || "authentication".equals(arrayPath[2])
                        || "logout".equals(arrayPath[2])) {
                    return true;
                } else {
                    if ("main".equals(arrayPath[2]) || "error".equals(arrayPath[2])
                            || "404.html".equals(arrayPath[2])) {
                        response.sendRedirect(
                                String.format("%s/%s/%s", request.getContextPath(), arrayPath[1], "login"));
                    } else {
                        response.sendError(901);
                    }
                }
            } else if (arrayPath.length == 2) {
                response.sendRedirect(String.format("%s/%s/%s", request.getContextPath(), arrayPath[1], "login"));
            } else {
                response.sendError(901);
            }

            return false;
        }
    }
}
